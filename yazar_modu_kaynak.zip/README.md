# Yazar Modu – Mobil Kitap Editörü v0.4

Bu kaynak paketinde:

- TXT, Word DOCX ve PDF içe aktarma
- DOCX içindeki JPG, JPEG, PNG, GIF, WEBP ve BMP görsellerini metindeki konumlarına bağlama
- PDF sayfalarını metin ve görsel ön izleme olarak aktarma
- Bölüm Editörü içinde **Metni düzenle / Belge görünümü** geçişi
- Görsellere dokunarak tam ekran ve yakınlaştırmalı inceleme
- Bölüm Ekle menüsünden belgeyi tek bölüm veya otomatik ayrılmış bölümler şeklinde ekleme
- Android Paylaş / Birlikte aç menüsünden Yazar Modu’na belge gönderme
- Yapay zekâ karşılaştırma editörü
- Bölüm, kelime, görsel ve tahmini sayfa istatistikleri

## Desteklenen dosyalar

- `.txt`
- `.docx` (modern Word)
- `.pdf` (metinli veya görselli)

Eski `.doc` dosyaları önce Word içinde DOCX biçiminde kaydedilmelidir. EMF ve WMF gibi eski Word çizim biçimleri Android tarafından doğrudan gösterilemeyebilir; standart JPG veya PNG kullanılması önerilir.

## v0.5 yenilikleri

- 13,5 × 21 cm oranında gerçek kitap sayfası ön izlemesi
- Metin ve görselleri otomatik sayfalara dağıtma
- Sayfa numaraları ve kitap kenar boşlukları
- Belge görünümünde görsel çevresindeki yapay beyaz alanları kaldıran doğal genişlik düzeni
- PDF sayfa ön izlemelerinde dış beyaz kenarları içe aktarma sırasında otomatik kırpma

Not: Daha önce içe aktarılmış PDF görsellerindeki gömülü beyaz alanların kırpılması için belgeyi bu sürümde yeniden içe aktarın.
