# Yazar Modu – Mobil Kitap Editörü v0.8.0

Bu sürüm mevcut kitap projelerini koruyacak biçimde aynı Android uygulama kimliğini kullanır.

## Yeni özellikler

- Ana ekrandaki kalkan menüsünden **Tüm projeleri yedekle**
- Metinleri ve bütün bölüm görsellerini tek ZIP dosyasına kaydetme
- **Yedeği geri yükle** ile projeleri ve görselleri geri getirme
- Bölüm menüsünden seçilen bölümü kendi görselleriyle ayrı **PDF** olarak kaydetme
- Bölüm menüsünden seçilen bölümü kendi görselleriyle ayrı **Word DOCX** olarak kaydetme
- Kitap ekranındaki paylaş menüsünden tüm bölümleri:
  - ayrı PDF dosyaları,
  - ayrı Word DOCX dosyaları,
  - iki format birlikte
  tek ZIP paketi olarak hazırlama
- Dışa aktarılan belgelerde bölüm numarası, ana başlık, alt başlık, paragraflar, görseller ve altyazılar korunur.
- PDF sayfa ölçüsü 13,5 × 21 cm kitap oranına göre hazırlanır.

## Güncelleme güvenliği

Uygulama kimliği `com.altayaytin.yazar_modu_kitap_editoru` olarak korunmuştur ve sürüm kodu 21’e yükseltilmiştir. APK mevcut uygulamanın üzerine kurulursa kayıtlı bölümler silinmez.

GitHub Actions’ın daha önce farklı bir imza anahtarıyla ürettiği APK Android tarafından reddedilebilir. Telefon “önce eski uygulamayı kaldırın” derse uygulamayı hemen silmeyin. Önce çalışmakta olan sürümden tam yedek alın. Kalıcı imza sistemine geçiş, güvenli yedek alındıktan sonra yapılmalıdır.
