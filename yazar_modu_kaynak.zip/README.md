# Yazar Modu — Mobil Kitap Editörü v0.3

## Bu sürümde çalışan özellikler

- TXT, modern Word DOCX ve metin tabanlı PDF içe aktarma
- DOCX içindeki ad alanlı Word XML yapısını güvenli okuma
- Ana ekrandan dosyadan yeni kitap oluşturma
- “Bölüm Ekle” içinden boş bölüm, tek bölüm olarak belge veya otomatik bölünmüş belge ekleme
- Android Paylaş ve Birlikte Aç menülerinde Yazar Modu seçeneği
- Paylaşılan belgeyi yeni kitaba veya mevcut bir kitaba ekleme
- Ön Söz, Giriş, numaralı bölümler, Son Söz ve Kaynakça algılama
- Yapay zekâ karşılaştırma editörü; değişiklikleri tek tek kabul veya reddetme
- Harici yapay zekâ sonucunu panodan yapıştırıp karşılaştırma
- Otomatik kayıt, bölüm sıralama, silme ve birleştirme

## Word notu

Modern Word dosyası olan `.docx` desteklenir. Eski `.doc` dosyaları Word içinde “Farklı Kaydet” ile DOCX biçimine çevrilmelidir.

## PDF notu

Metni seçilebilen PDF dosyaları içe aktarılır. Fotoğraf/tarama PDF dosyaları için OCR sonraki aşamada eklenecektir.
