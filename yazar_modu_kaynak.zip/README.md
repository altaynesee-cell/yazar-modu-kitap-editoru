# Yazar Modu – v0.1.3

Android için ilk çalışan kaynak sürümüdür.

Bu sürümde dosya seçme ve proje kayıt klasörü doğrudan Android'in yerel API'leriyle yönetilir. `file_picker` ve `path_provider` eklentileri kaldırılmıştır; böylece Flutter 3.44 Android derlemesindeki eklenti kayıt hatası önlenir.

## İlk sürüm özellikleri

- Yeni kitap projesi oluşturma
- Metin yapıştırma
- TXT ve DOCX dosyası seçme
- Ön Söz, Giriş, bölümler, Son Söz ve Kaynakça algılama
- Bölüm düzenleme, silme, sıralama ve birleştirme
- Bölümler / Durum / Eksikler ekranları
- Otomatik yerel kayıt
