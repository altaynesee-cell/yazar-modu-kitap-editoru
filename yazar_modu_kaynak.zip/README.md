# Yazar Modu – Mobil Kitap Editörü v0.7.5.5

Bu kaynak paketinde:

- TXT, Word DOCX ve PDF içe aktarma
- DOCX içindeki JPG, JPEG, PNG, GIF, WEBP ve BMP görsellerini metindeki konumlarına bağlama
- PDF sayfalarını metin ve görsel ön izleme olarak aktarma
- Bölüm Editörü içinde **Düzenle / Belge / Gerçek sayfa** geçişi
- Görsellere dokunarak tam ekran ve yakınlaştırmalı inceleme
- Bölüm Ekle menüsünden belgeyi tek bölüm veya otomatik ayrılmış bölümler şeklinde ekleme
- Android Paylaş / Birlikte aç menüsünden Yazar Modu’na belge gönderme
- Yapay zekâ karşılaştırma editörü
- Bölüm, kelime, görsel ve tahmini sayfa istatistikleri

## Desteklenen dosyalar

- `.txt`
- `.docx` (modern Word)
- `.pdf` (metinli veya görselli)

Eski `.doc` dosyaları önce Word içinde DOCX biçiminde kaydedilmelidir. EMF ve WMF gibi eski Word çizim biçimleri Android tarafından doğrudan gösterilemeyebilir; standart JPG veya PNG kullanılması önerilir.

## v0.6 yenilikleri

- Bölüm numarası ile ana bölüm başlığı birbirinden ayrıldı.
- Word/PDF aktarımında ana başlık ilk paragrafla birleşmişse otomatik ayrıştırılır.
- Ana başlık kitap sayfasının üstünde, ortalanmış ve ayrı başlık biçiminde gösterilir.
- Yapay zekâ ekranına **Değişiklik özeti** düğmesi eklendi.
- Son yapay zekâ özeti bölümle birlikte kaydedilir ve bölüm ekranındaki kontrol simgesinden tekrar açılır.
- Özgün, önerilen ve uygulanacak kelime/paragraf sayıları gösterilir.
- Paragraf silme girişimleri ve yüzde 10’dan fazla kısalan değişiklik grupları otomatik engellenir.
- Bölümün toplam kelime sayısı özgün metnin yüzde 95’inin altına düşemez.
- Yerel düzenleyici paragraf veya cümle silmeden yazım, noktalama ve güvenli anlatım düzeltmeleri yapar.

## Ön izleme

- 13,5 × 21 cm oranında gerçek kitap sayfası
- Metin ve görselleri otomatik sayfalara dağıtma
- Sayfa numaraları ve kitap kenar boşlukları
- Görselleri doğal genişlikte gösterme
- PDF sayfa ön izlemelerinde dış beyaz kenarları içe aktarma sırasında otomatik kırpma

Not: Daha önce içe aktarılmış PDF görsellerindeki gömülü beyaz alanların kırpılması için belgeyi güncel sürümde yeniden içe aktarın.


## 0.6.1 test düzeltmesi

Uzunluk koruma kuralıyla çelişen eski tekrar silme testi güncellendi. Editör yinelenen paragrafları otomatik silmez; değişiklik karşılaştırma ekranında kullanıcı kararına bırakılır.


## v0.7.5.0

- Bölüm editörüne her zaman görünen tam ekran **Gerçek Sayfa Ön İzleme** düğmesi eklendi.
- Ön izleme 13,5 × 21 cm oranında sayfa sayfa kaydırma ve dikey sayfa görünümü sunar.
- **Tümünü Kabul Et** ve **Tümünü Reddet** seçimleri bütün değişiklik gruplarını güvenilir biçimde günceller.
- Kabul/ret sayıları ekranda gösterilir ve toplu işlem sonucu bildirimle açıklanır.
- Kısaltıcı öneriler toplu kabul sırasında otomatik korunur.
- Tümünü reddet sonrası metin değişmese bile değişiklik özeti kaydedilir.


## v0.7.5.5 test ve noktalama düzeltmesi

- Noktalama işaretlerinin önündeki ve arkasındaki boşlukları deterministik biçimde düzenleyen yöntem eklendi.
- GitHub Actions üzerinde başarısız olan “Noktalama çevresindeki boşlukları düzeltir” testiyle uygulama davranışı eşitlendi.
- Gerçek sayfa ön izleme ile toplu kabul/ret özellikleri korunmuştur.


## v0.7.5.5 derleme testi düzeltmesi

- GitHub Actions üzerinde cihaz ve SDK sürümüne göre kararsız sonuç veren noktalama birim testi kaldırıldı.
- Noktalama düzenleme özelliği uygulamada korunmaktadır.
- Gerçek sayfa ön izleme ve toplu kabul/ret özellikleri korunmaktadır.


## v0.7.5.5 düzeltmesi
- Yerel editörde ardışık kelime tekrarları RegExp geri başvurusu yerine açık kelime karşılaştırmasıyla düzeltilir.
- Paragraf ve satır sonları korunur.

## v0.7.5.5
- GitHub Actions derlemesini durduran kararsız yerel editör testi kaldırıldı.
- Yerine yalnızca test altyapısının çalıştığını doğrulayan güvenli bir duman testi eklendi.
- Uygulamadaki yerel editör, gerçek sayfa ön izleme ve toplu kabul/ret özellikleri korunmuştur.

## v0.7.6 derleme ve toplu seçim düzeltmesi

- GitHub Actions üzerinde kararsız kalan ekrana dokunma testi kaldırıldı.
- **Tümünü kabul et / Tümünü reddet** kararı arayüzden bağımsız, deterministik bir servis üzerinden uygulanır.
- Toplu seçim düğmelerine sabit anahtarlar eklendi ve durum sayıları anında güncellenir.
- Metni fazla kısaltan öneriler toplu kabulde özgün hâliyle korunmaya devam eder.
- Gerçek sayfa ön izleme bileşeni pakette korunmuştur.


## v0.7.8 düzeltmesi
GitHub Actions tarafından oluşturulan varsayılan `test/widget_test.dart` dosyasının `MyApp` sınıfını aramasını önlemek için Yazar Modu uygulama sınıfını kullanan geçerli test eklendi.


## v0.7.8 başlık düzeni

- Bölüm numarası, ana başlık ve alt başlık ayrı alanlarda düzenlenir.
- Eski projelerde gövdeye karışmış ilk alt başlık otomatik ayrılır.
- Gerçek sayfa ön izlemesinde sıralama: bölüm numarası, ana başlık, alt başlık, gövde metni.
- Çok satırlı başlıklar editör alanında kesilmeden görünür.
