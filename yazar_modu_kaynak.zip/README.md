# Yazar Modu — Kaynak v0.1.1

Bu kaynak paketi GitHub Actions üzerinden Android APK üretmek için hazırlanmıştır.

Çalışan ilk özellikler:
- Kitap projesi oluşturma
- Metin yapıştırma
- TXT ve DOCX içe aktarma
- Ön Söz, Giriş, bölüm, Son Söz ve Kaynakça algılama
- Bölüm ekleme, silme, sıralama ve birleştirme
- Bölüm bazlı düzenleme
- Otomatik yerel kayıt
- Durum ve eksik kontrol ekranları

Henüz bulunmayan özellikler:
- Yapay zekâ editörü
- Basılı kitap sayfalama motoru
- Görsel yerleşimi
- PDF, Word ve EPUB dışa aktarma

Bu dosyalar doğrudan telefona kurulmaz. GitHub Actions, kaynakları kullanarak APK üretir.
