# Yazar Modu — Mobil Kitap Editörü v0.2

Bu sürüm Android için hazırlanmış Flutter kaynak paketidir.

## Çalışan özellikler

- Birden fazla kitap projesi oluşturma ve otomatik kayıt
- TXT, Word DOCX ve metin tabanlı PDF dosyalarını içe aktarma
- Metni doğrudan yapıştırma
- Ön Söz, Giriş, bölümler, Son Söz ve Kaynakça algılama
- Bölüm ekleme, silme, sıralama ve birleştirme
- Bölüm bazlı metin editörü
- Karşılaştırmalı akıllı editör
- Eski metin ile önerilen metni paragraf grupları halinde karşılaştırma
- Her değişikliği ayrı kabul etme veya reddetme
- Harici bir yapay zekâ uygulamasından alınan sonucu yapıştırıp karşılaştırma
- Durum ve eksikler ekranı

## PDF notu

Metin seçilebilen PDF dosyaları içe aktarılır. Taranmış fotoğraf PDF'lerinde henüz OCR bulunmadığı için uygulama uyarı verir.

## Yapay zekâ notu

Bu sürümde çevrimdışı güvenli düzenleme kuralları ve karşılaştırma ekranı bulunur. Harici yapay zekâdan alınan metin de panodan yapıştırılarak karşılaştırılabilir. Gizli API anahtarı uygulamanın içine gömülmemiştir.


## 0.2.1 derleme düzeltmesi

- PdfBox-Android için R8 isteğe bağlı JP2Decoder kuralı eklendi.
- Word DOCX, metin tabanlı PDF ve TXT içe aktarma korunur.
- Yapay zekâ karşılaştırma editörü korunur.
