# PdfBox-Android içindeki JPEG 2000 (JPX) desteği isteğe bağlıdır.
# Uygulama PDF metni çıkarırken bu sınıfa doğrudan ihtiyaç duymaz.
# R8'in isteğe bağlı Gemalto kod çözücü sınıfı yüzünden derlemeyi durdurmasını engeller.
-dontwarn com.gemalto.jp2.**
