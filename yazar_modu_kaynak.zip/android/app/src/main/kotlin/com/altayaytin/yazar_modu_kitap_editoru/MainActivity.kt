package com.altayaytin.yazar_modu_kitap_editoru

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.altayaytin.yazar_modu/native"
        private const val OPEN_DOCUMENT_REQUEST = 4701
        private const val MAX_PDF_PREVIEW_PAGES = 80
        private const val PDF_PREVIEW_WIDTH = 1000
    }

    private var pendingDocumentResult: MethodChannel.Result? = null
    private var pendingSharedDocument: Map<String, Any>? = null
    private var pendingSharedError: String? = null
    private var methodChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureSharedIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        PDFBoxResourceLoader.init(applicationContext)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocument" -> openDocumentPicker(result)
                "consumeSharedDocument" -> consumeSharedDocument(result)
                "extractPdfDocument" -> extractPdfDocument(call, result)
                "getDocumentsPath" -> result.success(filesDir.absolutePath)
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureSharedIntent(intent)
    }

    private fun openDocumentPicker(result: MethodChannel.Result) {
        if (pendingDocumentResult != null) {
            result.error("PICKER_BUSY", "Dosya seçme ekranı zaten açık.", null)
            return
        }

        pendingDocumentResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "text/plain",
                    "application/pdf",
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/octet-stream",
                    "application/zip"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent.createChooser(intent, "TXT, Word DOCX veya PDF dosyası seçin"),
                OPEN_DOCUMENT_REQUEST
            )
        } catch (error: Exception) {
            pendingDocumentResult = null
            result.error("PICKER_OPEN_FAILED", error.message, null)
        }
    }

    private fun consumeSharedDocument(result: MethodChannel.Result) {
        val error = pendingSharedError
        if (error != null) {
            pendingSharedError = null
            result.error("SHARED_FILE_READ_FAILED", error, null)
            return
        }
        val document = pendingSharedDocument
        pendingSharedDocument = null
        result.success(document)
    }

    private fun captureSharedIntent(sharedIntent: Intent?) {
        if (sharedIntent == null) return
        try {
            when (sharedIntent.action) {
                Intent.ACTION_SEND -> {
                    val streamUri = sharedStreamUri(sharedIntent)
                    if (streamUri != null) {
                        readSharedUri(streamUri, sharedIntent.flags)
                    } else {
                        val sharedText = sharedIntent.getStringExtra(Intent.EXTRA_TEXT)
                        if (!sharedText.isNullOrBlank()) {
                            pendingSharedDocument = mapOf(
                                "name" to "paylasilan_metin.txt",
                                "bytes" to sharedText.toByteArray(Charsets.UTF_8)
                            )
                            notifySharedDocumentAvailable()
                        }
                    }
                }
                Intent.ACTION_VIEW -> {
                    sharedIntent.data?.let { readSharedUri(it, sharedIntent.flags) }
                }
            }
        } catch (error: Exception) {
            pendingSharedError = error.message ?: "Paylaşılan belge okunamadı."
            notifySharedDocumentAvailable()
        }
    }

    @Suppress("DEPRECATION")
    private fun sharedStreamUri(intent: Intent): Uri? {
        val extraUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        return extraUri ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
    }

    private fun readSharedUri(uri: Uri, flags: Int) {
        persistReadPermission(uri, flags)
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Paylaşılan dosyanın içeriği okunamadı.")
        val name = queryDisplayName(uri) ?: inferNameFromMime(uri)
        pendingSharedDocument = mapOf("name" to name, "bytes" to bytes)
        pendingSharedError = null
        notifySharedDocumentAvailable()
    }

    private fun inferNameFromMime(uri: Uri): String {
        return when (contentResolver.getType(uri)) {
            "application/pdf" -> "paylasilan_belge.pdf"
            "application/msword" -> "paylasilan_belge.doc"
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ->
                "paylasilan_belge.docx"
            "text/plain" -> "paylasilan_metin.txt"
            else -> "paylasilan_belge"
        }
    }

    private fun notifySharedDocumentAvailable() {
        methodChannel?.invokeMethod("sharedDocumentAvailable", null)
    }

    private fun extractPdfDocument(call: MethodCall, result: MethodChannel.Result) {
        val bytes = call.arguments as? ByteArray
        if (bytes == null || bytes.isEmpty()) {
            result.error("PDF_BYTES_EMPTY", "PDF dosyasının içeriği alınamadı.", null)
            return
        }

        Thread {
            var tempFile: File? = null
            try {
                val pageTexts = mutableListOf<String>()
                val totalPages = PDDocument.load(bytes).use { document ->
                    val stripper = PDFTextStripper()
                    for (pageIndex in 0 until document.numberOfPages) {
                        stripper.startPage = pageIndex + 1
                        stripper.endPage = pageIndex + 1
                        pageTexts.add(stripper.getText(document).trim())
                    }
                    document.numberOfPages
                }

                tempFile = File.createTempFile("yazar_modu_pdf_", ".pdf", cacheDir)
                tempFile.writeBytes(bytes)
                val previewPageCount = minOf(totalPages, MAX_PDF_PREVIEW_PAGES)
                val pages = mutableListOf<Map<String, Any>>()

                ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        for (pageIndex in 0 until totalPages) {
                            var previewBytes = ByteArray(0)
                            if (pageIndex < previewPageCount) {
                                renderer.openPage(pageIndex).use { page ->
                                    val safeWidth = maxOf(page.width, 1)
                                    val safeHeight = maxOf(page.height, 1)
                                    val targetWidth = PDF_PREVIEW_WIDTH
                                    val targetHeight = ((targetWidth.toDouble() * safeHeight) / safeWidth)
                                        .toInt()
                                        .coerceIn(1, 1800)
                                    val bitmap = Bitmap.createBitmap(
                                        targetWidth,
                                        targetHeight,
                                        Bitmap.Config.ARGB_8888
                                    )
                                    bitmap.eraseColor(Color.WHITE)
                                    page.render(
                                        bitmap,
                                        null,
                                        null,
                                        PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                                    )
                                    val output = ByteArrayOutputStream()
                                    bitmap.compress(Bitmap.CompressFormat.JPEG, 78, output)
                                    previewBytes = output.toByteArray()
                                    output.close()
                                    bitmap.recycle()
                                }
                            }
                            pages.add(
                                mapOf(
                                    "pageNumber" to pageIndex + 1,
                                    "text" to pageTexts.getOrElse(pageIndex) { "" },
                                    "previewBytes" to previewBytes
                                )
                            )
                        }
                    }
                }

                val payload = mapOf(
                    "pages" to pages,
                    "totalPages" to totalPages,
                    "previewLimited" to (totalPages > previewPageCount)
                )
                runOnUiThread { result.success(payload) }
            } catch (error: Exception) {
                runOnUiThread {
                    result.error(
                        "PDF_READ_FAILED",
                        error.message ?: "PDF metni ve görselleri okunamadı.",
                        null
                    )
                }
            } finally {
                tempFile?.delete()
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != OPEN_DOCUMENT_REQUEST) return

        val result = pendingDocumentResult ?: return
        pendingDocumentResult = null

        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            result.success(null)
            return
        }

        try {
            persistReadPermission(uri, data.flags)
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Dosya içeriği okunamadı.")
            val name = queryDisplayName(uri) ?: inferNameFromMime(uri)
            result.success(mapOf("name" to name, "bytes" to bytes))
        } catch (error: Exception) {
            result.error("FILE_READ_FAILED", error.message, null)
        }
    }

    private fun persistReadPermission(uri: Uri, flags: Int) {
        val readFlag = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (readFlag == 0) return
        try {
            contentResolver.takePersistableUriPermission(uri, readFlag)
        } catch (_: SecurityException) {
            // Bazı sağlayıcılar kalıcı izin vermez; tek seferlik izin yeterlidir.
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                return cursor.getString(index)
            }
        }
        return uri.lastPathSegment
    }
}
