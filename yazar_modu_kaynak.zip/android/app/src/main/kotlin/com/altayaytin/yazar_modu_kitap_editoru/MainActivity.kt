package com.altayaytin.yazar_modu_kitap_editoru

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.altayaytin.yazar_modu/native"
        private const val OPEN_DOCUMENT_REQUEST = 4701
    }

    private var pendingDocumentResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickDocument" -> openDocumentPicker(result)
                    "getDocumentsPath" -> result.success(filesDir.absolutePath)
                    else -> result.notImplemented()
                }
            }
    }

    private fun openDocumentPicker(result: MethodChannel.Result) {
        if (pendingDocumentResult != null) {
            result.error("PICKER_BUSY", "Dosya seçme ekranı zaten açık.", null)
            return
        }

        pendingDocumentResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "text/plain",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/octet-stream",
                    "application/zip"
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent.createChooser(intent, "TXT veya DOCX dosyası seçin"),
                OPEN_DOCUMENT_REQUEST
            )
        } catch (error: Exception) {
            pendingDocumentResult = null
            result.error("PICKER_OPEN_FAILED", error.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != OPEN_DOCUMENT_REQUEST) return

        val result = pendingDocumentResult ?: return
        pendingDocumentResult = null

        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            result.success(null)
            return
        }

        try {
            persistReadPermission(uri, data.flags)
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Dosya içeriği okunamadı.")
            val name = queryDisplayName(uri) ?: "belge"
            result.success(mapOf("name" to name, "bytes" to bytes))
        } catch (error: Exception) {
            result.error("FILE_READ_FAILED", error.message, null)
        }
    }

    private fun persistReadPermission(uri: Uri, flags: Int) {
        val readFlag = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (readFlag == 0) return
        try {
            contentResolver.takePersistableUriPermission(uri, readFlag)
        } catch (_: SecurityException) {
            // Bazı dosya sağlayıcıları kalıcı izin vermez; tek seferlik izin yeterlidir.
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                return cursor.getString(index)
            }
        }
        return uri.lastPathSegment
    }
}
