package com.altayaytin.yazar_modu_kitap_editoru

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.altayaytin.yazar_modu/native"
        private const val OPEN_DOCUMENT_REQUEST = 4701
        private const val SAVE_DOCUMENT_REQUEST = 4702
        private const val RESTORE_BACKUP_REQUEST = 4703
        private const val MAX_PDF_PREVIEW_PAGES = 80
        private const val PDF_PREVIEW_WIDTH = 1000
        private const val BACKUP_MIME = "application/zip"
        private const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }

    private var pendingDocumentResult: MethodChannel.Result? = null
    private var pendingSaveResult: MethodChannel.Result? = null
    private var pendingRestoreResult: MethodChannel.Result? = null
    private var pendingOutputFile: File? = null
    private var pendingSharedDocument: Map<String, Any>? = null
    private var pendingSharedError: String? = null
    private var methodChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureSharedIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        PDFBoxResourceLoader.init(applicationContext)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "pickDocument" -> openDocumentPicker(result)
                "consumeSharedDocument" -> consumeSharedDocument(result)
                "extractPdfDocument" -> extractPdfDocument(call, result)
                "getDocumentsPath" -> result.success(filesDir.absolutePath)
                "createBackup" -> createBackup(call, result)
                "restoreBackup" -> restoreBackup(result)
                "exportSection" -> exportSection(call, result)
                "exportProjectSections" -> exportProjectSections(call, result)
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureSharedIntent(intent)
    }

    private fun openDocumentPicker(result: MethodChannel.Result) {
        if (pendingDocumentResult != null || pendingRestoreResult != null) {
            result.error("PICKER_BUSY", "Dosya seçme ekranı zaten açık.", null)
            return
        }

        pendingDocumentResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "text/plain",
                    "application/pdf",
                    "application/msword",
                    DOCX_MIME,
                    "application/octet-stream",
                    BACKUP_MIME
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }

        try {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent.createChooser(intent, "TXT, Word DOCX veya PDF dosyası seçin"),
                OPEN_DOCUMENT_REQUEST
            )
        } catch (error: Exception) {
            pendingDocumentResult = null
            result.error("PICKER_OPEN_FAILED", error.message, null)
        }
    }

    private fun consumeSharedDocument(result: MethodChannel.Result) {
        val error = pendingSharedError
        if (error != null) {
            pendingSharedError = null
            result.error("SHARED_FILE_READ_FAILED", error, null)
            return
        }
        val document = pendingSharedDocument
        pendingSharedDocument = null
        result.success(document)
    }

    private fun captureSharedIntent(sharedIntent: Intent?) {
        if (sharedIntent == null) return
        try {
            when (sharedIntent.action) {
                Intent.ACTION_SEND -> {
                    val streamUri = sharedStreamUri(sharedIntent)
                    if (streamUri != null) {
                        readSharedUri(streamUri, sharedIntent.flags)
                    } else {
                        val sharedText = sharedIntent.getStringExtra(Intent.EXTRA_TEXT)
                        if (!sharedText.isNullOrBlank()) {
                            pendingSharedDocument = mapOf(
                                "name" to "paylasilan_metin.txt",
                                "bytes" to sharedText.toByteArray(Charsets.UTF_8)
                            )
                            notifySharedDocumentAvailable()
                        }
                    }
                }
                Intent.ACTION_VIEW -> sharedIntent.data?.let { readSharedUri(it, sharedIntent.flags) }
            }
        } catch (error: Exception) {
            pendingSharedError = error.message ?: "Paylaşılan belge okunamadı."
            notifySharedDocumentAvailable()
        }
    }

    @Suppress("DEPRECATION")
    private fun sharedStreamUri(intent: Intent): Uri? {
        val extraUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }
        return extraUri ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
    }

    private fun readSharedUri(uri: Uri, flags: Int) {
        persistReadPermission(uri, flags)
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Paylaşılan dosyanın içeriği okunamadı.")
        val name = queryDisplayName(uri) ?: inferNameFromMime(uri)
        pendingSharedDocument = mapOf("name" to name, "bytes" to bytes)
        pendingSharedError = null
        notifySharedDocumentAvailable()
    }

    private fun inferNameFromMime(uri: Uri): String {
        return when (contentResolver.getType(uri)) {
            "application/pdf" -> "paylasilan_belge.pdf"
            "application/msword" -> "paylasilan_belge.doc"
            DOCX_MIME -> "paylasilan_belge.docx"
            "text/plain" -> "paylasilan_metin.txt"
            BACKUP_MIME, "application/x-zip-compressed" -> "yazar_modu_yedek.zip"
            else -> "paylasilan_belge"
        }
    }

    private fun notifySharedDocumentAvailable() {
        methodChannel?.invokeMethod("sharedDocumentAvailable", null)
    }

    private fun extractPdfDocument(call: MethodCall, result: MethodChannel.Result) {
        val bytes = call.arguments as? ByteArray
        if (bytes == null || bytes.isEmpty()) {
            result.error("PDF_BYTES_EMPTY", "PDF dosyasının içeriği alınamadı.", null)
            return
        }

        Thread {
            var tempFile: File? = null
            try {
                val pageTexts = mutableListOf<String>()
                val totalPages = PDDocument.load(bytes).use { document ->
                    val stripper = PDFTextStripper()
                    for (pageIndex in 0 until document.numberOfPages) {
                        stripper.startPage = pageIndex + 1
                        stripper.endPage = pageIndex + 1
                        pageTexts.add(stripper.getText(document).trim())
                    }
                    document.numberOfPages
                }

                tempFile = File.createTempFile("yazar_modu_pdf_", ".pdf", cacheDir)
                tempFile.writeBytes(bytes)
                val previewPageCount = minOf(totalPages, MAX_PDF_PREVIEW_PAGES)
                val pages = mutableListOf<Map<String, Any>>()

                ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        for (pageIndex in 0 until totalPages) {
                            var previewBytes = ByteArray(0)
                            if (pageIndex < previewPageCount) {
                                renderer.openPage(pageIndex).use { page ->
                                    val safeWidth = maxOf(page.width, 1)
                                    val safeHeight = maxOf(page.height, 1)
                                    val targetWidth = PDF_PREVIEW_WIDTH
                                    val targetHeight = ((targetWidth.toDouble() * safeHeight) / safeWidth)
                                        .toInt()
                                        .coerceIn(1, 1800)
                                    val bitmap = Bitmap.createBitmap(
                                        targetWidth,
                                        targetHeight,
                                        Bitmap.Config.ARGB_8888
                                    )
                                    bitmap.eraseColor(Color.WHITE)
                                    page.render(
                                        bitmap,
                                        null,
                                        null,
                                        PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                                    )
                                    if (containsVisualContent(bitmap)) {
                                        val cropped = cropWhiteMargins(bitmap)
                                        val output = ByteArrayOutputStream()
                                        cropped.compress(Bitmap.CompressFormat.JPEG, 86, output)
                                        previewBytes = output.toByteArray()
                                        output.close()
                                        if (cropped !== bitmap) cropped.recycle()
                                    }
                                    bitmap.recycle()
                                }
                            }
                            pages.add(
                                mapOf(
                                    "pageNumber" to pageIndex + 1,
                                    "text" to pageTexts.getOrElse(pageIndex) { "" },
                                    "previewBytes" to previewBytes
                                )
                            )
                        }
                    }
                }

                val payload = mapOf(
                    "pages" to pages,
                    "totalPages" to totalPages,
                    "previewLimited" to (totalPages > previewPageCount)
                )
                runOnUiThread { result.success(payload) }
            } catch (error: Exception) {
                runOnUiThread {
                    result.error(
                        "PDF_READ_FAILED",
                        error.message ?: "PDF metni ve görselleri okunamadı.",
                        null
                    )
                }
            } finally {
                tempFile?.delete()
            }
        }.start()
    }

    private fun createBackup(call: MethodCall, result: MethodChannel.Result) {
        if (!claimSaveSlot(result)) return
        val suggestedName = (call.argument<String>("fileName") ?: "Yazar-Modu-Yedek.zip")
            .ensureExtension("zip")
        Thread {
            try {
                val temp = File.createTempFile("yazar_modu_backup_", ".zip", cacheDir)
                buildBackupZip(temp)
                runOnUiThread { openSavePicker(temp, suggestedName, BACKUP_MIME, result) }
            } catch (error: Exception) {
                releaseSaveSlot()
                runOnUiThread {
                    result.error("BACKUP_FAILED", error.message ?: "Yedek oluşturulamadı.", null)
                }
            }
        }.start()
    }

    private fun restoreBackup(result: MethodChannel.Result) {
        if (pendingDocumentResult != null || pendingRestoreResult != null) {
            result.error("PICKER_BUSY", "Dosya seçme ekranı zaten açık.", null)
            return
        }
        pendingRestoreResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(BACKUP_MIME, "application/x-zip-compressed", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "Yazar Modu yedeğini seçin"), RESTORE_BACKUP_REQUEST)
    }

    private fun exportSection(call: MethodCall, result: MethodChannel.Result) {
        if (!claimSaveSlot(result)) return
        val projectId = call.argument<String>("projectId") ?: ""
        val sectionId = call.argument<String>("sectionId") ?: ""
        val format = call.argument<String>("format")?.lowercase(Locale.ROOT) ?: "pdf"
        Thread {
            try {
                val section = loadSection(projectId, sectionId)
                    ?: throw IllegalArgumentException("Bölüm bulunamadı.")
                val title = displayTitle(section)
                val extension = if (format == "docx") "docx" else "pdf"
                val mime = if (extension == "docx") DOCX_MIME else "application/pdf"
                val bytes = if (extension == "docx") buildDocx(section) else buildPdf(section)
                val temp = File.createTempFile("yazar_modu_section_", ".$extension", cacheDir)
                temp.writeBytes(bytes)
                val suggested = sanitizeFileName(title).ifBlank { "Bolum" }.ensureExtension(extension)
                runOnUiThread { openSavePicker(temp, suggested, mime, result) }
            } catch (error: Exception) {
                releaseSaveSlot()
                runOnUiThread {
                    result.error("SECTION_EXPORT_FAILED", error.message ?: "Bölüm dışa aktarılamadı.", null)
                }
            }
        }.start()
    }

    private fun exportProjectSections(call: MethodCall, result: MethodChannel.Result) {
        if (!claimSaveSlot(result)) return
        val projectId = call.argument<String>("projectId") ?: ""
        val format = call.argument<String>("format")?.lowercase(Locale.ROOT) ?: "both"
        Thread {
            try {
                val project = loadProject(projectId)
                    ?: throw IllegalArgumentException("Kitap projesi bulunamadı.")
                val temp = File.createTempFile("yazar_modu_sections_", ".zip", cacheDir)
                ZipOutputStream(FileOutputStream(temp)).use { zip ->
                    val sections = project.optJSONArray("sections") ?: JSONArray()
                    val sorted = (0 until sections.length())
                        .mapNotNull { sections.optJSONObject(it) }
                        .sortedBy { it.optInt("order", 0) }
                    sorted.forEachIndexed { index, section ->
                        val prefix = (index + 1).toString().padStart(2, '0')
                        val base = "$prefix-${sanitizeFileName(displayTitle(section)).ifBlank { "Bolum" }}"
                        if (format == "pdf" || format == "both") {
                            putZipBytes(zip, "PDF/$base.pdf", buildPdf(section))
                        }
                        if (format == "docx" || format == "both") {
                            putZipBytes(zip, "WORD/$base.docx", buildDocx(section))
                        }
                    }
                    val info = "Yazar Modu bölüm paketi\nKitap: ${project.optString("title", "İsimsiz Kitap")}\nBölüm sayısı: ${sorted.size}\n"
                    putZipBytes(zip, "BILGI.txt", info.toByteArray(Charsets.UTF_8))
                }
                val projectName = sanitizeFileName(project.optString("title", "Yazar-Modu"))
                val suffix = when (format) {
                    "pdf" -> "Bolumler-PDF"
                    "docx" -> "Bolumler-Word"
                    else -> "Bolumler-PDF-Word"
                }
                runOnUiThread {
                    openSavePicker(
                        temp,
                        "$projectName-$suffix.zip",
                        BACKUP_MIME,
                        result
                    )
                }
            } catch (error: Exception) {
                releaseSaveSlot()
                runOnUiThread {
                    result.error("PROJECT_EXPORT_FAILED", error.message ?: "Bölüm paketi oluşturulamadı.", null)
                }
            }
        }.start()
    }

    private fun claimSaveSlot(result: MethodChannel.Result): Boolean {
        if (pendingSaveResult != null || pendingOutputFile != null) {
            result.error("SAVE_BUSY", "Başka bir dosya işlemi devam ediyor.", null)
            return false
        }
        pendingSaveResult = result
        return true
    }

    private fun releaseSaveSlot() {
        pendingSaveResult = null
        pendingOutputFile?.delete()
        pendingOutputFile = null
    }

    private fun openSavePicker(tempFile: File, suggestedName: String, mimeType: String, result: MethodChannel.Result) {
        if (pendingSaveResult !== result) {
            tempFile.delete()
            return
        }
        pendingOutputFile = tempFile
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType
            putExtra(Intent.EXTRA_TITLE, suggestedName)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, SAVE_DOCUMENT_REQUEST)
        } catch (error: Exception) {
            releaseSaveSlot()
            result.error("SAVE_PICKER_FAILED", error.message, null)
        }
    }

    private fun buildBackupZip(output: File) {
        val root = File(filesDir, "yazar_modu")
        ZipOutputStream(FileOutputStream(output)).use { zip ->
            if (root.exists()) {
                root.walkTopDown()
                    .filter { it.isFile && !it.name.endsWith(".tmp") }
                    .forEach { file ->
                        val relative = file.relativeTo(root).invariantSeparatorsPath
                        zip.putNextEntry(ZipEntry(relative))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
            }
            if (!File(root, "projects.json").exists()) {
                putZipBytes(zip, "projects.json", "[]".toByteArray(Charsets.UTF_8))
            }
            putZipBytes(
                zip,
                "YEDEK_BILGISI.txt",
                "Yazar Modu tam proje yedeği. Metinler ve görseller birlikte saklanır.\n".toByteArray(Charsets.UTF_8)
            )
        }
    }

    private fun restoreBackupFromUri(uri: Uri): Int {
        val tempRoot = File(filesDir, "yazar_modu_restore_${System.currentTimeMillis()}")
        tempRoot.mkdirs()
        try {
            var extractedFiles = 0
            contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val output = File(tempRoot, entry.name)
                        val canonicalRoot = tempRoot.canonicalPath + File.separator
                        val canonicalOutput = output.canonicalPath
                        if (!canonicalOutput.startsWith(canonicalRoot)) {
                            throw SecurityException("Geçersiz yedek dosyası yolu.")
                        }
                        if (entry.isDirectory) {
                            output.mkdirs()
                        } else {
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                            extractedFiles++
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: throw IllegalStateException("Yedek dosyası açılamadı.")

            val projectsFile = File(tempRoot, "projects.json")
            if (!projectsFile.exists()) {
                throw IllegalArgumentException("Bu dosya geçerli bir Yazar Modu yedeği değil.")
            }
            JSONArray(projectsFile.readText(Charsets.UTF_8))

            val currentRoot = File(filesDir, "yazar_modu")
            val previousRoot = File(filesDir, "yazar_modu_onceki_${System.currentTimeMillis()}")
            if (currentRoot.exists() && !currentRoot.renameTo(previousRoot)) {
                currentRoot.deleteRecursively()
            }
            if (!tempRoot.renameTo(currentRoot)) {
                currentRoot.mkdirs()
                tempRoot.copyRecursively(currentRoot, overwrite = true)
                tempRoot.deleteRecursively()
            }
            rewriteRestoredImagePaths(currentRoot)
            return extractedFiles
        } catch (error: Exception) {
            tempRoot.deleteRecursively()
            throw error
        }
    }

    private fun rewriteRestoredImagePaths(root: File) {
        val projectsFile = File(root, "projects.json")
        if (!projectsFile.exists()) return
        val projects = JSONArray(projectsFile.readText(Charsets.UTF_8))
        for (projectIndex in 0 until projects.length()) {
            val project = projects.optJSONObject(projectIndex) ?: continue
            val sections = project.optJSONArray("sections") ?: continue
            for (sectionIndex in 0 until sections.length()) {
                val section = sections.optJSONObject(sectionIndex) ?: continue
                val images = section.optJSONArray("images") ?: continue
                for (imageIndex in 0 until images.length()) {
                    val image = images.optJSONObject(imageIndex) ?: continue
                    val oldPath = image.optString("filePath", "")
                    val marker = oldPath.indexOf("/assets/")
                    if (marker >= 0) {
                        image.put("filePath", root.absolutePath + oldPath.substring(marker))
                    } else if (oldPath.isNotBlank()) {
                        val candidate = File(root, "assets/${project.optString("id")}/${File(oldPath).name}")
                        image.put("filePath", candidate.absolutePath)
                    }
                }
            }
        }
        projectsFile.writeText(projects.toString(2), Charsets.UTF_8)
    }

    private fun loadProjectsJson(): JSONArray {
        val file = File(filesDir, "yazar_modu/projects.json")
        if (!file.exists()) throw IllegalStateException("Kayıtlı proje bulunamadı.")
        return JSONArray(file.readText(Charsets.UTF_8))
    }

    private fun loadProject(projectId: String): JSONObject? {
        val projects = loadProjectsJson()
        for (index in 0 until projects.length()) {
            val project = projects.optJSONObject(index) ?: continue
            if (project.optString("id") == projectId) return project
        }
        return null
    }

    private fun loadSection(projectId: String, sectionId: String): JSONObject? {
        val project = loadProject(projectId) ?: return null
        val sections = project.optJSONArray("sections") ?: return null
        for (index in 0 until sections.length()) {
            val section = sections.optJSONObject(index) ?: continue
            if (section.optString("id") == sectionId) return section
        }
        return null
    }

    private fun displayTitle(section: JSONObject): String {
        val mainTitle = section.optString("mainTitle", "").trim()
        val subtitle = section.optString("subtitle", "").trim()
        val rawTitle = section.optString("title", "Bölüm").trim()
        return listOf(mainTitle.ifBlank { rawTitle }, subtitle)
            .filter { it.isNotBlank() }
            .joinToString(" - ")
    }

    private fun buildPdf(section: JSONObject): ByteArray {
        val writer = SectionPdfWriter(section)
        return writer.build()
    }

    private inner class SectionPdfWriter(private val section: JSONObject) {
        private val document = PdfDocument()
        private val pageWidth = 383
        private val pageHeight = 595
        private val marginLeft = 36f
        private val marginRight = 36f
        private val marginTop = 34f
        private val marginBottom = 34f
        private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 11.2f
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 17f
            typeface = Typeface.create("serif", Typeface.BOLD)
        }
        private val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 13f
            typeface = Typeface.create("serif", Typeface.BOLD)
        }
        private val captionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 8.5f
            typeface = Typeface.create("serif", Typeface.ITALIC)
        }
        private var pageNumber = 0
        private var page: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = marginTop

        fun build(): ByteArray {
            startPage()
            val chapterNumber = if (section.has("chapterNumber") && !section.isNull("chapterNumber")) {
                section.optInt("chapterNumber", 0)
            } else 0
            if (chapterNumber > 0) {
                drawCentered("$chapterNumber. BÖLÜM", subtitlePaint, 22f)
                y += 6f
            }
            val mainTitle = section.optString("mainTitle", "").trim()
                .ifBlank { section.optString("title", "Bölüm").trim() }
            drawCentered(mainTitle.uppercase(Locale("tr", "TR")), titlePaint, 24f)
            val subtitle = section.optString("subtitle", "").trim()
            if (subtitle.isNotEmpty()) {
                y += 3f
                drawCentered(subtitle.uppercase(Locale("tr", "TR")), subtitlePaint, 19f)
            }
            y += 14f

            val paragraphs = splitParagraphs(section.optString("content", ""))
            val images = section.optJSONArray("images") ?: JSONArray()
            drawImagesAt(images, 0)
            paragraphs.forEachIndexed { index, paragraph ->
                drawParagraph(paragraph)
                y += 8f
                drawImagesAt(images, index + 1)
            }
            finishPage()
            val output = ByteArrayOutputStream()
            document.writeTo(output)
            document.close()
            return output.toByteArray()
        }

        private fun startPage() {
            pageNumber++
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = document.startPage(info)
            canvas = page!!.canvas
            y = marginTop
        }

        private fun finishPage() {
            val active = page ?: return
            val pagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 8f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("serif", Typeface.NORMAL)
            }
            active.canvas.drawText(pageNumber.toString(), pageWidth / 2f, pageHeight - 16f, pagePaint)
            document.finishPage(active)
            page = null
            canvas = null
        }

        private fun newPage() {
            finishPage()
            startPage()
        }

        private fun ensureSpace(requiredHeight: Float) {
            if (y + requiredHeight > pageHeight - marginBottom) newPage()
        }

        private fun drawCentered(text: String, paint: Paint, lineHeight: Float) {
            val lines = wrapText(text, paint, pageWidth - marginLeft - marginRight)
            ensureSpace(lines.size * lineHeight)
            val oldAlign = paint.textAlign
            paint.textAlign = Paint.Align.CENTER
            for (line in lines) {
                canvas!!.drawText(line, pageWidth / 2f, y + paint.textSize, paint)
                y += lineHeight
            }
            paint.textAlign = oldAlign
        }

        private fun drawParagraph(paragraph: String) {
            val maxWidth = pageWidth - marginLeft - marginRight
            val words = paragraph.replace(Regex("\\s+"), " ").trim().split(" ")
            if (words.isEmpty() || words.first().isEmpty()) return
            var line = ""
            var firstLine = true
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                val indent = if (firstLine) 16f else 0f
                if (bodyPaint.measureText(candidate) <= maxWidth - indent) {
                    line = candidate
                } else {
                    drawBodyLine(line, firstLine)
                    firstLine = false
                    line = word
                }
            }
            if (line.isNotEmpty()) drawBodyLine(line, firstLine)
        }

        private fun drawBodyLine(text: String, firstLine: Boolean) {
            ensureSpace(16.5f)
            val x = marginLeft + if (firstLine) 16f else 0f
            canvas!!.drawText(text, x, y + bodyPaint.textSize, bodyPaint)
            y += 16.5f
        }

        private fun drawImagesAt(images: JSONArray, paragraphIndex: Int) {
            for (index in 0 until images.length()) {
                val image = images.optJSONObject(index) ?: continue
                if (image.optInt("afterParagraph", 0) != paragraphIndex) continue
                drawImage(image)
            }
        }

        private fun drawImage(image: JSONObject) {
            val path = image.optString("filePath", "")
            val bitmap = BitmapFactory.decodeFile(path) ?: return
            try {
                val maxWidth = pageWidth - marginLeft - marginRight
                val maxHeight = (pageHeight - marginTop - marginBottom) * 0.58f
                val scale = minOf(maxWidth / bitmap.width.toFloat(), maxHeight / bitmap.height.toFloat(), 1f)
                val width = bitmap.width * scale
                val height = bitmap.height * scale
                val caption = image.optString("caption", "").trim()
                val required = height + if (caption.isNotEmpty()) 22f else 10f
                ensureSpace(required)
                val left = (pageWidth - width) / 2f
                canvas!!.drawBitmap(bitmap, null, RectF(left, y, left + width, y + height), null)
                y += height + 5f
                if (caption.isNotEmpty()) {
                    val lines = wrapText(caption, captionPaint, maxWidth)
                    for (line in lines) {
                        ensureSpace(12f)
                        captionPaint.textAlign = Paint.Align.CENTER
                        canvas!!.drawText(line, pageWidth / 2f, y + captionPaint.textSize, captionPaint)
                        y += 12f
                    }
                }
                y += 7f
            } finally {
                bitmap.recycle()
            }
        }
    }

    private fun buildDocx(section: JSONObject): ByteArray {
        val imageRelations = mutableListOf<String>()
        val media = mutableListOf<Pair<String, ByteArray>>()
        val documentBody = StringBuilder()
        val chapterNumber = if (section.has("chapterNumber") && !section.isNull("chapterNumber")) {
            section.optInt("chapterNumber", 0)
        } else 0
        if (chapterNumber > 0) {
            documentBody.append(docxParagraph("$chapterNumber. BÖLÜM", true, 26, "center", false))
        }
        val mainTitle = section.optString("mainTitle", "").trim()
            .ifBlank { section.optString("title", "Bölüm").trim() }
        documentBody.append(docxParagraph(mainTitle.uppercase(Locale("tr", "TR")), true, 34, "center", false))
        val subtitle = section.optString("subtitle", "").trim()
        if (subtitle.isNotEmpty()) {
            documentBody.append(docxParagraph(subtitle.uppercase(Locale("tr", "TR")), true, 26, "center", false))
        }

        val paragraphs = splitParagraphs(section.optString("content", ""))
        val images = section.optJSONArray("images") ?: JSONArray()
        appendDocxImages(documentBody, images, 0, media, imageRelations)
        paragraphs.forEachIndexed { index, paragraph ->
            documentBody.append(docxParagraph(paragraph, false, 23, "both", true))
            appendDocxImages(documentBody, images, index + 1, media, imageRelations)
        }
        documentBody.append(
            "<w:sectPr><w:pgSz w:w=\"7654\" w:h=\"11906\"/>" +
                "<w:pgMar w:top=\"1021\" w:right=\"1021\" w:bottom=\"1021\" w:left=\"1134\" w:header=\"425\" w:footer=\"425\" w:gutter=\"0\"/>" +
                "</w:sectPr>"
        )

        val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
 xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
 xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>$documentBody</w:body></w:document>"""

        val relationships = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
            append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            imageRelations.forEach { append(it) }
            append("</Relationships>")
        }

        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zip ->
            putZipBytes(zip, "[Content_Types].xml", contentTypesXml().toByteArray(Charsets.UTF_8))
            putZipBytes(zip, "_rels/.rels", rootRelationshipsXml().toByteArray(Charsets.UTF_8))
            putZipBytes(zip, "word/document.xml", documentXml.toByteArray(Charsets.UTF_8))
            putZipBytes(zip, "word/styles.xml", stylesXml().toByteArray(Charsets.UTF_8))
            putZipBytes(zip, "word/_rels/document.xml.rels", relationships.toByteArray(Charsets.UTF_8))
            media.forEach { (name, bytes) -> putZipBytes(zip, "word/media/$name", bytes) }
        }
        return output.toByteArray()
    }

    private fun appendDocxImages(
        body: StringBuilder,
        images: JSONArray,
        paragraphIndex: Int,
        media: MutableList<Pair<String, ByteArray>>,
        relations: MutableList<String>
    ) {
        for (index in 0 until images.length()) {
            val image = images.optJSONObject(index) ?: continue
            if (image.optInt("afterParagraph", 0) != paragraphIndex) continue
            val bitmap = BitmapFactory.decodeFile(image.optString("filePath", "")) ?: continue
            val bytes = ByteArrayOutputStream().use { output ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
                output.toByteArray()
            }
            val imageNumber = media.size + 1
            val fileName = "image$imageNumber.png"
            val relId = "rId$imageNumber"
            val maxWidth = 4_650_000L
            val maxHeight = 6_000_000L
            val rawWidth = bitmap.width.toLong().coerceAtLeast(1L)
            val rawHeight = bitmap.height.toLong().coerceAtLeast(1L)
            val scale = minOf(maxWidth.toDouble() / (rawWidth * 9525.0), maxHeight.toDouble() / (rawHeight * 9525.0), 1.0)
            val cx = (rawWidth * 9525.0 * scale).roundToInt().toLong().coerceAtLeast(1L)
            val cy = (rawHeight * 9525.0 * scale).roundToInt().toLong().coerceAtLeast(1L)
            bitmap.recycle()
            media.add(fileName to bytes)
            relations.add(
                "<Relationship Id=\"$relId\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$fileName\"/>"
            )
            body.append(docxImageParagraph(relId, imageNumber, cx, cy))
            val caption = image.optString("caption", "").trim()
            if (caption.isNotEmpty()) {
                body.append(docxParagraph(caption, false, 18, "center", false, italic = true))
            }
        }
    }

    private fun docxParagraph(
        text: String,
        bold: Boolean,
        halfPointSize: Int,
        alignment: String,
        firstLineIndent: Boolean,
        italic: Boolean = false
    ): String {
        val formatting = buildString {
            if (bold) append("<w:b/>")
            if (italic) append("<w:i/>")
            append("<w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:cs=\"Times New Roman\"/>")
            append("<w:sz w:val=\"$halfPointSize\"/><w:szCs w:val=\"$halfPointSize\"/>")
        }
        val indent = if (firstLineIndent) "<w:ind w:firstLine=\"425\"/>" else ""
        return "<w:p><w:pPr><w:jc w:val=\"$alignment\"/><w:spacing w:after=\"140\" w:line=\"360\" w:lineRule=\"auto\"/>$indent</w:pPr>" +
            "<w:r><w:rPr>$formatting</w:rPr><w:t xml:space=\"preserve\">${xmlEscape(text)}</w:t></w:r></w:p>"
    }

    private fun docxImageParagraph(relId: String, imageNumber: Int, cx: Long, cy: Long): String {
        return """<w:p><w:pPr><w:jc w:val="center"/><w:spacing w:before="80" w:after="80"/></w:pPr><w:r><w:drawing>
<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$imageNumber" name="Görsel $imageNumber"/>
<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>
<pic:nvPicPr><pic:cNvPr id="$imageNumber" name="Görsel $imageNumber"/><pic:cNvPicPr/></pic:nvPicPr>
<pic:blipFill><a:blip r:embed="$relId"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"""
    }

    private fun contentTypesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

    private fun rootRelationshipsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    private fun stylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="23"/><w:szCs w:val="23"/></w:rPr></w:rPrDefault></w:docDefaults>
</w:styles>"""

    private fun splitParagraphs(content: String): List<String> {
        return content.replace("\r\n", "\n").replace("\r", "\n")
            .split(Regex("\\n\\s*\\n"))
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotEmpty() }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.replace(Regex("\\s+"), " ").trim().split(" ")
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(candidate) <= maxWidth || line.isEmpty()) {
                line = candidate
            } else {
                lines.add(line)
                line = word
            }
        }
        if (line.isNotEmpty()) lines.add(line)
        return lines.ifEmpty { listOf("") }
    }

    private fun xmlEscape(value: String): String {
        return value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun putZipBytes(zip: ZipOutputStream, path: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(bytes)
        zip.closeEntry()
    }

    private fun sanitizeFileName(value: String): String {
        return value.trim()
            .replace(Regex("[\\\\/:*?\"<>|]"), "-")
            .replace(Regex("\\s+"), " ")
            .take(100)
            .trim('.', ' ')
    }

    private fun String.ensureExtension(extension: String): String {
        return if (lowercase(Locale.ROOT).endsWith(".${extension.lowercase(Locale.ROOT)}")) this else "$this.$extension"
    }

    private fun containsVisualContent(bitmap: Bitmap): Boolean {
        val step = 4
        var sampled = 0L
        var nonWhite = 0L
        var colorful = 0L
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val pixel = bitmap.getPixel(x, y)
                val red = Color.red(pixel)
                val green = Color.green(pixel)
                val blue = Color.blue(pixel)
                sampled++
                if (red < 246 || green < 246 || blue < 246) {
                    nonWhite++
                    val maximum = maxOf(red, green, blue)
                    val minimum = minOf(red, green, blue)
                    if (maximum - minimum > 18) colorful++
                }
                x += step
            }
            y += step
        }
        if (sampled == 0L) return false
        val nonWhiteRatio = nonWhite.toDouble() / sampled.toDouble()
        val colorfulRatio = colorful.toDouble() / sampled.toDouble()
        return colorfulRatio > 0.012 || nonWhiteRatio > 0.18
    }

    private fun cropWhiteMargins(source: Bitmap): Bitmap {
        val threshold = 247
        val scanStep = 2
        var left = source.width
        var top = source.height
        var right = -1
        var bottom = -1

        var y = 0
        while (y < source.height) {
            var x = 0
            while (x < source.width) {
                val pixel = source.getPixel(x, y)
                val isWhite = Color.red(pixel) >= threshold &&
                    Color.green(pixel) >= threshold &&
                    Color.blue(pixel) >= threshold
                if (!isWhite) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
                x += scanStep
            }
            y += scanStep
        }

        if (right < left || bottom < top) return source
        val padding = 10
        left = (left - padding).coerceAtLeast(0)
        top = (top - padding).coerceAtLeast(0)
        right = (right + padding).coerceAtMost(source.width - 1)
        bottom = (bottom + padding).coerceAtMost(source.height - 1)
        val width = right - left + 1
        val height = bottom - top + 1
        if (width.toDouble() >= source.width * 0.97 && height.toDouble() >= source.height * 0.97) {
            return source
        }
        if (width < 24 || height < 24) return source
        return Bitmap.createBitmap(source, left, top, width, height)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            OPEN_DOCUMENT_REQUEST -> handleOpenDocumentResult(resultCode, data)
            SAVE_DOCUMENT_REQUEST -> handleSaveDocumentResult(resultCode, data)
            RESTORE_BACKUP_REQUEST -> handleRestoreBackupResult(resultCode, data)
        }
    }

    private fun handleOpenDocumentResult(resultCode: Int, data: Intent?) {
        val result = pendingDocumentResult ?: return
        pendingDocumentResult = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            result.success(null)
            return
        }
        try {
            persistReadPermission(uri, data.flags)
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Dosya içeriği okunamadı.")
            val name = queryDisplayName(uri) ?: inferNameFromMime(uri)
            result.success(mapOf("name" to name, "bytes" to bytes))
        } catch (error: Exception) {
            result.error("FILE_READ_FAILED", error.message, null)
        }
    }

    private fun handleSaveDocumentResult(resultCode: Int, data: Intent?) {
        val result = pendingSaveResult ?: return
        val temp = pendingOutputFile
        pendingSaveResult = null
        pendingOutputFile = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null || temp == null) {
            temp?.delete()
            result.success(null)
            return
        }
        try {
            contentResolver.openOutputStream(uri, "w")?.use { output ->
                FileInputStream(temp).use { it.copyTo(output) }
            } ?: throw IllegalStateException("Seçilen konuma dosya yazılamadı.")
            result.success(uri.toString())
        } catch (error: Exception) {
            result.error("FILE_SAVE_FAILED", error.message, null)
        } finally {
            temp.delete()
        }
    }

    private fun handleRestoreBackupResult(resultCode: Int, data: Intent?) {
        val result = pendingRestoreResult ?: return
        pendingRestoreResult = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            result.success(null)
            return
        }
        Thread {
            try {
                val count = restoreBackupFromUri(uri)
                runOnUiThread { result.success(count) }
            } catch (error: Exception) {
                runOnUiThread {
                    result.error("RESTORE_FAILED", error.message ?: "Yedek geri yüklenemedi.", null)
                }
            }
        }.start()
    }

    private fun persistReadPermission(uri: Uri, flags: Int) {
        val readFlag = flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (readFlag == 0) return
        try {
            contentResolver.takePersistableUriPermission(uri, readFlag)
        } catch (_: SecurityException) {
            // Bazı sağlayıcılar kalıcı izin vermez; tek seferlik izin yeterlidir.
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                return cursor.getString(index)
            }
        }
        return uri.lastPathSegment
    }
}
