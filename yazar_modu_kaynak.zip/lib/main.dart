import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'state/book_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = BookStore();
  await store.initialize();
  runApp(YazarModuApp(store: store));
}

class YazarModuApp extends StatelessWidget {
  const YazarModuApp({required this.store, super.key});

  final BookStore store;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF6E4D32);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Yazar Modu',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.light,
          surface: const Color(0xFFFFFBF3),
        ),
        scaffoldBackgroundColor: const Color(0xFFF6EFE2),
        useMaterial3: true,
        appBarTheme: const AppBarThemeData(
          centerTitle: false,
          backgroundColor: Color(0xFFFFFBF3),
          foregroundColor: Color(0xFF2D2118),
          elevation: 0,
        ),
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          color: Color(0xFFFFFBF3),
        ),
        inputDecorationTheme: const InputDecorationThemeData(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
      home: HomeScreen(store: store),
    );
  }
}
