import 'book_section.dart';

class BookProject {
  const BookProject({
    required this.id,
    required this.title,
    required this.author,
    required this.sections,
    required this.createdAt,
    required this.modifiedAt,
  });

  final String id;
  final String title;
  final String author;
  final List<BookSection> sections;
  final DateTime createdAt;
  final DateTime modifiedAt;

  int get wordCount => sections.fold<int>(0, (sum, section) => sum + section.wordCount);
  int get estimatedPageCount => wordCount == 0 ? 0 : (wordCount / 250).ceil();
  int get imageCount => sections.fold<int>(0, (sum, section) => sum + section.images.length);

  BookProject copyWith({
    String? id,
    String? title,
    String? author,
    List<BookSection>? sections,
    DateTime? createdAt,
    DateTime? modifiedAt,
  }) {
    return BookProject(
      id: id ?? this.id,
      title: title ?? this.title,
      author: author ?? this.author,
      sections: sections ?? this.sections,
      createdAt: createdAt ?? this.createdAt,
      modifiedAt: modifiedAt ?? this.modifiedAt,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'author': author,
        'sections': sections.map((section) => section.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'modifiedAt': modifiedAt.toIso8601String(),
      };

  factory BookProject.fromJson(Map<String, dynamic> json) {
    final rawSections = json['sections'] as List<dynamic>? ?? <dynamic>[];
    return BookProject(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'İsimsiz Kitap',
      author: json['author'] as String? ?? '',
      sections: rawSections
          .map((item) => BookSection.fromJson(Map<String, dynamic>.from(item as Map)))
          .toList()
        ..sort((a, b) => a.order.compareTo(b.order)),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      modifiedAt: DateTime.tryParse(json['modifiedAt'] as String? ?? '') ?? DateTime.now(),
    );
  }
}
