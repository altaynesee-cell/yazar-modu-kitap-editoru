enum SectionKind { frontMatter, chapter, backMatter }

class BookSection {
  const BookSection({
    required this.id,
    required this.title,
    required this.content,
    required this.kind,
    required this.order,
    required this.createdAt,
    required this.modifiedAt,
  });

  final String id;
  final String title;
  final String content;
  final SectionKind kind;
  final int order;
  final DateTime createdAt;
  final DateTime modifiedAt;

  int get wordCount {
    final normalized = content.trim();
    if (normalized.isEmpty) return 0;
    return normalized.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
  }

  BookSection copyWith({
    String? id,
    String? title,
    String? content,
    SectionKind? kind,
    int? order,
    DateTime? createdAt,
    DateTime? modifiedAt,
  }) {
    return BookSection(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      kind: kind ?? this.kind,
      order: order ?? this.order,
      createdAt: createdAt ?? this.createdAt,
      modifiedAt: modifiedAt ?? this.modifiedAt,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'content': content,
        'kind': kind.name,
        'order': order,
        'createdAt': createdAt.toIso8601String(),
        'modifiedAt': modifiedAt.toIso8601String(),
      };

  factory BookSection.fromJson(Map<String, dynamic> json) {
    return BookSection(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'İsimsiz Bölüm',
      content: json['content'] as String? ?? '',
      kind: SectionKind.values.firstWhere(
        (value) => value.name == json['kind'],
        orElse: () => SectionKind.chapter,
      ),
      order: json['order'] as int? ?? 0,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      modifiedAt: DateTime.tryParse(json['modifiedAt'] as String? ?? '') ?? DateTime.now(),
    );
  }
}
