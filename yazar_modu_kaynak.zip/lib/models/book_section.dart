import 'section_image.dart';

enum SectionKind { frontMatter, chapter, backMatter }

class BookSection {
  const BookSection({
    required this.id,
    required this.title,
    required this.content,
    required this.kind,
    required this.order,
    required this.createdAt,
    required this.modifiedAt,
    this.images = const <SectionImage>[],
    this.chapterNumber,
    this.mainTitle = '',
    this.subtitle = '',
    this.lastAiSummary = '',
    this.lastAiEditedAt,
  });

  final String id;
  final String title;
  final String content;
  final SectionKind kind;
  final int order;
  final DateTime createdAt;
  final DateTime modifiedAt;
  final List<SectionImage> images;
  final int? chapterNumber;
  final String mainTitle;
  final String subtitle;
  final String lastAiSummary;
  final DateTime? lastAiEditedAt;

  int get wordCount {
    final normalized = content.trim();
    if (normalized.isEmpty) return 0;
    return normalized.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
  }

  BookSection copyWith({
    String? id,
    String? title,
    String? content,
    SectionKind? kind,
    int? order,
    DateTime? createdAt,
    DateTime? modifiedAt,
    List<SectionImage>? images,
    int? chapterNumber,
    bool clearChapterNumber = false,
    String? mainTitle,
    String? subtitle,
    String? lastAiSummary,
    DateTime? lastAiEditedAt,
  }) {
    return BookSection(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      kind: kind ?? this.kind,
      order: order ?? this.order,
      createdAt: createdAt ?? this.createdAt,
      modifiedAt: modifiedAt ?? this.modifiedAt,
      images: images ?? this.images,
      chapterNumber:
          clearChapterNumber ? null : (chapterNumber ?? this.chapterNumber),
      mainTitle: mainTitle ?? this.mainTitle,
      subtitle: subtitle ?? this.subtitle,
      lastAiSummary: lastAiSummary ?? this.lastAiSummary,
      lastAiEditedAt: lastAiEditedAt ?? this.lastAiEditedAt,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'content': content,
        'kind': kind.name,
        'order': order,
        'createdAt': createdAt.toIso8601String(),
        'modifiedAt': modifiedAt.toIso8601String(),
        'images': images.map((image) => image.toJson()).toList(),
        'chapterNumber': chapterNumber,
        'mainTitle': mainTitle,
        'subtitle': subtitle,
        'lastAiSummary': lastAiSummary,
        'lastAiEditedAt': lastAiEditedAt?.toIso8601String(),
      };

  factory BookSection.fromJson(Map<String, dynamic> json) {
    final rawImages = json['images'] as List<dynamic>? ?? <dynamic>[];
    return BookSection(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'İsimsiz Bölüm',
      content: json['content'] as String? ?? '',
      kind: SectionKind.values.firstWhere(
        (value) => value.name == json['kind'],
        orElse: () => SectionKind.chapter,
      ),
      order: json['order'] as int? ?? 0,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      modifiedAt: DateTime.tryParse(json['modifiedAt'] as String? ?? '') ?? DateTime.now(),
      images: rawImages
          .map((item) => SectionImage.fromJson(Map<String, dynamic>.from(item as Map)))
          .where((image) => image.filePath.isNotEmpty)
          .toList(),
      chapterNumber: json['chapterNumber'] as int?,
      mainTitle: json['mainTitle'] as String? ?? '',
      subtitle: json['subtitle'] as String? ?? '',
      lastAiSummary: json['lastAiSummary'] as String? ?? '',
      lastAiEditedAt: DateTime.tryParse(json['lastAiEditedAt'] as String? ?? ''),
    );
  }
}
