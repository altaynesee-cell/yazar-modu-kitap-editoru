class SectionImage {
  const SectionImage({
    required this.id,
    required this.filePath,
    required this.originalName,
    required this.mimeType,
    required this.afterParagraph,
    this.sourcePage,
    this.caption = '',
  });

  final String id;
  final String filePath;
  final String originalName;
  final String mimeType;

  /// 0: ilk paragraftan önce, 1: ilk paragraftan sonra.
  final int afterParagraph;
  final int? sourcePage;
  final String caption;

  SectionImage copyWith({
    String? id,
    String? filePath,
    String? originalName,
    String? mimeType,
    int? afterParagraph,
    int? sourcePage,
    String? caption,
  }) {
    return SectionImage(
      id: id ?? this.id,
      filePath: filePath ?? this.filePath,
      originalName: originalName ?? this.originalName,
      mimeType: mimeType ?? this.mimeType,
      afterParagraph: afterParagraph ?? this.afterParagraph,
      sourcePage: sourcePage ?? this.sourcePage,
      caption: caption ?? this.caption,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'filePath': filePath,
        'originalName': originalName,
        'mimeType': mimeType,
        'afterParagraph': afterParagraph,
        'sourcePage': sourcePage,
        'caption': caption,
      };

  factory SectionImage.fromJson(Map<String, dynamic> json) {
    return SectionImage(
      id: json['id'] as String? ?? '',
      filePath: json['filePath'] as String? ?? '',
      originalName: json['originalName'] as String? ?? 'Görsel',
      mimeType: json['mimeType'] as String? ?? 'image/jpeg',
      afterParagraph: json['afterParagraph'] as int? ?? 0,
      sourcePage: json['sourcePage'] as int?,
      caption: json['caption'] as String? ?? '',
    );
  }
}
