import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/local_editor_service.dart';

class AiComparisonScreen extends StatefulWidget {
  const AiComparisonScreen({required this.originalText, super.key});

  final String originalText;

  @override
  State<AiComparisonScreen> createState() => _AiComparisonScreenState();
}

class _AiComparisonScreenState extends State<AiComparisonScreen> {
  late final TextEditingController _proposalController;
  LocalEditMode _mode = LocalEditMode.full;
  List<_ComparisonBlock> _blocks = <_ComparisonBlock>[];
  bool _showUnchanged = false;

  @override
  void initState() {
    super.initState();
    _proposalController = TextEditingController(text: widget.originalText);
    _createLocalSuggestion();
  }

  @override
  void dispose() {
    _proposalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final changedCount = _blocks.where((block) => !block.unchanged).length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yapay Zekâ Karşılaştırma'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Harici yapay zekâ sonucunu yapıştır',
            onPressed: _pasteExternalResult,
            icon: const Icon(Icons.content_paste_go),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Material(
              color: const Color(0xFFFFF7E8),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Text(
                      'Metne yeni tarih, kişi veya olay eklenmez. Öneriler asıl metne yalnızca sizin onayınızla uygulanır.',
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<LocalEditMode>(
                      value: _mode,
                      decoration: const InputDecoration(labelText: 'Düzenleme türü'),
                      items: LocalEditMode.values
                          .map(
                            (mode) => DropdownMenuItem<LocalEditMode>(
                              value: mode,
                              child: Text(mode.label),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value == null) return;
                        setState(() => _mode = value);
                      },
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _createLocalSuggestion,
                            icon: const Icon(Icons.auto_fix_high),
                            label: const Text('Akıllı öneri oluştur'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _editProposal,
                            icon: const Icon(Icons.edit_note),
                            label: const Text('Öneriyi düzenle'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: <Widget>[
                        Text('$changedCount değişiklik grubu'),
                        const Spacer(),
                        FilterChip(
                          selected: _showUnchanged,
                          label: const Text('Değişmeyenleri göster'),
                          onSelected: (value) => setState(() => _showUnchanged = value),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: _blocks.isEmpty
                  ? const Center(child: Text('Karşılaştırılacak değişiklik bulunamadı.'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: _blocks.length,
                      itemBuilder: (context, index) {
                        final block = _blocks[index];
                        if (block.unchanged && !_showUnchanged) {
                          return const SizedBox.shrink();
                        }
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _ComparisonCard(
                            block: block,
                            onChanged: block.unchanged
                                ? null
                                : (accepted) => setState(() => block.accepted = accepted),
                          ),
                        );
                      },
                    ),
            ),
            Material(
              elevation: 8,
              color: const Color(0xFFFFFBF3),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => _setAll(false),
                              child: const Text('Tümünü reddet'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => _setAll(true),
                              child: const Text('Tümünü kabul et'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _applySelected,
                          icon: const Icon(Icons.check_circle),
                          label: const Text('Seçilenleri metne uygula'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _createLocalSuggestion() {
    final suggestion = LocalEditorService.createSuggestion(widget.originalText, _mode);
    _proposalController.text = suggestion;
    _rebuildComparison();
  }

  Future<void> _pasteExternalResult() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Panoda yapıştırılacak metin bulunamadı.')),
      );
      return;
    }
    _proposalController.text = text;
    _rebuildComparison();
  }

  Future<void> _editProposal() async {
    final controller = TextEditingController(text: _proposalController.text);
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 14,
          right: 14,
          top: 14,
          bottom: MediaQuery.viewInsetsOf(context).bottom + 14,
        ),
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.72,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text('Önerilen metin', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  expands: true,
                  maxLines: null,
                  minLines: null,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    hintText: 'Harici yapay zekâ sonucunu buraya da yapıştırabilirsiniz.',
                  ),
                ),
              ),
              const SizedBox(height: 10),
              FilledButton(
                onPressed: () => Navigator.pop(context, controller.text),
                child: const Text('Karşılaştır'),
              ),
            ],
          ),
        ),
      ),
    );
    controller.dispose();
    if (result == null) return;
    _proposalController.text = result;
    _rebuildComparison();
  }

  void _rebuildComparison() {
    setState(() {
      _blocks = _buildComparisonBlocks(widget.originalText, _proposalController.text);
    });
  }

  void _setAll(bool accepted) {
    setState(() {
      for (final block in _blocks) {
        if (!block.unchanged) block.accepted = accepted;
      }
    });
  }

  void _applySelected() {
    final parts = <String>[];
    for (final block in _blocks) {
      final selected = block.unchanged
          ? block.oldText
          : (block.accepted ? block.newText : block.oldText);
      if (selected.trim().isNotEmpty) parts.add(selected.trim());
    }
    Navigator.pop(context, parts.join('\n\n').trim());
  }
}

class _ComparisonCard extends StatelessWidget {
  const _ComparisonCard({required this.block, required this.onChanged});

  final _ComparisonBlock block;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    if (block.unchanged) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Row(
                children: <Widget>[
                  Icon(Icons.check, size: 18),
                  SizedBox(width: 6),
                  Text('Değişmedi', style: TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 6),
              Text(block.oldText),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: block.accepted,
              onChanged: onChanged,
              title: Text(block.accepted ? 'Değişiklik kabul edilecek' : 'Eski metin korunacak'),
            ),
            if (block.oldText.trim().isNotEmpty) ...<Widget>[
              const Text('ESKİ METİN', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 5),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFFFFEEEE),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(block.oldText),
                ),
              ),
              const SizedBox(height: 10),
            ],
            if (block.newText.trim().isNotEmpty) ...<Widget>[
              const Text('ÖNERİLEN METİN', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 5),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFFECF8EE),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(block.newText),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ComparisonBlock {
  _ComparisonBlock({
    required this.oldText,
    required this.newText,
    required this.unchanged,
    this.accepted = true,
  });

  final String oldText;
  final String newText;
  final bool unchanged;
  bool accepted;
}

List<_ComparisonBlock> _buildComparisonBlocks(String original, String proposal) {
  final oldParts = _splitParagraphs(original);
  final newParts = _splitParagraphs(proposal);
  final rows = oldParts.length + 1;
  final columns = newParts.length + 1;
  final lcs = List<List<int>>.generate(rows, (_) => List<int>.filled(columns, 0));

  for (var i = oldParts.length - 1; i >= 0; i--) {
    for (var j = newParts.length - 1; j >= 0; j--) {
      if (_sameParagraph(oldParts[i], newParts[j])) {
        lcs[i][j] = lcs[i + 1][j + 1] + 1;
      } else {
        lcs[i][j] = lcs[i + 1][j] >= lcs[i][j + 1]
            ? lcs[i + 1][j]
            : lcs[i][j + 1];
      }
    }
  }

  final blocks = <_ComparisonBlock>[];
  final removed = <String>[];
  final added = <String>[];

  void flushChanged() {
    if (removed.isEmpty && added.isEmpty) return;
    blocks.add(
      _ComparisonBlock(
        oldText: removed.join('\n\n'),
        newText: added.join('\n\n'),
        unchanged: false,
      ),
    );
    removed.clear();
    added.clear();
  }

  var i = 0;
  var j = 0;
  while (i < oldParts.length || j < newParts.length) {
    if (i < oldParts.length && j < newParts.length && _sameParagraph(oldParts[i], newParts[j])) {
      flushChanged();
      blocks.add(
        _ComparisonBlock(
          oldText: oldParts[i],
          newText: newParts[j],
          unchanged: true,
        ),
      );
      i++;
      j++;
    } else if (j < newParts.length &&
        (i == oldParts.length || lcs[i][j + 1] > lcs[i + 1][j])) {
      added.add(newParts[j]);
      j++;
    } else if (i < oldParts.length) {
      removed.add(oldParts[i]);
      i++;
    }
  }
  flushChanged();

  if (blocks.isEmpty && (original.isNotEmpty || proposal.isNotEmpty)) {
    blocks.add(
      _ComparisonBlock(
        oldText: original,
        newText: proposal,
        unchanged: original == proposal,
      ),
    );
  }
  return blocks;
}

List<String> _splitParagraphs(String input) {
  return input
      .replaceAll('\r\n', '\n')
      .replaceAll('\r', '\n')
      .split(RegExp(r'\n\s*\n'))
      .map((paragraph) => paragraph.trim())
      .where((paragraph) => paragraph.isNotEmpty)
      .toList();
}

bool _sameParagraph(String left, String right) {
  String normalize(String value) => value.replaceAll(RegExp(r'\s+'), ' ').trim();
  return normalize(left) == normalize(right);
}
