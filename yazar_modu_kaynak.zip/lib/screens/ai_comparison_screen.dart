import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/bulk_selection_service.dart';
import '../services/local_editor_service.dart';

class AiComparisonResult {
  const AiComparisonResult({required this.text, required this.summary});

  final String text;
  final String summary;
}

class AiComparisonScreen extends StatefulWidget {
  const AiComparisonScreen({required this.originalText, super.key});

  final String originalText;

  @override
  State<AiComparisonScreen> createState() => _AiComparisonScreenState();
}

class _AiComparisonScreenState extends State<AiComparisonScreen> {
  static const double _minimumWordRatio = 0.95;
  static const double _minimumBlockRatio = 0.90;

  late final TextEditingController _proposalController;
  LocalEditMode _mode = LocalEditMode.full;
  List<_ComparisonBlock> _blocks = <_ComparisonBlock>[];
  bool _showUnchanged = false;
  String _bulkSelectionMessage = '';

  @override
  void initState() {
    super.initState();
    _proposalController = TextEditingController(text: widget.originalText);
    _createLocalSuggestion();
  }

  @override
  void dispose() {
    _proposalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final changedBlocks = _blocks.where((block) => !block.unchanged).toList();
    final changedCount = changedBlocks.length;
    final acceptedCount = changedBlocks.where((block) => block.accepted).length;
    final rejectedCount = changedCount - acceptedCount;
    final originalWords = LocalEditorService.wordCount(widget.originalText);
    final proposalWords = LocalEditorService.wordCount(_proposalController.text);
    final selectedText = _buildSelectedText();
    final selectedWords = LocalEditorService.wordCount(selectedText);
    final minimumWords = (originalWords * _minimumWordRatio).ceil();
    final canApply = originalWords == 0 || selectedWords >= minimumWords;
    final protectedCount = changedBlocks.where(_isShorteningRisk).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Yapay Zekâ Karşılaştırma'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Değişiklik özetini göster',
            onPressed: _showChangeSummary,
            icon: const Icon(Icons.fact_check_outlined),
          ),
          IconButton(
            tooltip: 'Harici yapay zekâ sonucunu yapıştır',
            onPressed: _pasteExternalResult,
            icon: const Icon(Icons.content_paste_go),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Material(
              color: const Color(0xFFFFF7E8),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const Text(
                      'Yeni tarih, kişi veya olay eklenmez. Uzunluk koruması açıktır; paragraf silme ve bölümü belirgin biçimde kısaltma engellenir.',
                    ),
                    const SizedBox(height: 8),
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: canApply
                            ? const Color(0xFFEAF6EC)
                            : const Color(0xFFFFE8E5),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          children: <Widget>[
                            Icon(
                              canApply ? Icons.lock_outline : Icons.warning_amber,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                canApply
                                    ? 'Uzunluk koruması: $originalWords → $selectedWords kelime. Metin korunuyor.'
                                    : 'Uyarı: Seçilen sonuç $selectedWords kelime. En az $minimumWords kelime korunmalıdır.',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<LocalEditMode>(
                      value: _mode,
                      decoration: const InputDecoration(labelText: 'Düzenleme türü'),
                      items: LocalEditMode.values
                          .map(
                            (mode) => DropdownMenuItem<LocalEditMode>(
                              value: mode,
                              child: Text(mode.label),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value == null) return;
                        setState(() => _mode = value);
                      },
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _createLocalSuggestion,
                            icon: const Icon(Icons.auto_fix_high),
                            label: const Text('Öneri oluştur'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _editProposal,
                            icon: const Icon(Icons.edit_note),
                            label: const Text('Öneriyi düzenle'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: <Widget>[
                        Text('$changedCount değişiklik grubu'),
                        if (protectedCount > 0)
                          Text('$protectedCount grup kısalmaya karşı korundu'),
                        OutlinedButton.icon(
                          onPressed: _showChangeSummary,
                          icon: const Icon(Icons.summarize_outlined, size: 19),
                          label: const Text('Değişiklik özeti'),
                        ),
                        FilterChip(
                          selected: _showUnchanged,
                          label: const Text('Değişmeyenler'),
                          onSelected: (value) =>
                              setState(() => _showUnchanged = value),
                        ),
                      ],
                    ),
                    Text(
                      'Öneri: $proposalWords kelime · Uygulanacak seçim: $selectedWords kelime',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: _blocks.isEmpty
                  ? const Center(
                      child: Text('Karşılaştırılacak değişiklik bulunamadı.'),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: _blocks.length,
                      itemBuilder: (context, index) {
                        final block = _blocks[index];
                        if (block.unchanged && !_showUnchanged) {
                          return const SizedBox.shrink();
                        }
                        final shorteningRisk = _isShorteningRisk(block);
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _ComparisonCard(
                            block: block,
                            protectedFromShortening: shorteningRisk,
                            onChanged: block.unchanged || shorteningRisk
                                ? null
                                : (accepted) {
                                    setState(() {
                                      block.accepted = accepted;
                                      _bulkSelectionMessage = '';
                                    });
                                  },
                          ),
                        );
                      },
                    ),
            ),
            Material(
              elevation: 8,
              color: const Color(0xFFFFFBF3),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: FilledButton.tonalIcon(
                              key: const ValueKey<String>('reject_all_changes'),
                              onPressed: changedCount == 0
                                  ? null
                                  : () => _setAll(false),
                              icon: const Icon(Icons.close),
                              label: const Text('Tümünü reddet'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              key: const ValueKey<String>('accept_all_changes'),
                              onPressed: changedCount == 0
                                  ? null
                                  : () => _setAll(true),
                              icon: const Icon(Icons.done_all),
                              label: const Text('Tümünü kabul et'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 7),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              'Kabul: $acceptedCount · Ret: $rejectedCount'
                              '${protectedCount > 0 ? ' · Korunan: $protectedCount' : ''}',
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                      if (_bulkSelectionMessage.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 5),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            _bulkSelectionMessage,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      ],
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: canApply ? _applySelected : null,
                          icon: const Icon(Icons.check_circle),
                          label: Text(
                            canApply
                                ? 'Seçilenleri metne uygula'
                                : 'Metin fazla kısaldı — seçimleri düzeltin',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _createLocalSuggestion() {
    final suggestion =
        LocalEditorService.createSuggestion(widget.originalText, _mode);
    _proposalController.text = suggestion;
    _rebuildComparison();
  }

  Future<void> _pasteExternalResult() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Panoda yapıştırılacak metin bulunamadı.')),
      );
      return;
    }
    _proposalController.text = text;
    _rebuildComparison();
  }

  Future<void> _editProposal() async {
    final controller = TextEditingController(text: _proposalController.text);
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 14,
          right: 14,
          top: 14,
          bottom: MediaQuery.viewInsetsOf(context).bottom + 14,
        ),
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.72,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                'Önerilen metin — kısaltmadan',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 6),
              const Text(
                'Harici yapay zekâ sonucu yapıştırılabilir. Bölümün bilgi ve uzunluğunu koruyun.',
              ),
              const SizedBox(height: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  expands: true,
                  maxLines: null,
                  minLines: null,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: const InputDecoration(
                    hintText: 'Düzenlenmiş metni buraya yapıştırın.',
                  ),
                ),
              ),
              const SizedBox(height: 10),
              FilledButton(
                onPressed: () => Navigator.pop(context, controller.text),
                child: const Text('Karşılaştır'),
              ),
            ],
          ),
        ),
      ),
    );
    controller.dispose();
    if (result == null) return;
    _proposalController.text = result;
    _rebuildComparison();
  }

  void _rebuildComparison() {
    final rebuilt =
        _buildComparisonBlocks(widget.originalText, _proposalController.text);
    for (final block in rebuilt) {
      if (_isShorteningRisk(block)) block.accepted = false;
    }
    setState(() {
      _blocks = rebuilt;
      _bulkSelectionMessage = '';
    });
  }

  void _setAll(bool accepted) {
    final result = BulkSelectionService.selectAll(
      accept: accepted,
      items: _blocks
          .map(
            (block) => BulkSelectionItem(
              unchanged: block.unchanged,
              protectedFromShortening: _isShorteningRisk(block),
              accepted: block.accepted,
            ),
          )
          .toList(growable: false),
    );

    final updated = <_ComparisonBlock>[];
    for (var index = 0; index < _blocks.length; index++) {
      updated.add(
        _blocks[index].copyWith(accepted: result.acceptedValues[index]),
      );
    }

    setState(() {
      _blocks = updated;
      _bulkSelectionMessage = accepted
          ? result.protectedCount == 0
              ? '${result.acceptedCount} değişikliğin tamamı kabul edildi. Sonucu kaydetmek için aşağıdaki uygulama düğmesine basın.'
              : '${result.acceptedCount} değişiklik kabul edildi; ${result.protectedCount} kısaltıcı öneri uzunluk koruması nedeniyle reddedildi.'
          : 'Bütün değişiklikler reddedildi; özgün metin korunacak.';
    });

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: const Duration(seconds: 2),
          content: Text(
            accepted
                ? result.protectedCount == 0
                    ? 'Tüm değişiklikler kabul edildi.'
                    : '${result.acceptedCount} değişiklik kabul edildi, ${result.protectedCount} öneri korumaya alındı.'
                : 'Tüm değişiklikler reddedildi.',
          ),
        ),
      );
  }

  bool _isShorteningRisk(_ComparisonBlock block) {
    if (block.unchanged || block.oldText.trim().isEmpty) return false;
    if (block.newText.trim().isEmpty) return true;
    final oldWords = LocalEditorService.wordCount(block.oldText);
    final newWords = LocalEditorService.wordCount(block.newText);
    return oldWords >= 20 && newWords < (oldWords * _minimumBlockRatio).ceil();
  }

  String _selectedTextForBlock(_ComparisonBlock block) {
    if (block.unchanged || !block.accepted) return block.oldText;
    if (_isShorteningRisk(block)) return block.oldText;
    return block.newText;
  }

  String _buildSelectedText() {
    final parts = <String>[];
    for (final block in _blocks) {
      final selected = _selectedTextForBlock(block);
      if (selected.trim().isNotEmpty) parts.add(selected.trim());
    }
    return parts.join('\n\n').trim();
  }

  void _applySelected() {
    final selectedText = _buildSelectedText();
    final originalWords = LocalEditorService.wordCount(widget.originalText);
    final selectedWords = LocalEditorService.wordCount(selectedText);
    final minimumWords = (originalWords * _minimumWordRatio).ceil();
    if (originalWords > 0 && selectedWords < minimumWords) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Metin $selectedWords kelimeye düştü. En az $minimumWords kelime korunmalı.',
          ),
        ),
      );
      return;
    }
    Navigator.pop(
      context,
      AiComparisonResult(
        text: selectedText,
        summary: _buildSummary(selectedText: selectedText),
      ),
    );
  }

  Future<void> _showChangeSummary() async {
    final summary = _buildSummary(selectedText: _buildSelectedText());
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.78,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.summarize_outlined),
                    const SizedBox(width: 8),
                    Text(
                      'Değişiklik özeti',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
                const Divider(),
                Expanded(
                  child: SingleChildScrollView(
                    child: SelectableText(
                      summary,
                      style: const TextStyle(fontSize: 16, height: 1.5),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _buildSummary({required String selectedText}) {
    final originalWords = LocalEditorService.wordCount(widget.originalText);
    final proposalWords = LocalEditorService.wordCount(_proposalController.text);
    final selectedWords = LocalEditorService.wordCount(selectedText);
    final originalParagraphs =
        LocalEditorService.paragraphCount(widget.originalText);
    final selectedParagraphs = LocalEditorService.paragraphCount(selectedText);
    final changed = _blocks.where((block) => !block.unchanged).toList();
    final accepted = changed.where((block) => block.accepted).length;
    final rejected = changed.length - accepted;
    final protected = changed.where(_isShorteningRisk).length;
    final additions = changed
        .where((block) =>
            block.oldText.trim().isEmpty && block.newText.trim().isNotEmpty)
        .length;
    final deletionAttempts = changed
        .where((block) =>
            block.oldText.trim().isNotEmpty && block.newText.trim().isEmpty)
        .length;

    final lines = <String>[
      'GENEL DURUM',
      '• Özgün metin: $originalWords kelime, $originalParagraphs paragraf.',
      '• Yapay zekâ önerisi: $proposalWords kelime.',
      '• Seçimler uygulandığında: $selectedWords kelime, $selectedParagraphs paragraf.',
      '• Kelime farkı: ${_signed(selectedWords - originalWords)}.',
      '• Değişiklik grubu: ${changed.length}; kabul edilen: $accepted; reddedilen: $rejected.',
      if (protected > 0)
        '• $protected değişiklik, metni fazla kısalttığı için otomatik olarak eski hâliyle korundu.',
      if (additions > 0) '• $additions yeni paragraf/alan önerildi.',
      if (deletionAttempts > 0)
        '• $deletionAttempts paragraf silme girişimi engellendi.',
      '',
      'DEĞİŞİKLİKLER',
    ];

    var visibleIndex = 0;
    for (final block in changed) {
      visibleIndex++;
      final oldWords = LocalEditorService.wordCount(block.oldText);
      final newWords = LocalEditorService.wordCount(block.newText);
      final status = _isShorteningRisk(block)
          ? 'fazla kısaldığı için eski metin korundu'
          : !block.accepted
              ? 'reddedildi; eski metin korunacak'
              : 'kabul edilecek';
      lines.add(
        '$visibleIndex. ${_changeType(block)} — $oldWords → $newWords kelime; $status.',
      );
      if (visibleIndex >= 30 && changed.length > 30) {
        lines.add('• Kalan ${changed.length - 30} değişiklik grubu listede gösterilmedi.');
        break;
      }
    }
    if (changed.isEmpty) lines.add('• Metinde anlamlı bir değişiklik bulunmadı.');

    lines.addAll(<String>[
      '',
      'KORUMA KURALI',
      '• Bölümün toplam kelime sayısı özgün metnin yüzde 95’inin altına düşemez.',
      '• Bir değişiklik grubu yüzde 10’dan fazla kısalıyorsa eski paragraf otomatik korunur.',
      '• Böylece 6 sayfalık bir bölümün 4 sayfaya düşürülmesi engellenir.',
    ]);
    return lines.join('\n');
  }

  String _changeType(_ComparisonBlock block) {
    if (block.oldText.trim().isEmpty) return 'Yeni metin eklendi';
    if (block.newText.trim().isEmpty) return 'Metin silme önerildi';
    final oldLetters = _lettersAndNumbers(block.oldText);
    final newLetters = _lettersAndNumbers(block.newText);
    if (oldLetters == newLetters) return 'Yazım, boşluk veya noktalama düzenlendi';
    final oldWords = LocalEditorService.wordCount(block.oldText);
    final newWords = LocalEditorService.wordCount(block.newText);
    if ((oldWords - newWords).abs() <= 3) return 'Anlatım ve cümle yapısı düzenlendi';
    return 'Paragraf yeniden düzenlendi';
  }

  String _lettersAndNumbers(String value) {
    return value.toLowerCase().replaceAll(RegExp(r'[^a-zçğıöşü0-9]+'), '');
  }

  String _signed(int value) => value > 0 ? '+$value kelime' : '$value kelime';
}

class _ComparisonCard extends StatelessWidget {
  const _ComparisonCard({
    required this.block,
    required this.protectedFromShortening,
    required this.onChanged,
  });

  final _ComparisonBlock block;
  final bool protectedFromShortening;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    if (block.unchanged) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Row(
                children: <Widget>[
                  Icon(Icons.check, size: 18),
                  SizedBox(width: 6),
                  Text(
                    'Değişmedi',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(block.oldText),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: block.accepted,
              onChanged: onChanged,
              title: Text(
                block.accepted
                    ? 'Değişiklik seçildi'
                    : 'Eski metin korunacak',
              ),
              subtitle: protectedFromShortening
                  ? const Text(
                      'Bu öneri metni fazla kısalttığı için uygulansa bile eski paragraf korunacak.',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    )
                  : null,
            ),
            if (block.oldText.trim().isNotEmpty) ...<Widget>[
              const Text(
                'ESKİ METİN',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 5),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFFFFEEEE),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(block.oldText),
                ),
              ),
              const SizedBox(height: 10),
            ],
            if (block.newText.trim().isNotEmpty) ...<Widget>[
              const Text(
                'ÖNERİLEN METİN',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 5),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFFECF8EE),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(block.newText),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ComparisonBlock {
  _ComparisonBlock({
    required this.oldText,
    required this.newText,
    required this.unchanged,
    this.accepted = true,
  });

  final String oldText;
  final String newText;
  final bool unchanged;
  bool accepted;

  _ComparisonBlock copyWith({bool? accepted}) {
    return _ComparisonBlock(
      oldText: oldText,
      newText: newText,
      unchanged: unchanged,
      accepted: accepted ?? this.accepted,
    );
  }
}

List<_ComparisonBlock> _buildComparisonBlocks(String original, String proposal) {
  final oldParts = _splitParagraphs(original);
  final newParts = _splitParagraphs(proposal);
  final rows = oldParts.length + 1;
  final columns = newParts.length + 1;
  final lcs =
      List<List<int>>.generate(rows, (_) => List<int>.filled(columns, 0));

  for (var i = oldParts.length - 1; i >= 0; i--) {
    for (var j = newParts.length - 1; j >= 0; j--) {
      if (_sameParagraph(oldParts[i], newParts[j])) {
        lcs[i][j] = lcs[i + 1][j + 1] + 1;
      } else {
        lcs[i][j] = lcs[i + 1][j] >= lcs[i][j + 1]
            ? lcs[i + 1][j]
            : lcs[i][j + 1];
      }
    }
  }

  final blocks = <_ComparisonBlock>[];
  final removed = <String>[];
  final added = <String>[];

  void flushChanged() {
    if (removed.isEmpty && added.isEmpty) return;
    blocks.add(
      _ComparisonBlock(
        oldText: removed.join('\n\n'),
        newText: added.join('\n\n'),
        unchanged: false,
      ),
    );
    removed.clear();
    added.clear();
  }

  var i = 0;
  var j = 0;
  while (i < oldParts.length || j < newParts.length) {
    if (i < oldParts.length &&
        j < newParts.length &&
        _sameParagraph(oldParts[i], newParts[j])) {
      flushChanged();
      blocks.add(
        _ComparisonBlock(
          oldText: oldParts[i],
          newText: newParts[j],
          unchanged: true,
        ),
      );
      i++;
      j++;
    } else if (j < newParts.length &&
        (i == oldParts.length || lcs[i][j + 1] > lcs[i + 1][j])) {
      added.add(newParts[j]);
      j++;
    } else if (i < oldParts.length) {
      removed.add(oldParts[i]);
      i++;
    }
  }
  flushChanged();

  if (blocks.isEmpty && (original.isNotEmpty || proposal.isNotEmpty)) {
    blocks.add(
      _ComparisonBlock(
        oldText: original,
        newText: proposal,
        unchanged: original == proposal,
      ),
    );
  }
  return blocks;
}

List<String> _splitParagraphs(String input) {
  return input
      .replaceAll('\r\n', '\n')
      .replaceAll('\r', '\n')
      .split(RegExp(r'\n\s*\n'))
      .map((paragraph) => paragraph.trim())
      .where((paragraph) => paragraph.isNotEmpty)
      .toList();
}

bool _sameParagraph(String left, String right) {
  String normalize(String value) =>
      value.replaceAll(RegExp(r'\s+'), ' ').trim();
  return normalize(left) == normalize(right);
}
