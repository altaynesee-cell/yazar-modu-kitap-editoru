import 'package:flutter/material.dart';

import '../models/book_project.dart';
import '../services/import_service.dart';
import '../services/native_bridge.dart';
import '../state/book_store.dart';
import 'project_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({required this.store, super.key});

  final BookStore store;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  bool _checkingSharedDocument = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    NativeBridge.setSharedDocumentListener(_checkForSharedDocument);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkForSharedDocument());
  }

  @override
  void dispose() {
    NativeBridge.setSharedDocumentListener(null);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkForSharedDocument();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Yazar Modu', style: TextStyle(fontWeight: FontWeight.w700)),
                Text('Mobil Kitap Editörü', style: TextStyle(fontSize: 12)),
              ],
            ),
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: <Widget>[
                _ActionPanel(store: widget.store),
                const SizedBox(height: 22),
                Row(
                  children: <Widget>[
                    Text(
                      'Kitaplarım',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    Text('${widget.store.projects.length} proje'),
                  ],
                ),
                const SizedBox(height: 12),
                if (widget.store.errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: MaterialBanner(
                      content: Text(widget.store.errorMessage!),
                      actions: const <Widget>[SizedBox.shrink()],
                    ),
                  ),
                if (widget.store.projects.isEmpty)
                  const _EmptyProjects()
                else
                  ...widget.store.projects.map(
                    (project) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _ProjectCard(project: project, store: widget.store),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _checkForSharedDocument() async {
    if (_checkingSharedDocument || !mounted) return;
    _checkingSharedDocument = true;
    try {
      final imported = await ImportService.consumeSharedDocument();
      if (imported == null || !mounted) return;
      await _handleSharedDocument(imported);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Paylaşılan belge açılamadı: $error')),
      );
    } finally {
      _checkingSharedDocument = false;
    }
  }

  Future<void> _handleSharedDocument(ImportedDocument imported) async {
    final destination = await showModalBottomSheet<_SharedDestination>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: <Widget>[
            ListTile(
              title: const Text('Paylaşılan belge alındı', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(imported.fileName),
            ),
            ListTile(
              leading: const Icon(Icons.add_box_outlined),
              title: const Text('Yeni kitap oluştur'),
              onTap: () => Navigator.pop(context, const _SharedDestination.newProject()),
            ),
            ...widget.store.projects.map(
              (project) => ListTile(
                leading: const Icon(Icons.menu_book_outlined),
                title: Text(project.title),
                subtitle: const Text('Bu kitabın bölümlerine ekle'),
                onTap: () => Navigator.pop(context, _SharedDestination.existing(project.id)),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (destination == null || !mounted) return;

    if (destination.projectId == null) {
      final suggestedTitle = imported.fileName.replaceFirst(RegExp(r'\.[^.]+$'), '');
      final metadata = await _showMetadataDialog(
        context,
        title: 'Paylaşılan belgeden kitap oluştur',
        initialTitle: suggestedTitle,
      );
      if (metadata == null || !mounted) return;
      final project = await widget.store.createProjectFromImportedDocument(
        title: metadata.title,
        author: metadata.author,
        document: imported,
      );
      if (!mounted) return;
      if (imported.warning != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(imported.warning!)),
        );
      }
      _openProject(context, project);
      return;
    }

    final split = await _askSplitMode(context);
    if (split == null || !mounted) return;
    final sections = await widget.store.addImportedDocument(
      destination.projectId!,
      document: imported,
      splitIntoSections: split,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(imported.warning ?? '${sections.length} bölüm ve ${imported.images.length} görsel eklendi.')),
    );
    final project = widget.store.projectById(destination.projectId!);
    if (project != null) _openProject(context, project);
  }

  Future<bool?> _askSplitMode(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Belge nasıl eklensin?'),
        content: const Text('Belgeyi tek bölüm olarak veya başlıkları algılayarak birkaç bölüme ayırabilirsiniz.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          OutlinedButton(onPressed: () => Navigator.pop(context, false), child: const Text('Tek bölüm')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Bölümlere ayır')),
        ],
      ),
    );
  }

  void _openProject(BuildContext context, BookProject project) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ProjectScreen(store: widget.store, projectId: project.id),
      ),
    );
  }
}

class _ActionPanel extends StatelessWidget {
  const _ActionPanel({required this.store});

  final BookStore store;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              'Kitabınıza başlayın',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const Text('Yeni proje oluşturun, metni yapıştırın veya TXT, Word DOCX ve PDF dosyası yükleyin.'),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => _createEmpty(context),
              icon: const Icon(Icons.add),
              label: const Text('Yeni Kitap Oluştur'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _pasteText(context),
              icon: const Icon(Icons.content_paste),
              label: const Text('Metin Yapıştır'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _importFile(context),
              icon: const Icon(Icons.upload_file),
              label: const Text('TXT, Word DOCX veya PDF Yükle'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _createEmpty(BuildContext context) async {
    final metadata = await _showMetadataDialog(context, title: 'Yeni kitap');
    if (metadata == null || !context.mounted) return;
    final project = await store.createProject(title: metadata.title, author: metadata.author);
    if (!context.mounted) return;
    _openProject(context, project);
  }

  Future<void> _pasteText(BuildContext context) async {
    final data = await _showPasteDialog(context);
    if (data == null || !context.mounted) return;
    final project = await store.createProject(
      title: data.title,
      author: data.author,
      initialText: data.text,
    );
    if (!context.mounted) return;
    _openProject(context, project);
  }

  Future<void> _importFile(BuildContext context) async {
    try {
      final imported = await ImportService.pickDocument();
      if (imported == null || !context.mounted) return;
      final suggestedTitle = imported.fileName.replaceFirst(RegExp(r'\.[^.]+$'), '');
      final metadata = await _showMetadataDialog(
        context,
        title: 'Dosyadan kitap oluştur',
        initialTitle: suggestedTitle,
      );
      if (metadata == null || !context.mounted) return;
      final project = await store.createProjectFromImportedDocument(
        title: metadata.title,
        author: metadata.author,
        document: imported,
      );
      if (!context.mounted) return;
      if (imported.warning != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(imported.warning!)),
        );
      }
      _openProject(context, project);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dosya yüklenemedi: $error')),
      );
    }
  }

  void _openProject(BuildContext context, BookProject project) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ProjectScreen(store: store, projectId: project.id),
      ),
    );
  }
}

class _SharedDestination {
  const _SharedDestination.newProject() : projectId = null;
  const _SharedDestination.existing(this.projectId);

  final String? projectId;
}

class _ProjectCard extends StatelessWidget {
  const _ProjectCard({required this.project, required this.store});

  final BookProject project;
  final BookStore store;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ProjectScreen(store: store, projectId: project.id),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: 62,
                height: 86,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFFE9D9C4),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFF8C6A4B)),
                ),
                child: const Icon(Icons.menu_book, size: 34),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(project.title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    if (project.author.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 3),
                      Text(project.author),
                    ],
                    const SizedBox(height: 10),
                    Text('${project.sections.length} bölüm • ${project.wordCount} kelime${project.imageCount == 0 ? "" : " • ${project.imageCount} görsel"}'),
                    Text('Yaklaşık ${project.estimatedPageCount} sayfa'),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (value) async {
                  if (value == 'delete') {
                    final approved = await _confirmDelete(context, project.title);
                    if (approved) await store.deleteProject(project.id);
                  }
                },
                itemBuilder: (_) => const <PopupMenuEntry<String>>[
                  PopupMenuItem<String>(value: 'delete', child: Text('Projeyi sil')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyProjects extends StatelessWidget {
  const _EmptyProjects();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 36),
        child: Column(
          children: <Widget>[
            Icon(Icons.library_books_outlined, size: 54, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            const Text('Henüz kitap projesi yok.', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text('Yukarıdaki seçeneklerden biriyle ilk kitabınızı oluşturun.'),
          ],
        ),
      ),
    );
  }
}

Future<_Metadata?> _showMetadataDialog(
  BuildContext context, {
  required String title,
  String initialTitle = '',
}) async {
  final titleController = TextEditingController(text: initialTitle);
  final authorController = TextEditingController();
  return showDialog<_Metadata>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(
              controller: titleController,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Kitap adı'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: authorController,
              decoration: const InputDecoration(labelText: 'Yazar adı'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            _Metadata(title: titleController.text, author: authorController.text),
          ),
          child: const Text('Oluştur'),
        ),
      ],
    ),
  );
}

Future<_PasteData?> _showPasteDialog(BuildContext context) async {
  final titleController = TextEditingController();
  final authorController = TextEditingController();
  final textController = TextEditingController();
  return showDialog<_PasteData>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Metin yapıştır'),
      content: SizedBox(
        width: 540,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Kitap adı')),
              const SizedBox(height: 10),
              TextField(controller: authorController, decoration: const InputDecoration(labelText: 'Yazar adı')),
              const SizedBox(height: 10),
              TextField(
                controller: textController,
                minLines: 10,
                maxLines: 16,
                decoration: const InputDecoration(
                  labelText: 'Kitap metni',
                  alignLabelWithHint: true,
                  hintText: 'Ön Söz, Giriş, 1. Bölüm gibi başlıklar otomatik algılanır.',
                ),
              ),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
        FilledButton(
          onPressed: () {
            if (textController.text.trim().isEmpty) return;
            Navigator.pop(
              context,
              _PasteData(
                title: titleController.text,
                author: authorController.text,
                text: textController.text,
              ),
            );
          },
          child: const Text('Bölümlere Ayır'),
        ),
      ],
    ),
  );
}

Future<bool> _confirmDelete(BuildContext context, String title) async {
  return await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Projeyi sil'),
          content: Text('“$title” cihazdan silinecek. Bu işlem geri alınamaz.'),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sil')),
          ],
        ),
      ) ??
      false;
}

class _Metadata {
  const _Metadata({required this.title, required this.author});
  final String title;
  final String author;
}

class _PasteData extends _Metadata {
  const _PasteData({required super.title, required super.author, required this.text});
  final String text;
}
