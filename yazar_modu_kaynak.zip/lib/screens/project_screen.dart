import 'package:flutter/material.dart';

import '../models/book_project.dart';
import '../models/book_section.dart';
import '../services/import_service.dart';
import '../services/native_bridge.dart';
import '../state/book_store.dart';
import '../widgets/stat_card.dart';
import 'section_editor_screen.dart';

class ProjectScreen extends StatefulWidget {
  const ProjectScreen({required this.store, required this.projectId, super.key});

  final BookStore store;
  final String projectId;

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (context, _) {
        final project = widget.store.projectById(widget.projectId);
        if (project == null) {
          return const Scaffold(body: Center(child: Text('Proje bulunamadı.')));
        }
        final pages = <Widget>[
          _SectionsTab(project: project, store: widget.store),
          _StatusTab(project: project),
          _MissingTab(project: project),
        ];
        return Scaffold(
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(project.title, overflow: TextOverflow.ellipsis),
                Text(
                  project.author.isEmpty ? 'Yazar belirtilmedi' : project.author,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                ),
              ],
            ),
            actions: <Widget>[
              PopupMenuButton<_ProjectAction>(
                tooltip: 'Dışa aktar',
                icon: const Icon(Icons.ios_share_outlined),
                onSelected: (action) => _handleProjectAction(context, project, action),
                itemBuilder: (context) => const <PopupMenuEntry<_ProjectAction>>[
                  PopupMenuItem<_ProjectAction>(
                    value: _ProjectAction.separatePdf,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.picture_as_pdf_outlined),
                      title: Text('Bölümleri ayrı PDF yap'),
                      subtitle: Text('Her bölüm kendi görselleriyle ayrı PDF olur.'),
                    ),
                  ),
                  PopupMenuItem<_ProjectAction>(
                    value: _ProjectAction.separateDocx,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.description_outlined),
                      title: Text('Bölümleri ayrı Word yap'),
                      subtitle: Text('Her bölüm kendi görselleriyle ayrı DOCX olur.'),
                    ),
                  ),
                  PopupMenuItem<_ProjectAction>(
                    value: _ProjectAction.separateBoth,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.folder_zip_outlined),
                      title: Text('PDF ve Word paketini oluştur'),
                      subtitle: Text('Ayrı bölüm dosyalarını tek ZIP içinde verir.'),
                    ),
                  ),
                ],
              ),
            ],
          ),
          body: pages[_index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: _index,
            onDestinationSelected: (value) => setState(() => _index = value),
            destinations: const <NavigationDestination>[
              NavigationDestination(icon: Icon(Icons.format_list_numbered), label: 'Bölümler'),
              NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Durum'),
              NavigationDestination(icon: Icon(Icons.rule_folder_outlined), label: 'Eksikler'),
            ],
          ),
          floatingActionButton: _index == 0
              ? FloatingActionButton.extended(
                  onPressed: () => _showAddSectionMenu(context, project),
                  icon: const Icon(Icons.add),
                  label: const Text('Bölüm Ekle'),
                )
              : null,
        );
      },
    );
  }

  Future<void> _handleProjectAction(
    BuildContext context,
    BookProject project,
    _ProjectAction action,
  ) async {
    final format = switch (action) {
      _ProjectAction.separatePdf => 'pdf',
      _ProjectAction.separateDocx => 'docx',
      _ProjectAction.separateBoth => 'both',
    };
    try {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bölümler görselleriyle hazırlanıyor…')),
      );
      final saved = await NativeBridge.exportProjectSections(
        projectId: project.id,
        format: format,
      );
      if (!context.mounted || !saved) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bölüm paketi seçtiğiniz klasöre kaydedildi.')),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dışa aktarım tamamlanamadı: $error')),
      );
    }
  }

  Future<void> _showAddSectionMenu(
    BuildContext context,
    BookProject project,
  ) async {
    final action = await showModalBottomSheet<_AddSectionAction>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const ListTile(
              title: Text('Bölüm ekle', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('Boş bölüm oluşturun veya Word, PDF ve TXT belgesi ekleyin.'),
            ),
            ListTile(
              leading: const Icon(Icons.note_add_outlined),
              title: const Text('Boş bölüm oluştur'),
              onTap: () => Navigator.pop(context, _AddSectionAction.blank),
            ),
            ListTile(
              leading: const Icon(Icons.upload_file),
              title: const Text('Word, PDF veya TXT ekle'),
              subtitle: const Text('Belgeyi tek bölüm olarak ekler.'),
              onTap: () => Navigator.pop(context, _AddSectionAction.importSingle),
            ),
            ListTile(
              leading: const Icon(Icons.account_tree_outlined),
              title: const Text('Belgeyi bölümlere ayırarak ekle'),
              subtitle: const Text('Ön Söz, Giriş ve bölüm başlıklarını otomatik algılar.'),
              onTap: () => Navigator.pop(context, _AddSectionAction.importSplit),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (action == null || !context.mounted) return;

    if (action == _AddSectionAction.blank) {
      await _addBlankSection(context, project);
      return;
    }
    await _importIntoProject(
      context,
      project,
      splitIntoSections: action == _AddSectionAction.importSplit,
    );
  }

  Future<void> _addBlankSection(
    BuildContext context,
    BookProject project,
  ) async {
    final controller = TextEditingController(
      text: '${project.sections.length + 1}. Bölüm',
    );
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yeni bölüm'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Başlık'),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Ekle')),
        ],
      ),
    );
    controller.dispose();
    if (title == null || !context.mounted) return;
    final section = await widget.store.addSection(project.id, title: title);
    if (section != null && context.mounted) {
      _openEditor(context, project.id, section.id);
    }
  }

  Future<void> _importIntoProject(
    BuildContext context,
    BookProject project, {
    required bool splitIntoSections,
  }) async {
    try {
      final imported = await ImportService.pickDocument();
      if (imported == null || !context.mounted) return;
      final sections = await widget.store.addImportedDocument(
        project.id,
        document: imported,
        splitIntoSections: splitIntoSections,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            imported.warning ??
                (splitIntoSections
                    ? '${sections.length} bölüm ve ${imported.images.length} görsel eklendi.'
                    : 'Belge yeni bölüm olarak eklendi. ${imported.images.length} görsel aktarıldı.'),
          ),
        ),
      );
      if (!splitIntoSections && sections.isNotEmpty) {
        _openEditor(context, project.id, sections.first.id);
      }
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Belge eklenemedi: $error')),
      );
    }
  }

  void _openEditor(BuildContext context, String projectId, String sectionId) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SectionEditorScreen(
          store: widget.store,
          projectId: projectId,
          sectionId: sectionId,
        ),
      ),
    );
  }
}

enum _ProjectAction { separatePdf, separateDocx, separateBoth }

enum _AddSectionAction { blank, importSingle, importSplit }

class _SectionsTab extends StatelessWidget {
  const _SectionsTab({required this.project, required this.store});

  final BookProject project;
  final BookStore store;

  @override
  Widget build(BuildContext context) {
    return ReorderableListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
      itemCount: project.sections.length,
      onReorder: (oldIndex, newIndex) => store.reorderSections(project.id, oldIndex, newIndex),
      proxyDecorator: (child, index, animation) => Material(
        elevation: 4,
        borderRadius: BorderRadius.circular(12),
        child: child,
      ),
      itemBuilder: (context, index) {
        final section = project.sections[index];
        return Padding(
          key: ValueKey(section.id),
          padding: const EdgeInsets.only(bottom: 8),
          child: Card(
            child: ListTile(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => SectionEditorScreen(
                    store: store,
                    projectId: project.id,
                    sectionId: section.id,
                  ),
                ),
              ),
              leading: CircleAvatar(child: Text('${index + 1}')),
              title: Text(section.title, maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text('${_kindLabel(section.kind)} • ${section.wordCount} kelime${section.images.isEmpty ? "" : " • ${section.images.length} görsel"}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  PopupMenuButton<String>(
                    onSelected: (value) => _handleAction(context, value, section, index),
                    itemBuilder: (_) => <PopupMenuEntry<String>>[
                      const PopupMenuItem<String>(
                        value: 'exportPdf',
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(Icons.picture_as_pdf_outlined),
                          title: Text('Bu bölümü PDF yap'),
                        ),
                      ),
                      const PopupMenuItem<String>(
                        value: 'exportDocx',
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(Icons.description_outlined),
                          title: Text('Bu bölümü Word yap'),
                        ),
                      ),
                      if (index > 0)
                        const PopupMenuItem<String>(value: 'merge', child: Text('Önceki bölümle birleştir')),
                      const PopupMenuItem<String>(value: 'delete', child: Text('Bölümü sil')),
                    ],
                  ),
                  const Icon(Icons.drag_handle),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _handleAction(BuildContext context, String value, BookSection section, int index) async {
    if (value == 'exportPdf' || value == 'exportDocx') {
      await _exportSection(context, section, value == 'exportDocx' ? 'docx' : 'pdf');
      return;
    }
    if (value == 'merge' && index > 0) {
      final approved = await _confirm(
        context,
        'Bölümleri birleştir',
        '“${section.title}” içeriği önceki bölümün sonuna eklenecek.',
      );
      if (approved) await store.mergeWithPrevious(project.id, section.id);
    }
    if (value == 'delete') {
      if (project.sections.length <= 1) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Kitapta en az bir bölüm bulunmalıdır.')),
          );
        }
        return;
      }
      final approved = await _confirm(
        context,
        'Bölümü sil',
        '“${section.title}” içindeki metin ve görseller silinecek.',
      );
      if (approved) await store.deleteSection(project.id, section.id);
    }
  }

  Future<void> _exportSection(
    BuildContext context,
    BookSection section,
    String format,
  ) async {
    try {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${format == 'docx' ? 'Word' : 'PDF'} dosyası hazırlanıyor…')),
      );
      final saved = await NativeBridge.exportSection(
        projectId: project.id,
        sectionId: section.id,
        format: format,
      );
      if (!context.mounted || !saved) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bölüm, metni ve görselleriyle kaydedildi.')),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bölüm dışa aktarılamadı: $error')),
      );
    }
  }

  String _kindLabel(SectionKind kind) => switch (kind) {
        SectionKind.frontMatter => 'Ön bölüm',
        SectionKind.chapter => 'Ana bölüm',
        SectionKind.backMatter => 'Son bölüm',
      };
}

class _StatusTab extends StatelessWidget {
  const _StatusTab({required this.project});

  final BookProject project;

  @override
  Widget build(BuildContext context) {
    final empty = project.sections.where((section) => section.content.trim().isEmpty && section.images.isEmpty).length;
    final short = project.sections.where((section) => section.wordCount > 0 && section.wordCount < 80).length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Text('Proje Durumu', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: <Widget>[
            StatCard(label: 'Bölüm', value: '${project.sections.length}', icon: Icons.view_list_outlined),
            StatCard(label: 'Kelime', value: '${project.wordCount}', icon: Icons.text_fields),
            StatCard(label: 'Tahmini sayfa', value: '${project.estimatedPageCount}', icon: Icons.menu_book_outlined),
            StatCard(label: 'Görsel', value: '${project.imageCount}', icon: Icons.image_outlined),
            StatCard(label: 'Boş bölüm', value: '$empty', icon: Icons.inbox_outlined),
            StatCard(label: 'Kısa bölüm', value: '$short', icon: Icons.short_text),
          ],
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('Otomatik kayıt', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('Metin değişiklikleri cihazın uygulama klasörüne otomatik kaydedilir.'),
                const SizedBox(height: 10),
                Text('Son kayıt: ${_formatDate(project.modifiedAt)}'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _MissingTab extends StatelessWidget {
  const _MissingTab({required this.project});

  final BookProject project;

  @override
  Widget build(BuildContext context) {
    final issues = _issues(project);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: <Widget>[
        Text('Eksikler ve Uyarılar', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        if (issues.isEmpty)
          const Card(
            child: ListTile(
              leading: Icon(Icons.check_circle_outline),
              title: Text('Temel kontrolde sorun bulunmadı.'),
            ),
          )
        else
          ...issues.map(
            (issue) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  leading: Icon(issue.icon),
                  title: Text(issue.title),
                  subtitle: Text(issue.detail),
                ),
              ),
            ),
          ),
      ],
    );
  }

  List<_Issue> _issues(BookProject project) {
    final result = <_Issue>[];
    final seen = <String>{};
    for (final section in project.sections) {
      if (section.content.trim().isEmpty && section.images.isEmpty) {
        result.add(_Issue(Icons.inbox_outlined, 'Boş bölüm', '“${section.title}” içinde metin bulunmuyor.'));
      } else if (section.wordCount < 80) {
        result.add(_Issue(Icons.short_text, 'Çok kısa bölüm', '“${section.title}” yalnızca ${section.wordCount} kelime.'));
      }
      final normalized = section.title.trim().toLowerCase();
      if (!seen.add(normalized)) {
        result.add(_Issue(Icons.copy_all_outlined, 'Tekrarlanan başlık', '“${section.title}” başlığı birden fazla kez kullanılmış.'));
      }
    }
    if (project.author.trim().isEmpty) {
      result.add(const _Issue(Icons.person_outline, 'Yazar adı eksik', 'Proje bilgilerinde yazar adı bulunmuyor.'));
    }
    return result;
  }
}

class _Issue {
  const _Issue(this.icon, this.title, this.detail);
  final IconData icon;
  final String title;
  final String detail;
}

Future<bool> _confirm(BuildContext context, String title, String detail) async {
  return await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: Text(detail),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Onayla')),
          ],
        ),
      ) ??
      false;
}

String _formatDate(DateTime date) {
  final day = date.day.toString().padLeft(2, '0');
  final month = date.month.toString().padLeft(2, '0');
  final hour = date.hour.toString().padLeft(2, '0');
  final minute = date.minute.toString().padLeft(2, '0');
  return '$day.$month.${date.year} $hour:$minute';
}
