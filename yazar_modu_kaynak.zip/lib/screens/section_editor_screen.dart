import 'dart:async';

import 'package:flutter/material.dart';

import '../models/book_section.dart';
import '../state/book_store.dart';
import 'ai_comparison_screen.dart';

class SectionEditorScreen extends StatefulWidget {
  const SectionEditorScreen({
    required this.store,
    required this.projectId,
    required this.sectionId,
    super.key,
  });

  final BookStore store;
  final String projectId;
  final String sectionId;

  @override
  State<SectionEditorScreen> createState() => _SectionEditorScreenState();
}

class _SectionEditorScreenState extends State<SectionEditorScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _contentController;
  late SectionKind _kind;
  Timer? _saveTimer;
  bool _saving = false;
  bool _dirty = false;

  BookSection? get _currentSection {
    final project = widget.store.projectById(widget.projectId);
    if (project == null) return null;
    for (final section in project.sections) {
      if (section.id == widget.sectionId) return section;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final section = _currentSection;
    _titleController = TextEditingController(text: section?.title ?? 'Bölüm');
    _contentController = TextEditingController(text: section?.content ?? '');
    _kind = section?.kind ?? SectionKind.chapter;
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final words = _wordCount(_contentController.text);
    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () async {
              await _saveNow();
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back),
          ),
          title: const Text('Bölüm Editörü'),
          actions: <Widget>[
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text(_saving ? 'Kaydediliyor…' : (_dirty ? 'Değişti' : 'Kaydedildi')),
              ),
            ),
            IconButton(
              tooltip: 'Yapay zekâ karşılaştırma editörü',
              onPressed: _openComparisonEditor,
              icon: const Icon(Icons.auto_fix_high),
            ),
          ],
        ),
        body: Column(
          children: <Widget>[
            Material(
              color: const Color(0xFFFFFBF3),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                child: Column(
                  children: <Widget>[
                    TextField(
                      controller: _titleController,
                      onChanged: (_) => _scheduleSave(),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                      decoration: const InputDecoration(labelText: 'Bölüm başlığı'),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<SectionKind>(
                      value: _kind,
                      decoration: const InputDecoration(labelText: 'Bölüm türü'),
                      items: const <DropdownMenuItem<SectionKind>>[
                        DropdownMenuItem(value: SectionKind.frontMatter, child: Text('Ön bölüm — numarasız')),
                        DropdownMenuItem(value: SectionKind.chapter, child: Text('Ana bölüm')),
                        DropdownMenuItem(value: SectionKind.backMatter, child: Text('Son bölüm — numarasız')),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        setState(() => _kind = value);
                        _scheduleSave();
                      },
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: TextField(
                  controller: _contentController,
                  onChanged: (_) {
                    setState(() {});
                    _scheduleSave();
                  },
                  expands: true,
                  maxLines: null,
                  minLines: null,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.multiline,
                  style: const TextStyle(fontSize: 17, height: 1.55),
                  decoration: const InputDecoration(
                    hintText: 'Bölüm metnini buraya yazın…',
                    alignLabelWithHint: true,
                    contentPadding: EdgeInsets.all(18),
                  ),
                ),
              ),
            ),
            Material(
              color: const Color(0xFFFFFBF3),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Text('$words kelime'),
                      const Spacer(),
                      Text('Yaklaşık ${words == 0 ? 0 : (words / 250).ceil()} sayfa'),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  Future<void> _openComparisonEditor() async {
    await _saveNow();
    if (!mounted) return;
    final revised = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) => AiComparisonScreen(originalText: _contentController.text),
      ),
    );
    if (revised == null || !mounted || revised == _contentController.text) return;
    _contentController.text = revised;
    _contentController.selection = TextSelection.collapsed(offset: revised.length);
    setState(() {});
    _scheduleSave();
  }

  void _scheduleSave() {
    _dirty = true;
    if (mounted) setState(() {});
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _saveNow);
  }

  Future<void> _saveNow() async {
    _saveTimer?.cancel();
    if (!_dirty) return;
    final old = _currentSection;
    if (old == null) return;
    if (mounted) setState(() => _saving = true);
    await widget.store.updateSection(
      widget.projectId,
      old.copyWith(
        title: _titleController.text.trim().isEmpty ? 'İsimsiz Bölüm' : _titleController.text.trim(),
        content: _contentController.text,
        kind: _kind,
        modifiedAt: DateTime.now(),
      ),
    );
    _dirty = false;
    if (mounted) setState(() => _saving = false);
  }

  int _wordCount(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed.split(RegExp(r'\s+')).where((word) => word.isNotEmpty).length;
  }
}
