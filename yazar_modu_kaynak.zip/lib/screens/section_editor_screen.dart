import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../models/book_section.dart';
import '../models/section_image.dart';
import '../state/book_store.dart';
import 'ai_comparison_screen.dart';

class SectionEditorScreen extends StatefulWidget {
  const SectionEditorScreen({
    required this.store,
    required this.projectId,
    required this.sectionId,
    super.key,
  });

  final BookStore store;
  final String projectId;
  final String sectionId;

  @override
  State<SectionEditorScreen> createState() => _SectionEditorScreenState();
}

enum _EditorMode { edit, preview }

class _SectionEditorScreenState extends State<SectionEditorScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _contentController;
  late SectionKind _kind;
  late _EditorMode _mode;
  Timer? _saveTimer;
  bool _saving = false;
  bool _dirty = false;

  BookSection? get _currentSection {
    final project = widget.store.projectById(widget.projectId);
    if (project == null) return null;
    for (final section in project.sections) {
      if (section.id == widget.sectionId) return section;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final section = _currentSection;
    _titleController = TextEditingController(text: section?.title ?? 'Bölüm');
    _contentController = TextEditingController(text: section?.content ?? '');
    _kind = section?.kind ?? SectionKind.chapter;
    _mode = section?.images.isNotEmpty == true
        ? _EditorMode.preview
        : _EditorMode.edit;
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final section = _currentSection;
    final images = section?.images ?? const <SectionImage>[];
    final words = _wordCount(_contentController.text);
    return WillPopScope(
      onWillPop: () async {
        await _saveNow();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () async {
              await _saveNow();
              if (context.mounted) Navigator.pop(context);
            },
            icon: const Icon(Icons.arrow_back),
          ),
          title: const Text('Bölüm Editörü'),
          actions: <Widget>[
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text(
                  _saving
                      ? 'Kaydediliyor…'
                      : (_dirty ? 'Değişti' : 'Kaydedildi'),
                ),
              ),
            ),
            IconButton(
              tooltip: 'Yapay zekâ karşılaştırma editörü',
              onPressed: _openComparisonEditor,
              icon: const Icon(Icons.auto_fix_high),
            ),
          ],
        ),
        body: Column(
          children: <Widget>[
            Material(
              color: const Color(0xFFFFFBF3),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                child: Column(
                  children: <Widget>[
                    TextField(
                      controller: _titleController,
                      onChanged: (_) => _scheduleSave(),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                      decoration:
                          const InputDecoration(labelText: 'Bölüm başlığı'),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<SectionKind>(
                      value: _kind,
                      decoration:
                          const InputDecoration(labelText: 'Bölüm türü'),
                      items: const <DropdownMenuItem<SectionKind>>[
                        DropdownMenuItem(
                          value: SectionKind.frontMatter,
                          child: Text('Ön bölüm — numarasız'),
                        ),
                        DropdownMenuItem(
                          value: SectionKind.chapter,
                          child: Text('Ana bölüm'),
                        ),
                        DropdownMenuItem(
                          value: SectionKind.backMatter,
                          child: Text('Son bölüm — numarasız'),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        setState(() => _kind = value);
                        _scheduleSave();
                      },
                    ),
                    if (images.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: SegmentedButton<_EditorMode>(
                          segments: <ButtonSegment<_EditorMode>>[
                            const ButtonSegment<_EditorMode>(
                              value: _EditorMode.edit,
                              icon: Icon(Icons.edit_outlined),
                              label: Text('Metni düzenle'),
                            ),
                            ButtonSegment<_EditorMode>(
                              value: _EditorMode.preview,
                              icon: const Icon(Icons.image_outlined),
                              label: Text('Belge görünümü (${images.length})'),
                            ),
                          ],
                          selected: <_EditorMode>{_mode},
                          onSelectionChanged: (selection) {
                            setState(() => _mode = selection.first);
                          },
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            Expanded(
              child: _mode == _EditorMode.edit || images.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(14),
                      child: TextField(
                        controller: _contentController,
                        onChanged: (_) {
                          setState(() {});
                          _scheduleSave();
                        },
                        expands: true,
                        maxLines: null,
                        minLines: null,
                        textAlignVertical: TextAlignVertical.top,
                        keyboardType: TextInputType.multiline,
                        style: const TextStyle(fontSize: 17, height: 1.55),
                        decoration: const InputDecoration(
                          hintText: 'Bölüm metnini buraya yazın…',
                          alignLabelWithHint: true,
                          contentPadding: EdgeInsets.all(18),
                        ),
                      ),
                    )
                  : _SectionDocumentPreview(
                      title: _titleController.text,
                      content: _contentController.text,
                      images: images,
                    ),
            ),
            Material(
              color: const Color(0xFFFFFBF3),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Text('$words kelime'),
                      if (images.isNotEmpty) ...<Widget>[
                        const SizedBox(width: 14),
                        Text('${images.length} görsel'),
                      ],
                      const Spacer(),
                      Text(
                        'Yaklaşık ${words == 0 ? 0 : (words / 250).ceil()} sayfa',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openComparisonEditor() async {
    await _saveNow();
    if (!mounted) return;
    final revised = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) =>
            AiComparisonScreen(originalText: _contentController.text),
      ),
    );
    if (revised == null ||
        !mounted ||
        revised == _contentController.text) {
      return;
    }
    _contentController.text = revised;
    _contentController.selection =
        TextSelection.collapsed(offset: revised.length);
    setState(() {});
    _scheduleSave();
  }

  void _scheduleSave() {
    _dirty = true;
    if (mounted) setState(() {});
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 700), _saveNow);
  }

  Future<void> _saveNow() async {
    _saveTimer?.cancel();
    if (!_dirty) return;
    final old = _currentSection;
    if (old == null) return;
    if (mounted) setState(() => _saving = true);
    await widget.store.updateSection(
      widget.projectId,
      old.copyWith(
        title: _titleController.text.trim().isEmpty
            ? 'İsimsiz Bölüm'
            : _titleController.text.trim(),
        content: _contentController.text,
        kind: _kind,
        modifiedAt: DateTime.now(),
      ),
    );
    _dirty = false;
    if (mounted) setState(() => _saving = false);
  }

  int _wordCount(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .length;
  }
}

class _SectionDocumentPreview extends StatelessWidget {
  const _SectionDocumentPreview({
    required this.title,
    required this.content,
    required this.images,
  });

  final String title;
  final String content;
  final List<SectionImage> images;

  @override
  Widget build(BuildContext context) {
    final paragraphs = content.trim().isEmpty
        ? <String>[]
        : content
            .trim()
            .split(RegExp(r'\n\s*\n'))
            .map((paragraph) => paragraph.trim())
            .where((paragraph) => paragraph.isNotEmpty)
            .toList();
    final imagesByPosition = <int, List<SectionImage>>{};
    for (final image in images) {
      final position = image.afterParagraph.clamp(0, paragraphs.length).toInt();
      imagesByPosition.putIfAbsent(position, () => <SectionImage>[]).add(image);
    }

    final children = <Widget>[
      Text(
        title,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontFamily: 'serif',
              fontWeight: FontWeight.w700,
            ),
      ),
      const SizedBox(height: 22),
    ];

    for (var position = 0; position <= paragraphs.length; position++) {
      for (final image in imagesByPosition[position] ?? const <SectionImage>[]) {
        children.add(_ImportedImageView(image: image));
        children.add(const SizedBox(height: 20));
      }
      if (position < paragraphs.length) {
        final paragraph = paragraphs[position];
        final headingLevel = paragraph.startsWith('## ')
            ? 2
            : (paragraph.startsWith('# ') ? 1 : 0);
        final visibleText = headingLevel == 2
            ? paragraph.substring(3).trim()
            : (headingLevel == 1 ? paragraph.substring(2).trim() : paragraph);
        children.add(
          Text(
            visibleText,
            textAlign: headingLevel == 0 ? TextAlign.justify : TextAlign.left,
            style: headingLevel == 0
                ? const TextStyle(
                    fontFamily: 'serif',
                    fontSize: 17,
                    height: 1.55,
                    color: Color(0xFF2D2118),
                  )
                : TextStyle(
                    fontFamily: 'serif',
                    fontSize: headingLevel == 1 ? 22 : 19,
                    height: 1.3,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF2D2118),
                  ),
          ),
        );
        children.add(SizedBox(height: headingLevel == 0 ? 15 : 18));
      }
    }

    return ColoredBox(
      color: const Color(0xFFE8DED0),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
        children: <Widget>[
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Container(
                padding: const EdgeInsets.fromLTRB(24, 30, 24, 36),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFBF3),
                  borderRadius: BorderRadius.circular(4),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                      blurRadius: 12,
                      offset: Offset(0, 4),
                      color: Color(0x33000000),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: children,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ImportedImageView extends StatelessWidget {
  const _ImportedImageView({required this.image});

  final SectionImage image;

  @override
  Widget build(BuildContext context) {
    final file = File(image.filePath);
    final label = image.caption.trim().isNotEmpty
        ? image.caption.trim()
        : image.sourcePage == null
            ? ''
            : 'PDF sayfa ${image.sourcePage}';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        InkWell(
          onTap: file.existsSync()
              ? () => _showFullImage(context, file, label)
              : null,
          child: Container(
            constraints: const BoxConstraints(minHeight: 120, maxHeight: 680),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: const Color(0xFFD1C3B4)),
              borderRadius: BorderRadius.circular(4),
            ),
            clipBehavior: Clip.antiAlias,
            child: file.existsSync()
                ? Image.file(
                    file,
                    width: double.infinity,
                    fit: BoxFit.contain,
                    filterQuality: FilterQuality.medium,
                    errorBuilder: (_, error, __) => _ImageProblem(
                      text:
                          'Bu görsel biçimi telefonda gösterilemiyor: ${image.originalName}',
                    ),
                  )
                : _ImageProblem(
                    text: 'Görsel dosyası bulunamadı: ${image.originalName}',
                  ),
          ),
        ),
        if (label.isNotEmpty) ...<Widget>[
          const SizedBox(height: 7),
          Text(
            label,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontStyle: FontStyle.italic,
                  color: const Color(0xFF665548),
                ),
          ),
        ],
      ],
    );
  }

  void _showFullImage(BuildContext context, File file, String label) {
    showDialog<void>(
      context: context,
      builder: (context) => Dialog.fullscreen(
        child: Scaffold(
          appBar: AppBar(
            title: Text(label.isEmpty ? image.originalName : label),
            leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.close),
            ),
          ),
          body: ColoredBox(
            color: Colors.black,
            child: Center(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 5,
                child: Image.file(
                  file,
                  fit: BoxFit.contain,
                  errorBuilder: (_, error, __) => const _ImageProblem(
                    text: 'Görsel açılamadı.',
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ImageProblem extends StatelessWidget {
  const _ImageProblem({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(22),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const Icon(Icons.broken_image_outlined, size: 42),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
