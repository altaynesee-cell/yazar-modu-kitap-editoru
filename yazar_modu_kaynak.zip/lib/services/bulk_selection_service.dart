class BulkSelectionItem {
  const BulkSelectionItem({
    required this.unchanged,
    required this.protectedFromShortening,
    required this.accepted,
  });

  final bool unchanged;
  final bool protectedFromShortening;
  final bool accepted;
}

class BulkSelectionResult {
  const BulkSelectionResult({
    required this.acceptedValues,
    required this.acceptedCount,
    required this.rejectedCount,
    required this.protectedCount,
  });

  final List<bool> acceptedValues;
  final int acceptedCount;
  final int rejectedCount;
  final int protectedCount;
}

class BulkSelectionService {
  const BulkSelectionService._();

  /// Toplu kabul/reddet kararını arayüzden bağımsız ve deterministik üretir.
  /// Değişmeyen blokların mevcut durumu korunur. Metni fazla kısaltan bloklar
  /// "tümünü kabul" işleminde bile reddedilerek özgün metin korunur.
  static BulkSelectionResult selectAll({
    required List<BulkSelectionItem> items,
    required bool accept,
  }) {
    final values = <bool>[];
    var acceptedCount = 0;
    var rejectedCount = 0;
    var protectedCount = 0;

    for (final item in items) {
      if (item.unchanged) {
        values.add(item.accepted);
        continue;
      }

      final accepted = accept && !item.protectedFromShortening;
      values.add(accepted);
      if (accepted) {
        acceptedCount++;
      } else {
        rejectedCount++;
      }
      if (accept && item.protectedFromShortening) protectedCount++;
    }

    return BulkSelectionResult(
      acceptedValues: List<bool>.unmodifiable(values),
      acceptedCount: acceptedCount,
      rejectedCount: rejectedCount,
      protectedCount: protectedCount,
    );
  }
}
