import '../models/book_section.dart';

class ChapterParser {
  ChapterParser._();

  static final RegExp _chapterNumberFirst = RegExp(
    r'^(\d{1,3})\s*[.)-]?\s*BÖLÜM(?:\s*[-:–—]\s*(.+))?$',
    caseSensitive: false,
  );
  static final RegExp _chapterWordFirst = RegExp(
    r'^BÖLÜM\s*(\d{1,3})(?:\s*[-:–—]\s*(.+))?$',
    caseSensitive: false,
  );
  static final RegExp _markdownHeading = RegExp(r'^#\s+(.+)$');

  static const Map<String, int> _ordinalNumbers = <String, int>{
    'BİRİNCİ': 1,
    'İKİNCİ': 2,
    'ÜÇÜNCÜ': 3,
    'DÖRDÜNCÜ': 4,
    'BEŞİNCİ': 5,
    'ALTINCI': 6,
    'YEDİNCİ': 7,
    'SEKİZİNCİ': 8,
    'DOKUZUNCU': 9,
    'ONUNCU': 10,
    'ON BİRİNCİ': 11,
    'ON İKİNCİ': 12,
    'ON ÜÇÜNCÜ': 13,
    'ON DÖRDÜNCÜ': 14,
    'ON BEŞİNCİ': 15,
    'ON ALTINCI': 16,
    'ON YEDİNCİ': 17,
    'ON SEKİZİNCİ': 18,
    'ON DOKUZUNCU': 19,
    'YİRMİNCİ': 20,
  };

  static List<BookSection> parse(String rawText) {
    final text = rawText.replaceAll('\r\n', '\n').replaceAll('\r', '\n').trim();
    if (text.isEmpty) return <BookSection>[_emptyFirstChapter()];

    final lines = text.split('\n');
    final sections = <BookSection>[];
    var currentTitle = '1. Bölüm';
    var currentKind = SectionKind.chapter;
    int? currentChapterNumber = 1;
    var currentMainTitle = '';
    var currentSubtitle = '';
    final body = StringBuffer();
    var foundHeading = false;

    void flush() {
      final content = body.toString().trim();
      if (!foundHeading && content.isEmpty) return;
      sections.add(
        BookSection(
          id: _id('section'),
          title: currentTitle.trim().isEmpty ? 'İsimsiz Bölüm' : currentTitle.trim(),
          content: content,
          kind: currentKind,
          order: sections.length,
          createdAt: DateTime.now(),
          modifiedAt: DateTime.now(),
          chapterNumber: currentChapterNumber,
          mainTitle: currentMainTitle,
          subtitle: currentSubtitle,
        ),
      );
      body.clear();
    }

    for (var index = 0; index < lines.length; index++) {
      final line = lines[index].trim();
      final detected = _detectHeading(line);
      if (detected == null) {
        body.writeln(lines[index].trimRight());
        continue;
      }

      if (foundHeading || body.toString().trim().isNotEmpty) flush();
      foundHeading = true;
      currentKind = detected.kind;
      currentChapterNumber = detected.chapterNumber;
      currentMainTitle = detected.mainTitle;
      currentSubtitle = '';

      if (currentKind == SectionKind.chapter) {
        if (currentMainTitle.isEmpty && index + 1 < lines.length) {
          final next = lines[index + 1].trim();
          if (_looksLikeStandaloneTitle(next)) {
            currentMainTitle = next;
            index++;
          }
        }
        if (index + 1 < lines.length) {
          final next = lines[index + 1].trim();
          if (_looksLikeSubtitle(next)) {
            currentSubtitle = _normalizeSubtitle(next);
            index++;
          }
        }
        currentTitle = _composeChapterTitle(
          currentChapterNumber,
          currentMainTitle,
        );
      } else {
        currentMainTitle = detected.mainTitle;
        currentTitle = currentMainTitle;
      }
    }

    flush();

    if (sections.isEmpty) {
      return <BookSection>[_emptyFirstChapter().copyWith(content: text)];
    }
    return List<BookSection>.generate(
      sections.length,
      (index) => sections[index].copyWith(order: index),
    );
  }

  static _DetectedHeading? _detectHeading(String line) {
    if (line.isEmpty) return null;
    final normalized = _normalize(line);

    final special = _specialKind(normalized);
    if (special != null) {
      return _DetectedHeading(
        kind: special,
        mainTitle: _titleCaseSpecial(normalized),
      );
    }

    final numberFirst = _chapterNumberFirst.firstMatch(line);
    if (numberFirst != null) {
      return _DetectedHeading(
        kind: SectionKind.chapter,
        chapterNumber: int.tryParse(numberFirst.group(1) ?? ''),
        mainTitle: (numberFirst.group(2) ?? '').trim(),
      );
    }

    final wordFirst = _chapterWordFirst.firstMatch(line);
    if (wordFirst != null) {
      return _DetectedHeading(
        kind: SectionKind.chapter,
        chapterNumber: int.tryParse(wordFirst.group(1) ?? ''),
        mainTitle: (wordFirst.group(2) ?? '').trim(),
      );
    }

    for (final entry in _ordinalNumbers.entries) {
      final pattern = RegExp(
        '^${RegExp.escape(entry.key)}\\s+BÖLÜM(?:\\s*[-:–—]\\s*(.+))?\$',
        caseSensitive: false,
      );
      final match = pattern.firstMatch(normalized);
      if (match != null) {
        return _DetectedHeading(
          kind: SectionKind.chapter,
          chapterNumber: entry.value,
          mainTitle: (match.group(1) ?? '').trim(),
        );
      }
    }

    final markdown = _markdownHeading.firstMatch(line);
    if (markdown != null) {
      final title = markdown.group(1)!.trim();
      return _DetectedHeading(
        kind: _specialKind(_normalize(title)) ?? SectionKind.chapter,
        mainTitle: title,
      );
    }
    return null;
  }

  static String _normalizeSubtitle(String value) {
    return value.replaceAllMapped(
      RegExp(r'TANRININ', caseSensitive: false),
      (_) => 'TANRI’NIN',
    );
  }

  static String _composeChapterTitle(int? number, String mainTitle) {
    final label = number == null ? 'Bölüm' : '$number. Bölüm';
    return mainTitle.trim().isEmpty ? label : '$label — ${mainTitle.trim()}';
  }

  static SectionKind? _specialKind(String normalized) {
    const front = <String>{
      'ÖN SÖZ',
      'ÖNSÖZ',
      'GİRİŞ',
      'İÇİNDEKİLER',
      'İÇ KAPAK',
      'TELİF SAYFASI',
    };
    const back = <String>{
      'SON SÖZ',
      'SONSÖZ',
      'KAYNAKÇA',
      'EKLER',
      'GÖRSEL KAYNAKLARI',
      'YAZAR HAKKINDA',
    };
    if (front.contains(normalized)) return SectionKind.frontMatter;
    if (back.contains(normalized)) return SectionKind.backMatter;
    return null;
  }

  static String _titleCaseSpecial(String normalized) {
    const titles = <String, String>{
      'ÖN SÖZ': 'Ön Söz',
      'ÖNSÖZ': 'Ön Söz',
      'GİRİŞ': 'Giriş',
      'İÇİNDEKİLER': 'İçindekiler',
      'İÇ KAPAK': 'İç Kapak',
      'TELİF SAYFASI': 'Telif Sayfası',
      'SON SÖZ': 'Son Söz',
      'SONSÖZ': 'Son Söz',
      'KAYNAKÇA': 'Kaynakça',
      'EKLER': 'Ekler',
      'GÖRSEL KAYNAKLARI': 'Görsel Kaynakları',
      'YAZAR HAKKINDA': 'Yazar Hakkında',
    };
    return titles[normalized] ?? normalized;
  }

  static bool _looksLikeStandaloneTitle(String line) {
    if (line.isEmpty || line.length > 110 || _detectHeading(line) != null) {
      return false;
    }
    if (RegExp(r'[.!?]$').hasMatch(line)) return false;
    final words = line.split(RegExp(r'\s+'));
    if (words.length > 12) return false;
    final letters = line.replaceAll(RegExp(r'[^A-Za-zÇĞİÖŞÜçğıöşü]'), '');
    return letters.length >= 3;
  }

  static bool _looksLikeSubtitle(String line) {
    if (line.isEmpty || line.length > 180 || _detectHeading(line) != null) {
      return false;
    }
    if (RegExp(r'[.!?]$').hasMatch(line)) return false;
    final words = line.split(RegExp(r'\s+'));
    if (words.length > 20) return false;
    var letters = 0;
    var uppercase = 0;
    for (final rune in line.runes) {
      final character = String.fromCharCode(rune);
      if (RegExp(r'[A-ZÇĞİÖŞÜ]').hasMatch(character)) {
        letters++;
        uppercase++;
      } else if (RegExp(r'[a-zçğıöşü]').hasMatch(character)) {
        letters++;
      }
    }
    return letters >= 4 && uppercase / letters >= 0.72;
  }

  static String _normalize(String value) => value.trim().toUpperCase();

  static BookSection _emptyFirstChapter() {
    final now = DateTime.now();
    return BookSection(
      id: _id('section'),
      title: '1. Bölüm',
      content: '',
      kind: SectionKind.chapter,
      order: 0,
      createdAt: now,
      modifiedAt: now,
      chapterNumber: 1,
    );
  }

  static String _id(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}';
}

class _DetectedHeading {
  const _DetectedHeading({
    required this.kind,
    required this.mainTitle,
    this.chapterNumber,
  });

  final SectionKind kind;
  final int? chapterNumber;
  final String mainTitle;
}
