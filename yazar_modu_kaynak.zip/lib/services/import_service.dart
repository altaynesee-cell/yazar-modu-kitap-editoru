import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:xml/xml.dart';

class ImportedDocument {
  const ImportedDocument({required this.fileName, required this.text});

  final String fileName;
  final String text;
}

class ImportService {
  ImportService._();

  static Future<ImportedDocument?> pickDocument() async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: <String>['txt', 'docx'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;

    final selected = result.files.single;
    final bytes = selected.bytes ??
        (selected.path == null ? null : await File(selected.path!).readAsBytes());
    if (bytes == null) {
      throw FileSystemException('Dosya verisi okunamadı.');
    }

    final extension = (selected.extension ?? '').toLowerCase();
    final text = switch (extension) {
      'txt' => _decodeText(bytes),
      'docx' => _decodeDocx(bytes),
      _ => throw const FormatException('Bu dosya türü henüz desteklenmiyor.'),
    };
    return ImportedDocument(fileName: selected.name, text: text);
  }

  static String _decodeText(Uint8List bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }

  static String _decodeDocx(Uint8List bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    ArchiveFile? documentFile;
    for (final file in archive) {
      if (file.name == 'word/document.xml' || file.fullPathName == 'word/document.xml') {
        documentFile = file;
        break;
      }
    }
    if (documentFile == null) {
      throw const FormatException('DOCX içinde word/document.xml bulunamadı.');
    }

    final xmlBytes = documentFile.readBytes();
    if (xmlBytes == null) {
      throw const FormatException('DOCX metni çözülemedi.');
    }

    final document = XmlDocument.parse(utf8.decode(xmlBytes));
    final output = StringBuffer();

    for (final paragraph in document.findAllElements('p')) {
      final text = paragraph
          .findAllElements('t')
          .map((node) => node.innerText)
          .join()
          .trim();
      if (text.isEmpty) {
        output.writeln();
        continue;
      }

      XmlElement? styleElement;
      for (final candidate in paragraph.findAllElements('pStyle')) {
        styleElement = candidate;
        break;
      }
      final style = styleElement == null ? '' : _attributeByLocalName(styleElement, 'val');
      final normalizedStyle = style.toLowerCase();
      if (normalizedStyle.contains('heading1') ||
          normalizedStyle.contains('başlık1') ||
          normalizedStyle.contains('title')) {
        output.writeln('# $text');
      } else if (normalizedStyle.contains('heading2') ||
          normalizedStyle.contains('başlık2')) {
        output.writeln('## $text');
      } else {
        output.writeln(text);
      }
    }

    return output.toString().trim();
  }

  static String _attributeByLocalName(XmlElement element, String localName) {
    for (final attribute in element.attributes) {
      if (attribute.name.local == localName) return attribute.value;
    }
    return '';
  }
}
