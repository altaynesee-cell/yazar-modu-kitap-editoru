import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'native_bridge.dart';

class ImportedDocument {
  const ImportedDocument({required this.fileName, required this.text});

  final String fileName;
  final String text;
}

class ImportService {
  ImportService._();

  static Future<ImportedDocument?> pickDocument() async {
    final selected = await NativeBridge.pickDocument();
    if (selected == null) return null;

    final extension = _extensionOf(selected.name);
    final text = switch (extension) {
      'txt' => _decodeText(selected.bytes),
      'docx' => _decodeDocx(selected.bytes),
      'pdf' => await _decodePdf(selected.bytes),
      'doc' => throw const FormatException(
          'Eski Word .doc biçimi henüz desteklenmiyor. Dosyayı .docx olarak kaydedip yeniden seçin.',
        ),
      _ => throw const FormatException(
          'Yalnızca TXT, Word DOCX ve PDF dosyaları destekleniyor.',
        ),
    };

    return ImportedDocument(fileName: selected.name, text: text);
  }

  static String _extensionOf(String fileName) {
    final dotIndex = fileName.lastIndexOf('.');
    if (dotIndex < 0 || dotIndex == fileName.length - 1) return '';
    return fileName.substring(dotIndex + 1).toLowerCase();
  }


  static Future<String> _decodePdf(Uint8List bytes) async {
    final text = (await NativeBridge.extractPdfText(bytes)).trim();
    if (text.isEmpty) {
      throw const FormatException(
        'PDF içinde seçilebilir metin bulunamadı. Dosya taranmış görüntüyse OCR desteği gerekir.',
      );
    }
    return text;
  }

  static String _decodeText(Uint8List bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }

  static String _decodeDocx(Uint8List bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final ArchiveFile? documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) {
      throw const FormatException('DOCX içinde word/document.xml bulunamadı.');
    }

    final xmlBytes = documentFile.readBytes();
    if (xmlBytes == null) {
      throw const FormatException('DOCX metni çözülemedi.');
    }

    final document = XmlDocument.parse(utf8.decode(xmlBytes));
    final output = StringBuffer();

    for (final paragraph in document.findAllElements('p')) {
      final text = paragraph
          .findAllElements('t')
          .map((node) => node.innerText)
          .join()
          .trim();
      if (text.isEmpty) {
        output.writeln();
        continue;
      }

      XmlElement? styleElement;
      for (final candidate in paragraph.findAllElements('pStyle')) {
        styleElement = candidate;
        break;
      }
      final style = styleElement == null
          ? ''
          : _attributeByLocalName(styleElement, 'val');
      final normalizedStyle = style.toLowerCase();
      if (normalizedStyle.contains('heading1') ||
          normalizedStyle.contains('başlık1') ||
          normalizedStyle.contains('title')) {
        output.writeln('# $text');
      } else if (normalizedStyle.contains('heading2') ||
          normalizedStyle.contains('başlık2')) {
        output.writeln('## $text');
      } else {
        output.writeln(text);
      }
    }

    return output.toString().trim();
  }

  static String _attributeByLocalName(XmlElement element, String localName) {
    for (final attribute in element.attributes) {
      if (attribute.name.local == localName) return attribute.value;
    }
    return '';
  }
}
