import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'native_bridge.dart';

class ImportedDocument {
  const ImportedDocument({required this.fileName, required this.text});

  final String fileName;
  final String text;
}

class ImportService {
  ImportService._();

  static Future<ImportedDocument?> pickDocument() async {
    final selected = await NativeBridge.pickDocument();
    if (selected == null) return null;
    return decodeDocument(selected);
  }

  static Future<ImportedDocument?> consumeSharedDocument() async {
    final selected = await NativeBridge.consumeSharedDocument();
    if (selected == null) return null;
    return decodeDocument(selected);
  }

  static Future<ImportedDocument> decodeDocument(
    NativePickedDocument selected,
  ) async {
    final extension = _extensionOf(selected.name);
    final text = switch (extension) {
      'txt' => _decodeText(selected.bytes),
      'docx' => _decodeDocx(selected.bytes),
      'pdf' => await _decodePdf(selected.bytes),
      'doc' => throw const FormatException(
          'Eski Word .doc biçimi desteklenmiyor. Word içinde “Farklı Kaydet” ile DOCX olarak kaydedip yeniden seçin.',
        ),
      _ => throw const FormatException(
          'Yalnızca TXT, Word DOCX ve PDF dosyaları destekleniyor.',
        ),
    };

    if (text.trim().isEmpty) {
      throw const FormatException('Belgenin içinde aktarılabilecek metin bulunamadı.');
    }
    return ImportedDocument(fileName: selected.name, text: text.trim());
  }

  static String _extensionOf(String fileName) {
    final cleanName = fileName.split('?').first;
    final dotIndex = cleanName.lastIndexOf('.');
    if (dotIndex < 0 || dotIndex == cleanName.length - 1) return '';
    return cleanName.substring(dotIndex + 1).toLowerCase();
  }

  static Future<String> _decodePdf(Uint8List bytes) async {
    final text = (await NativeBridge.extractPdfText(bytes)).trim();
    if (text.isEmpty) {
      throw const FormatException(
        'PDF içinde seçilebilir metin bulunamadı. Dosya taranmış görüntüyse OCR desteği gerekir.',
      );
    }
    return text;
  }

  static String _decodeText(Uint8List bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }

  static String _decodeDocx(Uint8List bytes) {
    Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes);
    } catch (_) {
      throw const FormatException(
        'Word dosyası açılamadı. Dosyanın gerçek DOCX biçiminde olduğundan emin olun.',
      );
    }

    final ArchiveFile? documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) {
      throw const FormatException(
        'DOCX içeriği bulunamadı. Dosyayı Word içinde yeniden DOCX olarak kaydedin.',
      );
    }

    final xmlBytes = documentFile.readBytes();
    if (xmlBytes == null || xmlBytes.isEmpty) {
      throw const FormatException('DOCX metni çözülemedi.');
    }

    late final XmlDocument document;
    try {
      document = XmlDocument.parse(utf8.decode(xmlBytes));
    } catch (_) {
      throw const FormatException('DOCX içindeki metin yapısı okunamadı.');
    }

    final output = StringBuffer();
    final paragraphs = _elementsByLocalName(document, 'p');
    for (final paragraph in paragraphs) {
      final text = _paragraphText(paragraph).trimRight();
      if (text.trim().isEmpty) {
        output.writeln();
        continue;
      }

      XmlElement? styleElement;
      for (final candidate in _elementsByLocalName(paragraph, 'pStyle')) {
        styleElement = candidate;
        break;
      }
      final style = styleElement == null
          ? ''
          : _attributeByLocalName(styleElement, 'val').toLowerCase();

      if (_isHeadingOne(style)) {
        output.writeln('# ${text.trim()}');
      } else if (_isHeadingTwo(style)) {
        output.writeln('## ${text.trim()}');
      } else {
        output.writeln(text);
      }
    }

    return output.toString().replaceAll(RegExp(r'\n{4,}'), '\n\n\n').trim();
  }

  static bool _isHeadingOne(String style) {
    return style.contains('heading1') ||
        style.contains('heading 1') ||
        style.contains('başlık1') ||
        style.contains('başlık 1') ||
        style == 'title';
  }

  static bool _isHeadingTwo(String style) {
    return style.contains('heading2') ||
        style.contains('heading 2') ||
        style.contains('başlık2') ||
        style.contains('başlık 2') ||
        style == 'subtitle';
  }

  static String _paragraphText(XmlElement paragraph) {
    final buffer = StringBuffer();
    void visit(XmlNode node) {
      if (node is XmlElement) {
        switch (node.name.local) {
          case 't':
          case 'instrText':
            buffer.write(node.innerText);
            return;
          case 'tab':
            buffer.write('\t');
            return;
          case 'br':
          case 'cr':
            buffer.write('\n');
            return;
        }
      }
      for (final child in node.children) {
        visit(child);
      }
    }

    visit(paragraph);
    return buffer.toString();
  }

  static Iterable<XmlElement> _elementsByLocalName(
    XmlNode root,
    String localName,
  ) sync* {
    for (final child in root.children) {
      if (child is XmlElement) {
        if (child.name.local == localName) yield child;
        yield* _elementsByLocalName(child, localName);
      }
    }
  }

  static String _attributeByLocalName(XmlElement element, String localName) {
    for (final attribute in element.attributes) {
      if (attribute.name.local == localName) return attribute.value;
    }
    return '';
  }
}
