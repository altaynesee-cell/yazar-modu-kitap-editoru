import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'native_bridge.dart';

class ImportedImage {
  const ImportedImage({
    required this.token,
    required this.name,
    required this.mimeType,
    required this.bytes,
    this.sourcePage,
  });

  final String token;
  final String name;
  final String mimeType;
  final Uint8List bytes;
  final int? sourcePage;
}

class ImportedDocument {
  const ImportedDocument({
    required this.fileName,
    required this.text,
    this.images = const <ImportedImage>[],
    this.warning,
  });

  final String fileName;
  final String text;
  final List<ImportedImage> images;
  final String? warning;
}

class ImportService {
  ImportService._();

  static final RegExp imageMarkerPattern = RegExp(r'^\[\[YM_IMAGE:([^\]]+)\]\]$');

  static String imageMarker(String token) => '[[YM_IMAGE:$token]]';

  static Future<ImportedDocument?> pickDocument() async {
    final selected = await NativeBridge.pickDocument();
    if (selected == null) return null;
    return decodeDocument(selected);
  }

  static Future<ImportedDocument?> consumeSharedDocument() async {
    final selected = await NativeBridge.consumeSharedDocument();
    if (selected == null) return null;
    return decodeDocument(selected);
  }

  static Future<ImportedDocument> decodeDocument(
    NativePickedDocument selected,
  ) async {
    final extension = _extensionOf(selected.name);
    final decoded = switch (extension) {
      'txt' => ImportedDocument(
          fileName: selected.name,
          text: _decodeText(selected.bytes).trim(),
        ),
      'docx' => _decodeDocx(selected.name, selected.bytes),
      'pdf' => await _decodePdf(selected.name, selected.bytes),
      'doc' => throw const FormatException(
          'Eski Word .doc biçimi desteklenmiyor. Word içinde “Farklı Kaydet” ile DOCX olarak kaydedip yeniden seçin.',
        ),
      _ => throw const FormatException(
          'Yalnızca TXT, Word DOCX ve PDF dosyaları destekleniyor.',
        ),
    };

    final visibleText = decoded.text.replaceAll(
      RegExp(r'^\[\[YM_IMAGE:[^\]]+\]\]\s*$', multiLine: true),
      '',
    );
    if (visibleText.trim().isEmpty && decoded.images.isEmpty) {
      throw const FormatException('Belgenin içinde aktarılabilecek metin veya görsel bulunamadı.');
    }
    return decoded;
  }

  static String _extensionOf(String fileName) {
    final cleanName = fileName.split('?').first;
    final dotIndex = cleanName.lastIndexOf('.');
    if (dotIndex < 0 || dotIndex == cleanName.length - 1) return '';
    return cleanName.substring(dotIndex + 1).toLowerCase();
  }

  static Future<ImportedDocument> _decodePdf(
    String fileName,
    Uint8List bytes,
  ) async {
    final decoded = await NativeBridge.extractPdfDocument(bytes);
    final output = StringBuffer();
    final images = <ImportedImage>[];

    for (final page in decoded.pages) {
      final pageText = page.text.trim();
      if (pageText.isNotEmpty) {
        output.writeln(pageText);
        output.writeln();
      }
      if (page.previewBytes.isNotEmpty) {
        final token = _token('pdf-${page.pageNumber}');
        images.add(
          ImportedImage(
            token: token,
            name: 'PDF sayfa ${page.pageNumber}.jpg',
            mimeType: 'image/jpeg',
            bytes: page.previewBytes,
            sourcePage: page.pageNumber,
          ),
        );
        output.writeln(imageMarker(token));
        output.writeln();
      }
    }

    final warning = decoded.previewLimited
        ? 'PDF ${decoded.totalPages} sayfa. Telefon belleğini korumak için ilk ${decoded.pages.length} sayfanın görsel ön izlemesi aktarıldı; metin aktarımı devam eder.'
        : null;

    return ImportedDocument(
      fileName: fileName,
      text: output.toString().trim(),
      images: images,
      warning: warning,
    );
  }

  static String _decodeText(Uint8List bytes) {
    try {
      return utf8.decode(bytes);
    } on FormatException {
      return latin1.decode(bytes);
    }
  }

  static ImportedDocument _decodeDocx(String fileName, Uint8List bytes) {
    Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes);
    } catch (_) {
      throw const FormatException(
        'Word dosyası açılamadı. Dosyanın gerçek DOCX biçiminde olduğundan emin olun.',
      );
    }

    final ArchiveFile? documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) {
      throw const FormatException(
        'DOCX içeriği bulunamadı. Dosyayı Word içinde yeniden DOCX olarak kaydedin.',
      );
    }

    final xmlBytes = documentFile.readBytes();
    if (xmlBytes == null || xmlBytes.isEmpty) {
      throw const FormatException('DOCX metni çözülemedi.');
    }

    late final XmlDocument document;
    try {
      document = XmlDocument.parse(utf8.decode(xmlBytes));
    } catch (_) {
      throw const FormatException('DOCX içindeki metin yapısı okunamadı.');
    }

    final relationships = _docxRelationships(archive);
    final output = StringBuffer();
    final images = <ImportedImage>[];
    var occurrence = 0;

    final paragraphs = _elementsByLocalName(document, 'p');
    for (final paragraph in paragraphs) {
      final text = _paragraphText(paragraph).trimRight();

      XmlElement? styleElement;
      for (final candidate in _elementsByLocalName(paragraph, 'pStyle')) {
        styleElement = candidate;
        break;
      }
      final style = styleElement == null
          ? ''
          : _attributeByLocalName(styleElement, 'val').toLowerCase();

      if (text.trim().isNotEmpty) {
        if (_isHeadingOne(style)) {
          output.writeln('# ${text.trim()}');
        } else if (_isHeadingTwo(style)) {
          output.writeln('## ${text.trim()}');
        } else {
          output.writeln(text);
        }
        output.writeln();
      }

      final relationshipIds = <String>[];
      for (final blip in _elementsByLocalName(paragraph, 'blip')) {
        final id = _attributeByLocalName(blip, 'embed');
        if (id.isNotEmpty) relationshipIds.add(id);
      }
      for (final imageData in _elementsByLocalName(paragraph, 'imagedata')) {
        final id = _attributeByLocalName(imageData, 'id');
        if (id.isNotEmpty) relationshipIds.add(id);
      }

      for (final relationshipId in relationshipIds) {
        final target = relationships[relationshipId];
        if (target == null || target.external) continue;
        final path = _wordTargetPath(target.target);
        final imageFile = archive.findFile(path);
        final imageBytes = imageFile?.readBytes();
        if (imageBytes == null || imageBytes.isEmpty) continue;

        occurrence++;
        final originalName = path.split('/').last;
        final token = _token('docx-$occurrence');
        images.add(
          ImportedImage(
            token: token,
            name: originalName,
            mimeType: _mimeTypeForName(originalName),
            bytes: imageBytes,
          ),
        );
        output.writeln(imageMarker(token));
        output.writeln();
      }
    }

    return ImportedDocument(
      fileName: fileName,
      text: output.toString().replaceAll(RegExp(r'\n{4,}'), '\n\n\n').trim(),
      images: images,
    );
  }

  static Map<String, _DocxRelationship> _docxRelationships(Archive archive) {
    final file = archive.findFile('word/_rels/document.xml.rels');
    final bytes = file?.readBytes();
    if (bytes == null || bytes.isEmpty) return <String, _DocxRelationship>{};

    try {
      final xml = XmlDocument.parse(utf8.decode(bytes));
      final result = <String, _DocxRelationship>{};
      for (final relationship in _elementsByLocalName(xml, 'Relationship')) {
        final id = _attributeByLocalName(relationship, 'Id');
        final target = _attributeByLocalName(relationship, 'Target');
        final mode = _attributeByLocalName(relationship, 'TargetMode');
        if (id.isNotEmpty && target.isNotEmpty) {
          result[id] = _DocxRelationship(
            target: target,
            external: mode.toLowerCase() == 'external',
          );
        }
      }
      return result;
    } catch (_) {
      return <String, _DocxRelationship>{};
    }
  }

  static String _wordTargetPath(String target) {
    var normalized = target.replaceAll('\\', '/');
    while (normalized.startsWith('../')) {
      normalized = normalized.substring(3);
    }
    if (normalized.startsWith('/')) normalized = normalized.substring(1);
    if (normalized.startsWith('word/')) return normalized;
    return 'word/$normalized';
  }

  static String _mimeTypeForName(String name) {
    final extension = _extensionOf(name);
    return switch (extension) {
      'png' => 'image/png',
      'gif' => 'image/gif',
      'webp' => 'image/webp',
      'bmp' => 'image/bmp',
      'tif' || 'tiff' => 'image/tiff',
      'svg' => 'image/svg+xml',
      'emf' => 'image/emf',
      'wmf' => 'image/wmf',
      _ => 'image/jpeg',
    };
  }

  static bool _isHeadingOne(String style) {
    return style.contains('heading1') ||
        style.contains('heading 1') ||
        style.contains('başlık1') ||
        style.contains('başlık 1') ||
        style == 'title';
  }

  static bool _isHeadingTwo(String style) {
    return style.contains('heading2') ||
        style.contains('heading 2') ||
        style.contains('başlık2') ||
        style.contains('başlık 2') ||
        style == 'subtitle';
  }

  static String _paragraphText(XmlElement paragraph) {
    final buffer = StringBuffer();
    void visit(XmlNode node) {
      if (node is XmlElement) {
        switch (node.name.local) {
          case 't':
          case 'instrText':
            buffer.write(node.innerText);
            return;
          case 'tab':
            buffer.write('\t');
            return;
          case 'br':
          case 'cr':
            buffer.write('\n');
            return;
        }
      }
      for (final child in node.children) {
        visit(child);
      }
    }

    visit(paragraph);
    return buffer.toString();
  }

  static Iterable<XmlElement> _elementsByLocalName(
    XmlNode root,
    String localName,
  ) sync* {
    for (final child in root.children) {
      if (child is XmlElement) {
        if (child.name.local == localName) yield child;
        yield* _elementsByLocalName(child, localName);
      }
    }
  }

  static String _attributeByLocalName(XmlElement element, String localName) {
    for (final attribute in element.attributes) {
      if (attribute.name.local == localName) return attribute.value;
    }
    return '';
  }

  static String _token(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${_tokenCounter++}';

  static int _tokenCounter = 0;
}

class _DocxRelationship {
  const _DocxRelationship({required this.target, required this.external});

  final String target;
  final bool external;
}
