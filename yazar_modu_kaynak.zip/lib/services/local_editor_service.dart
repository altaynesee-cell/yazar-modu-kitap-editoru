enum LocalEditMode {
  spelling,
  repetitions,
  simplify,
  full,
}

extension LocalEditModeLabel on LocalEditMode {
  String get label => switch (this) {
        LocalEditMode.spelling => 'Yazım ve noktalama',
        LocalEditMode.repetitions => 'Tekrarları düzelt — metni silmeden',
        LocalEditMode.simplify => 'Anlatımı sadeleştir — kısaltmadan',
        LocalEditMode.full => 'Kısaltmadan kitap düzenlemesi',
      };
}

class LocalEditorService {
  LocalEditorService._();

  /// Yerel editör hiçbir paragrafı veya cümleyi kaldırmaz. Yalnızca güvenli
  /// yazım, noktalama ve küçük anlatım düzeltmeleri yapar. Sonuç, özgün metnin
  /// kelime sayısının yüzde 97'sinin altına düşerse koruma devreye girer.
  static String createSuggestion(String input, LocalEditMode mode) {
    final normalizedInput =
        input.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    var output = normalizedInput;

    if (mode == LocalEditMode.spelling || mode == LocalEditMode.full) {
      output = _normalizePunctuation(output);
      output = _removeRepeatedWords(output);
    }

    if (mode == LocalEditMode.repetitions || mode == LocalEditMode.full) {
      // İçerik kaybını önlemek için paragraf ve cümle silinmez. Yalnızca art
      // arda yanlışlıkla yinelenen kelimeler düzeltilir.
      output = _removeRepeatedWords(output);
    }

    if (mode == LocalEditMode.simplify || mode == LocalEditMode.full) {
      output = _simplifySafePatterns(output);
    }

    output = _normalizeParagraphSpacing(output).trim();
    final originalWords = wordCount(normalizedInput);
    final outputWords = wordCount(output);
    if (originalWords > 20 && outputWords < (originalWords * 0.97).ceil()) {
      return _normalizeParagraphSpacing(normalizedInput).trim();
    }
    return output;
  }

  static int wordCount(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .length;
  }

  static int paragraphCount(String value) {
    return _splitParagraphs(value).length;
  }

  static String _normalizePunctuation(String input) {
    var output = input.replaceAll(RegExp(r'[ \t]+'), ' ');

    // Art arda kullanılan işaretleri önce tekilleştir. Böylece boşluk
    // düzenlemesi "? !" gibi istenmeyen ayrımlar oluşturmaz.
    output = output.replaceAll(RegExp(r'\.{3,}'), '…');
    output = output.replaceAll(RegExp(r'!{2,}'), '!');
    output = output.replaceAll(RegExp(r'\?{2,}'), '?');

    // Noktalama işaretinin önündeki yatay boşluğu kaldırır; işaretten sonra
    // metin devam ediyorsa tam bir boşluk bırakır. Satır sonları ve kapanış
    // işaretleri korunur. Bu yöntem mobil/CI ortamlarında aynı sonucu verir.
    final source = output;
    final punctuation = RegExp(r'[ \t]*([,.;:!?])[ \t]*');
    output = source.replaceAllMapped(punctuation, (match) {
      final mark = match.group(1) ?? '';
      final nextIndex = match.end;
      if (nextIndex >= source.length) return mark;

      final next = source.substring(nextIndex, nextIndex + 1);
      const noSpaceBefore = <String>{
        '\n',
        '\r',
        ')',
        ']',
        '}',
        '"',
        '”',
        '’',
      };
      if (noSpaceBefore.contains(next)) return mark;
      return '$mark ';
    });

    return output;
  }

  static String _removeRepeatedWords(String input) {
    // RegExp geri başvuruları bazı çalışma ortamlarında büyük/küçük harf
    // karşılaştırmasında tutarsız sonuç verebildiği için ardışık kelimeleri
    // açık biçimde karşılaştırıyoruz. Yalnızca yatay boşlukla ayrılan aynı
    // kelime kaldırılır; satır sonları ve paragraf yapısı korunur.
    final adjacentWords = RegExp(
      r'([A-Za-zÇĞİÖŞÜçğıöşü]+)([ \t]+)([A-Za-zÇĞİÖŞÜçğıöşü]+)',
    );

    var output = input;
    while (true) {
      var changed = false;
      final next = output.replaceAllMapped(adjacentWords, (match) {
        final first = match.group(1) ?? '';
        final second = match.group(3) ?? '';
        if (first.toLowerCase() == second.toLowerCase()) {
          changed = true;
          return first;
        }
        return match.group(0) ?? '';
      });
      output = next;
      if (!changed) return output;
    }
  }

  static String _simplifySafePatterns(String input) {
    var output = input;
    final replacements = <RegExp, String>{
      RegExp(r'\bbu noktada şunu belirtmek gerekir ki\b', caseSensitive: false):
          'Bu noktada',
      RegExp(r'\bşunu da ayrıca belirtmek gerekir ki\b', caseSensitive: false):
          'Ayrıca belirtmek gerekir ki',
      RegExp(r'\bbu bağlamda değerlendirildiğinde\b', caseSensitive: false):
          'Bu bağlamda değerlendirildiğinde',
      RegExp(r'\bgerçekleştirilmiş bulunmaktadır\b', caseSensitive: false):
          'gerçekleştirilmiş durumdadır',
      RegExp(r'\byapılmış bulunmaktadır\b', caseSensitive: false):
          'yapılmış durumdadır',
    };
    for (final entry in replacements.entries) {
      output = output.replaceAll(entry.key, entry.value);
    }
    return output;
  }

  static String _normalizeParagraphSpacing(String input) {
    return input
        .split('\n')
        .map((line) => line.trimRight())
        .join('\n')
        .replaceAll(RegExp(r'\n[ \t]+\n'), '\n\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n');
  }

  static List<String> _splitParagraphs(String input) {
    final normalized = input.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return normalized
        .split(RegExp(r'\n\s*\n'))
        .map((paragraph) => paragraph.trim())
        .where((paragraph) => paragraph.isNotEmpty)
        .toList();
  }
}
