enum LocalEditMode {
  spelling,
  repetitions,
  simplify,
  full,
}

extension LocalEditModeLabel on LocalEditMode {
  String get label => switch (this) {
        LocalEditMode.spelling => 'Yazım ve noktalama',
        LocalEditMode.repetitions => 'Tekrarları azalt',
        LocalEditMode.simplify => 'Anlatımı sadeleştir',
        LocalEditMode.full => 'Dengeli kitap düzenlemesi',
      };
}

class LocalEditorService {
  LocalEditorService._();

  static String createSuggestion(String input, LocalEditMode mode) {
    var output = input.replaceAll('\r\n', '\n').replaceAll('\r', '\n');

    if (mode == LocalEditMode.spelling || mode == LocalEditMode.full) {
      output = _normalizePunctuation(output);
      output = _removeRepeatedWords(output);
    }

    if (mode == LocalEditMode.repetitions || mode == LocalEditMode.full) {
      output = _removeDuplicateParagraphs(output);
      output = _removeConsecutiveDuplicateSentences(output);
    }

    if (mode == LocalEditMode.simplify || mode == LocalEditMode.full) {
      output = _simplifySafePatterns(output);
    }

    return _normalizeParagraphSpacing(output).trim();
  }

  static String _normalizePunctuation(String input) {
    var output = input;
    output = output.replaceAll(RegExp(r'[ \t]+'), ' ');
    output = output.replaceAllMapped(
      RegExp(r'\s+([,.;:!?])'),
      (match) => match.group(1) ?? '',
    );
    output = output.replaceAllMapped(
      RegExp(r'([,.;:!?])(?=[^\s\n\)\]\}\"”’])'),
      (match) => '${match.group(1) ?? ''} ',
    );
    output = output.replaceAll(RegExp(r'\.{4,}'), '…');
    output = output.replaceAll(RegExp(r'!{2,}'), '!');
    output = output.replaceAll(RegExp(r'\?{2,}'), '?');
    return output;
  }

  static String _removeRepeatedWords(String input) {
    final repeatedWord = RegExp(
      r'\b([A-Za-zÇĞİÖŞÜçğıöşü]+)(?:\s+\1\b)+',
      caseSensitive: false,
    );
    return input.replaceAllMapped(repeatedWord, (match) => match.group(1) ?? '');
  }

  static String _removeDuplicateParagraphs(String input) {
    final paragraphs = _splitParagraphs(input);
    final seen = <String>{};
    final output = <String>[];
    for (final paragraph in paragraphs) {
      final key = _comparisonKey(paragraph);
      if (key.isEmpty || seen.add(key)) output.add(paragraph.trim());
    }
    return output.join('\n\n');
  }

  static String _removeConsecutiveDuplicateSentences(String input) {
    final output = <String>[];
    for (final paragraph in _splitParagraphs(input)) {
      final sentences = _splitSentences(paragraph);
      final kept = <String>[];
      String? previousKey;
      for (final sentence in sentences) {
        final key = _comparisonKey(sentence);
        if (key.isEmpty || key != previousKey) {
          kept.add(sentence.trim());
        }
        previousKey = key;
      }
      output.add(kept.join(' ').trim());
    }
    return output.join('\n\n');
  }

  static String _simplifySafePatterns(String input) {
    var output = input;
    final replacements = <RegExp, String>{
      RegExp(r'\bbu noktada şunu belirtmek gerekir ki\b', caseSensitive: false):
          'Burada',
      RegExp(r'\bşunu da ayrıca belirtmek gerekir ki\b', caseSensitive: false):
          'Ayrıca',
      RegExp(r'\bbu bağlamda değerlendirildiğinde\b', caseSensitive: false):
          'Bu bağlamda',
      RegExp(r'\bgerçekleştirilmiş bulunmaktadır\b', caseSensitive: false):
          'gerçekleştirilmiştir',
      RegExp(r'\byapılmış bulunmaktadır\b', caseSensitive: false):
          'yapılmıştır',
    };
    for (final entry in replacements.entries) {
      output = output.replaceAll(entry.key, entry.value);
    }
    return output;
  }

  static String _normalizeParagraphSpacing(String input) {
    return input
        .split('\n')
        .map((line) => line.trimRight())
        .join('\n')
        .replaceAll(RegExp(r'\n[ \t]+\n'), '\n\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n');
  }

  static List<String> _splitParagraphs(String input) {
    final normalized = input.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    return normalized
        .split(RegExp(r'\n\s*\n'))
        .map((paragraph) => paragraph.trim())
        .where((paragraph) => paragraph.isNotEmpty)
        .toList();
  }

  static List<String> _splitSentences(String paragraph) {
    final matches = RegExp(r'[^.!?…]+[.!?…]+|[^.!?…]+$')
        .allMatches(paragraph)
        .map((match) => match.group(0)?.trim() ?? '')
        .where((sentence) => sentence.isNotEmpty)
        .toList();
    return matches.isEmpty ? <String>[paragraph.trim()] : matches;
  }

  static String _comparisonKey(String value) {
    return value
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-zçğıöşü0-9]+'), ' ')
        .trim();
  }
}
