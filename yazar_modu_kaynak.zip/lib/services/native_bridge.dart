import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';

class NativePickedDocument {
  const NativePickedDocument({required this.name, required this.bytes});

  final String name;
  final Uint8List bytes;
}

class NativePdfPage {
  const NativePdfPage({
    required this.pageNumber,
    required this.text,
    required this.previewBytes,
  });

  final int pageNumber;
  final String text;
  final Uint8List previewBytes;
}

class NativePdfDocument {
  const NativePdfDocument({
    required this.pages,
    required this.totalPages,
    required this.previewLimited,
  });

  final List<NativePdfPage> pages;
  final int totalPages;
  final bool previewLimited;
}

class NativeBridge {
  NativeBridge._();

  static const MethodChannel _channel =
      MethodChannel('com.altayaytin.yazar_modu/native');

  static Future<void> Function()? _sharedDocumentListener;
  static bool _handlerInstalled = false;

  static void setSharedDocumentListener(Future<void> Function()? listener) {
    _sharedDocumentListener = listener;
    if (!_handlerInstalled) {
      _handlerInstalled = true;
      _channel.setMethodCallHandler((call) async {
        if (call.method == 'sharedDocumentAvailable') {
          await _sharedDocumentListener?.call();
        }
        return null;
      });
    }
  }

  static Future<NativePickedDocument?> pickDocument() async {
    final Object? response = await _channel.invokeMethod<Object?>('pickDocument');
    return _decodeDocumentResponse(response);
  }

  static Future<NativePickedDocument?> consumeSharedDocument() async {
    final Object? response =
        await _channel.invokeMethod<Object?>('consumeSharedDocument');
    return _decodeDocumentResponse(response);
  }

  static NativePickedDocument? _decodeDocumentResponse(Object? response) {
    if (response == null) return null;
    if (response is! Map) {
      throw const FormatException('Dosya seçme yanıtı okunamadı.');
    }

    final map = Map<Object?, Object?>.from(response);
    final name = map['name']?.toString().trim() ?? '';
    final Object? rawBytes = map['bytes'];
    final bytes = _decodeBytes(rawBytes);

    if (name.isEmpty) {
      throw const FormatException('Seçilen dosyanın adı okunamadı.');
    }
    return NativePickedDocument(name: name, bytes: bytes);
  }

  static Future<NativePdfDocument> extractPdfDocument(Uint8List bytes) async {
    final Object? response =
        await _channel.invokeMethod<Object?>('extractPdfDocument', bytes);
    if (response is! Map) {
      throw const FormatException('PDF içeriği okunamadı.');
    }

    final map = Map<Object?, Object?>.from(response);
    final rawPages = map['pages'];
    if (rawPages is! List) {
      throw const FormatException('PDF sayfaları okunamadı.');
    }

    final pages = <NativePdfPage>[];
    for (final rawPage in rawPages) {
      if (rawPage is! Map) continue;
      final pageMap = Map<Object?, Object?>.from(rawPage);
      pages.add(
        NativePdfPage(
          pageNumber: pageMap['pageNumber'] as int? ?? pages.length + 1,
          text: pageMap['text']?.toString() ?? '',
          previewBytes: _decodeBytes(pageMap['previewBytes'], allowEmpty: true),
        ),
      );
    }

    return NativePdfDocument(
      pages: pages,
      totalPages: map['totalPages'] as int? ?? pages.length,
      previewLimited: map['previewLimited'] as bool? ?? false,
    );
  }

  static Uint8List _decodeBytes(Object? rawBytes, {bool allowEmpty = false}) {
    final Uint8List bytes;
    if (rawBytes is Uint8List) {
      bytes = rawBytes;
    } else if (rawBytes is List) {
      bytes = Uint8List.fromList(List<int>.from(rawBytes));
    } else if (allowEmpty && rawBytes == null) {
      return Uint8List(0);
    } else {
      throw const FormatException('Dosya içeriği okunamadı.');
    }
    if (!allowEmpty && bytes.isEmpty) {
      throw const FormatException('Dosya içeriği boş.');
    }
    return bytes;
  }


  static Future<bool> createBackup({required String fileName}) async {
    final uri = await _channel.invokeMethod<String>('createBackup', <String, Object?>{
      'fileName': fileName,
    });
    return uri != null && uri.isNotEmpty;
  }

  static Future<int?> restoreBackup() async {
    return _channel.invokeMethod<int>('restoreBackup');
  }

  static Future<bool> exportSection({
    required String projectId,
    required String sectionId,
    required String format,
  }) async {
    final uri = await _channel.invokeMethod<String>('exportSection', <String, Object?>{
      'projectId': projectId,
      'sectionId': sectionId,
      'format': format,
    });
    return uri != null && uri.isNotEmpty;
  }

  static Future<bool> exportProjectSections({
    required String projectId,
    required String format,
  }) async {
    final uri = await _channel.invokeMethod<String>('exportProjectSections', <String, Object?>{
      'projectId': projectId,
      'format': format,
    });
    return uri != null && uri.isNotEmpty;
  }

  static Future<String> getDocumentsPath() async {
    final path = await _channel.invokeMethod<String>('getDocumentsPath');
    if (path == null || path.trim().isEmpty) {
      throw const FileSystemException('Uygulama kayıt klasörü bulunamadı.');
    }
    return path;
  }
}
