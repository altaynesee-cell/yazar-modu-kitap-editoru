import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';

class NativePickedDocument {
  const NativePickedDocument({required this.name, required this.bytes});

  final String name;
  final Uint8List bytes;
}

class NativeBridge {
  NativeBridge._();

  static const MethodChannel _channel =
      MethodChannel('com.altayaytin.yazar_modu/native');

  static Future<void> Function()? _sharedDocumentListener;
  static bool _handlerInstalled = false;

  static void setSharedDocumentListener(Future<void> Function()? listener) {
    _sharedDocumentListener = listener;
    if (!_handlerInstalled) {
      _handlerInstalled = true;
      _channel.setMethodCallHandler((call) async {
        if (call.method == 'sharedDocumentAvailable') {
          await _sharedDocumentListener?.call();
        }
        return null;
      });
    }
  }

  static Future<NativePickedDocument?> pickDocument() async {
    final Object? response =
        await _channel.invokeMethod<Object?>('pickDocument');
    return _decodeDocumentResponse(response);
  }

  static Future<NativePickedDocument?> consumeSharedDocument() async {
    final Object? response =
        await _channel.invokeMethod<Object?>('consumeSharedDocument');
    return _decodeDocumentResponse(response);
  }

  static NativePickedDocument? _decodeDocumentResponse(Object? response) {
    if (response == null) return null;
    if (response is! Map) {
      throw const FormatException('Dosya seçme yanıtı okunamadı.');
    }

    final map = Map<Object?, Object?>.from(response);
    final name = map['name']?.toString().trim() ?? '';
    final Object? rawBytes = map['bytes'];

    final Uint8List bytes;
    if (rawBytes is Uint8List) {
      bytes = rawBytes;
    } else if (rawBytes is List) {
      bytes = Uint8List.fromList(List<int>.from(rawBytes));
    } else {
      throw const FormatException('Seçilen dosyanın içeriği okunamadı.');
    }

    if (name.isEmpty) {
      throw const FormatException('Seçilen dosyanın adı okunamadı.');
    }
    return NativePickedDocument(name: name, bytes: bytes);
  }

  static Future<String> extractPdfText(Uint8List bytes) async {
    final text = await _channel.invokeMethod<String>('extractPdfText', bytes);
    if (text == null) {
      throw const FormatException('PDF metni okunamadı.');
    }
    return text;
  }

  static Future<String> getDocumentsPath() async {
    final path = await _channel.invokeMethod<String>('getDocumentsPath');
    if (path == null || path.trim().isEmpty) {
      throw const FileSystemException('Uygulama kayıt klasörü bulunamadı.');
    }
    return path;
  }
}
