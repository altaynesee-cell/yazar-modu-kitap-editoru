enum PreviewTextKind { heading1, heading2, paragraph }

class PreviewTextBlock {
  const PreviewTextBlock({required this.kind, required this.text});

  final PreviewTextKind kind;
  final String text;
}

/// Belgeden gelen düz metni kitap ön izlemesine uygun başlık ve paragraf
/// bloklarına ayırır. Word/PDF aktarımında başlık ile ilk paragrafın birleştiği
/// durumları da güvenli bir sezgisel yöntemle düzeltir.
class PreviewTextParser {
  PreviewTextParser._();

  static List<PreviewTextBlock> parse(String input) {
    final normalized = input
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .trim();
    if (normalized.isEmpty) return const <PreviewTextBlock>[];

    final rawParagraphs = normalized
        .split(RegExp(r'\n\s*\n'))
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toList();

    final output = <PreviewTextBlock>[];
    for (var index = 0; index < rawParagraphs.length; index++) {
      output.addAll(
        parseParagraph(
          rawParagraphs[index],
          allowMergedLeadingHeading: index == 0,
        ),
      );
    }
    return output;
  }

  static List<PreviewTextBlock> parseParagraph(
    String input, {
    bool allowMergedLeadingHeading = false,
  }) {
    final paragraph = input.trim();
    if (paragraph.isEmpty) return const <PreviewTextBlock>[];

    final explicit = _parseExplicitHeading(paragraph);
    if (explicit != null) return <PreviewTextBlock>[explicit];

    final lines = paragraph
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList();
    if (lines.length > 1 && _isLikelyHeading(lines.first)) {
      final output = <PreviewTextBlock>[
        PreviewTextBlock(kind: PreviewTextKind.heading1, text: lines.first),
      ];
      final rest = lines.skip(1).join(' ').trim();
      if (rest.isNotEmpty) {
        output.add(
          PreviewTextBlock(kind: PreviewTextKind.paragraph, text: rest),
        );
      }
      return output;
    }

    if (allowMergedLeadingHeading) {
      final split = _splitMergedLeadingHeading(paragraph);
      if (split != null) {
        return <PreviewTextBlock>[
          PreviewTextBlock(
            kind: PreviewTextKind.heading1,
            text: split.heading,
          ),
          if (split.body.isNotEmpty)
            PreviewTextBlock(
              kind: PreviewTextKind.paragraph,
              text: split.body,
            ),
        ];
      }
    }

    if (_isLikelyHeading(paragraph)) {
      return <PreviewTextBlock>[
        PreviewTextBlock(kind: PreviewTextKind.heading2, text: paragraph),
      ];
    }
    return <PreviewTextBlock>[
      PreviewTextBlock(
        kind: PreviewTextKind.paragraph,
        text: paragraph.replaceAll(RegExp(r'\n+'), ' '),
      ),
    ];
  }

  static PreviewTextBlock? _parseExplicitHeading(String paragraph) {
    if (paragraph.startsWith('## ')) {
      return PreviewTextBlock(
        kind: PreviewTextKind.heading2,
        text: paragraph.substring(3).trim(),
      );
    }
    if (paragraph.startsWith('# ')) {
      return PreviewTextBlock(
        kind: PreviewTextKind.heading1,
        text: paragraph.substring(2).trim(),
      );
    }
    return null;
  }

  static _HeadingSplit? _splitMergedLeadingHeading(String paragraph) {
    final value = paragraph.trim();
    if (value.length < 24) return null;

    var uppercaseLetters = 0;
    var boundary = -1;
    for (var index = 0; index < value.length; index++) {
      final character = value[index];
      if (_isUppercaseLetter(character)) {
        uppercaseLetters++;
        continue;
      }
      if (_isLowercaseLetter(character)) {
        if (uppercaseLetters >= 10) boundary = index;
        break;
      }
    }

    if (boundary <= 0 || boundary > 180) return null;
    var heading = value.substring(0, boundary).trimRight();
    var body = value.substring(boundary).trimLeft();
    if (heading.split(RegExp(r'\s+')).length < 2 || heading.length < 12) {
      return null;
    }

    // "TEORİSİ" + "İnsanlık" bazı dosyalarda ortak bir İ harfi üzerinden
    // "TEORİSİnsanlık" biçiminde birleşebilir. Gövdenin ilk harfini geri ekle.
    if (body.isNotEmpty && _isLowercaseLetter(body[0])) {
      final last = heading.isEmpty ? '' : heading[heading.length - 1];
      final beforeLast = heading.length > 1 ? heading[heading.length - 2] : '';
      if ((last == 'İ' || last == 'I') && beforeLast.trim().isEmpty) {
        heading = heading.substring(0, heading.length - 1).trimRight();
        body = '$last$body';
      } else if (last == 'İ' || last == 'I') {
        body = '$last$body';
      }
    }

    heading = heading.replaceAll(RegExp(r'\s+'), ' ').trim();
    body = body.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (!_isLikelyHeading(heading)) return null;
    return _HeadingSplit(heading: heading, body: body);
  }

  static bool _isLikelyHeading(String value) {
    final text = value.trim();
    if (text.length < 4 || text.length > 180) return false;
    if (text.endsWith('.') || text.endsWith('?') || text.endsWith('!')) {
      return false;
    }
    final words = text.split(RegExp(r'\s+'));
    if (words.length > 18) return false;

    var letters = 0;
    var uppercase = 0;
    for (final rune in text.runes) {
      final character = String.fromCharCode(rune);
      if (_isUppercaseLetter(character)) {
        letters++;
        uppercase++;
      } else if (_isLowercaseLetter(character)) {
        letters++;
      }
    }
    if (letters < 4) return false;
    return uppercase / letters >= 0.82;
  }

  static bool _isUppercaseLetter(String character) {
    return RegExp(r'[A-ZÇĞİÖŞÜ]').hasMatch(character);
  }

  static bool _isLowercaseLetter(String character) {
    return RegExp(r'[a-zçğıöşü]').hasMatch(character);
  }
}

class _HeadingSplit {
  const _HeadingSplit({required this.heading, required this.body});

  final String heading;
  final String body;
}
