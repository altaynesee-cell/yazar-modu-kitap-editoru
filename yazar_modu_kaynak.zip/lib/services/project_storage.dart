import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/book_project.dart';

class ProjectStorage {
  static const _directoryName = 'yazar_modu';
  static const _fileName = 'projects.json';

  Future<File> _dataFile() async {
    final documents = await getApplicationDocumentsDirectory();
    final directory = Directory('${documents.path}/$_directoryName');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return File('${directory.path}/$_fileName');
  }

  Future<List<BookProject>> loadProjects() async {
    final file = await _dataFile();
    if (!await file.exists()) return <BookProject>[];
    try {
      final content = await file.readAsString();
      if (content.trim().isEmpty) return <BookProject>[];
      final decoded = jsonDecode(content) as List<dynamic>;
      return decoded
          .map((item) => BookProject.fromJson(Map<String, dynamic>.from(item as Map)))
          .toList()
        ..sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    } on FormatException {
      final backup = File('${file.path}.bozuk-${DateTime.now().millisecondsSinceEpoch}');
      await file.copy(backup.path);
      return <BookProject>[];
    }
  }

  Future<void> saveProjects(List<BookProject> projects) async {
    final file = await _dataFile();
    final temp = File('${file.path}.tmp');
    final payload = const JsonEncoder.withIndent('  ')
        .convert(projects.map((project) => project.toJson()).toList());
    await temp.writeAsString(payload, flush: true);
    if (await file.exists()) await file.delete();
    await temp.rename(file.path);
  }
}
