import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../models/book_project.dart';
import 'native_bridge.dart';

class ProjectStorage {
  static const _directoryName = 'yazar_modu';
  static const _fileName = 'projects.json';

  Future<Directory> _rootDirectory() async {
    final documentsPath = await NativeBridge.getDocumentsPath();
    final directory = Directory('$documentsPath/$_directoryName');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  Future<File> _dataFile() async {
    final directory = await _rootDirectory();
    return File('${directory.path}/$_fileName');
  }

  Future<String> saveImageAsset({
    required String projectId,
    required String imageId,
    required String extension,
    required Uint8List bytes,
  }) async {
    final root = await _rootDirectory();
    final safeProject = _safeSegment(projectId);
    final safeImage = _safeSegment(imageId);
    final safeExtension = _safeExtension(extension);
    final directory = Directory('${root.path}/assets/$safeProject');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    final file = File('${directory.path}/$safeImage.$safeExtension');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<List<BookProject>> loadProjects() async {
    final file = await _dataFile();
    if (!await file.exists()) return <BookProject>[];
    try {
      final content = await file.readAsString();
      if (content.trim().isEmpty) return <BookProject>[];
      final decoded = jsonDecode(content) as List<dynamic>;
      return decoded
          .map((item) =>
              BookProject.fromJson(Map<String, dynamic>.from(item as Map)))
          .toList()
        ..sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    } on FormatException {
      final backup =
          File('${file.path}.bozuk-${DateTime.now().millisecondsSinceEpoch}');
      await file.copy(backup.path);
      return <BookProject>[];
    }
  }

  Future<void> saveProjects(List<BookProject> projects) async {
    final file = await _dataFile();
    final temp = File('${file.path}.tmp');
    final payload = const JsonEncoder.withIndent('  ')
        .convert(projects.map((project) => project.toJson()).toList());
    await temp.writeAsString(payload, flush: true);
    if (await file.exists()) await file.delete();
    await temp.rename(file.path);
  }

  static String _safeSegment(String value) {
    return value.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
  }

  static String _safeExtension(String value) {
    final cleaned = value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    return cleaned.isEmpty ? 'jpg' : cleaned;
  }
}
