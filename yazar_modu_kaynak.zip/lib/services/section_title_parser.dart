import '../models/book_section.dart';
import 'preview_text_parser.dart';

class ResolvedSectionTitle {
  const ResolvedSectionTitle({
    required this.chapterNumber,
    required this.mainTitle,
    required this.subtitle,
    required this.body,
    required this.removedLeadingParagraphs,
  });

  final int? chapterNumber;
  final String mainTitle;
  final String subtitle;
  final String body;
  final int removedLeadingParagraphs;

  String get chapterLabel =>
      chapterNumber == null ? '' : '${chapterNumber!}. Bölüm';

  String get displayTitle {
    final pieces = <String>[
      if (chapterLabel.isNotEmpty) chapterLabel,
      if (mainTitle.trim().isNotEmpty) mainTitle.trim(),
    ];
    return pieces.join(' — ');
  }
}

/// Eski tek alanlı bölüm başlıklarını üç ayrı alana dönüştürür:
/// bölüm numarası, ana başlık ve alt başlık.
class SectionTitleParser {
  SectionTitleParser._();

  static final RegExp _legacyChapter = RegExp(
    r'^(\d{1,3})\.\s*Bölüm(?:\s*[—–-]\s*(.+))?$',
    caseSensitive: false,
  );

  static ResolvedSectionTitle resolve({
    required BookSection section,
    bool extractSubtitleFromBody = true,
  }) {
    int? number = section.chapterNumber;
    var mainTitle = section.mainTitle.trim();
    var subtitle = section.subtitle.trim();
    var body = section.content;
    var removed = 0;

    final legacy = _legacyChapter.firstMatch(section.title.trim());
    if (legacy != null) {
      number ??= int.tryParse(legacy.group(1) ?? '');
      if (mainTitle.isEmpty) {
        mainTitle = (legacy.group(2) ?? '').trim();
      }
    } else if (mainTitle.isEmpty) {
      mainTitle = section.title.trim();
    }

    if (section.kind == SectionKind.chapter &&
        subtitle.isEmpty &&
        extractSubtitleFromBody) {
      final extraction = _extractLeadingSubtitle(body);
      subtitle = extraction.subtitle;
      body = extraction.body;
      removed = extraction.removedParagraphs;
    }

    return ResolvedSectionTitle(
      chapterNumber: number,
      mainTitle: mainTitle,
      subtitle: subtitle,
      body: body,
      removedLeadingParagraphs: removed,
    );
  }

  static String composeLegacyTitle({
    required SectionKind kind,
    required int? chapterNumber,
    required String mainTitle,
  }) {
    final cleanMain = mainTitle.trim();
    if (kind != SectionKind.chapter) {
      return cleanMain.isEmpty ? 'İsimsiz Bölüm' : cleanMain;
    }
    final label = chapterNumber == null ? 'Bölüm' : '$chapterNumber. Bölüm';
    return cleanMain.isEmpty ? label : '$label — $cleanMain';
  }

  static _SubtitleExtraction _extractLeadingSubtitle(String content) {
    final normalized = content
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .trim();
    if (normalized.isEmpty) {
      return const _SubtitleExtraction('', '', 0);
    }

    final paragraphs = normalized
        .split(RegExp(r'\n\s*\n'))
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toList();
    final headingParts = <String>[];
    var removed = 0;

    while (paragraphs.isNotEmpty && headingParts.length < 2) {
      final blocks = PreviewTextParser.parseParagraph(
        paragraphs.first,
        allowMergedLeadingHeading: true,
      );
      if (blocks.isEmpty || blocks.first.kind == PreviewTextKind.paragraph) {
        break;
      }

      headingParts.add(blocks.first.text.trim());
      removed++;
      if (blocks.length > 1 &&
          blocks[1].kind == PreviewTextKind.paragraph &&
          blocks[1].text.trim().isNotEmpty) {
        paragraphs[0] = blocks[1].text.trim();
        removed--;
        break;
      }
      paragraphs.removeAt(0);
    }

    if (headingParts.isEmpty) {
      return _SubtitleExtraction('', normalized, 0);
    }
    return _SubtitleExtraction(
      headingParts.join(' ').replaceAll(RegExp(r'\s+'), ' ').trim(),
      paragraphs.join('\n\n').trim(),
      removed,
    );
  }
}

class _SubtitleExtraction {
  const _SubtitleExtraction(
    this.subtitle,
    this.body,
    this.removedParagraphs,
  );

  final String subtitle;
  final String body;
  final int removedParagraphs;
}
