import 'package:flutter/foundation.dart';

import '../models/book_project.dart';
import '../models/book_section.dart';
import '../models/section_image.dart';
import '../services/chapter_parser.dart';
import '../services/import_service.dart';
import '../services/project_storage.dart';

class BookStore extends ChangeNotifier {
  BookStore({ProjectStorage? storage}) : _storage = storage ?? ProjectStorage();

  final ProjectStorage _storage;
  final List<BookProject> _projects = <BookProject>[];
  bool _initialized = false;
  String? _errorMessage;

  List<BookProject> get projects => List<BookProject>.unmodifiable(_projects);
  bool get initialized => _initialized;
  String? get errorMessage => _errorMessage;

  Future<void> initialize() async {
    try {
      _projects
        ..clear()
        ..addAll(await _storage.loadProjects());
    } catch (error) {
      _errorMessage = 'Projeler yüklenemedi: $error';
    } finally {
      _initialized = true;
      notifyListeners();
    }
  }

  BookProject? projectById(String id) {
    for (final project in _projects) {
      if (project.id == id) return project;
    }
    return null;
  }

  Future<BookProject> createProject({
    required String title,
    required String author,
    String initialText = '',
  }) async {
    final now = DateTime.now();
    final project = BookProject(
      id: _id('project'),
      title: title.trim().isEmpty ? 'İsimsiz Kitap' : title.trim(),
      author: author.trim(),
      sections: ChapterParser.parse(initialText),
      createdAt: now,
      modifiedAt: now,
    );
    _projects.insert(0, project);
    await _persistAndNotify();
    return project;
  }

  Future<BookProject> createProjectFromImportedDocument({
    required String title,
    required String author,
    required ImportedDocument document,
    bool splitIntoSections = true,
  }) async {
    final now = DateTime.now();
    final projectId = _id('project');
    final sections = await _prepareImportedSections(
      projectId: projectId,
      document: document,
      splitIntoSections: splitIntoSections,
    );
    final project = BookProject(
      id: projectId,
      title: title.trim().isEmpty ? 'İsimsiz Kitap' : title.trim(),
      author: author.trim(),
      sections: sections.isEmpty ? ChapterParser.parse('') : sections,
      createdAt: now,
      modifiedAt: now,
    );
    _projects.insert(0, project);
    await _persistAndNotify();
    return project;
  }

  Future<void> updateProject(BookProject updated) async {
    final index = _projects.indexWhere((project) => project.id == updated.id);
    if (index == -1) return;
    _projects[index] = updated.copyWith(modifiedAt: DateTime.now());
    _projects.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    await _persistAndNotify();
  }

  Future<void> deleteProject(String id) async {
    _projects.removeWhere((project) => project.id == id);
    await _persistAndNotify();
  }

  Future<void> reorderSections(String projectId, int oldIndex, int newIndex) async {
    final project = projectById(projectId);
    if (project == null) return;
    final sections = List<BookSection>.from(project.sections);
    if (newIndex > oldIndex) newIndex--;
    final moved = sections.removeAt(oldIndex);
    sections.insert(newIndex, moved);
    final reordered = List<BookSection>.generate(
      sections.length,
      (index) => sections[index].copyWith(order: index, modifiedAt: DateTime.now()),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<BookSection?> addSection(
    String projectId, {
    String? title,
    String content = '',
    SectionKind kind = SectionKind.chapter,
  }) async {
    final project = projectById(projectId);
    if (project == null) return null;
    final now = DateTime.now();
    final section = BookSection(
      id: _id('section'),
      title: title?.trim().isNotEmpty == true
          ? title!.trim()
          : '${project.sections.length + 1}. Bölüm',
      content: content,
      kind: kind,
      order: project.sections.length,
      createdAt: now,
      modifiedAt: now,
    );
    await updateProject(
      project.copyWith(sections: <BookSection>[...project.sections, section]),
    );
    return section;
  }

  Future<List<BookSection>> addImportedDocument(
    String projectId, {
    required ImportedDocument document,
    required bool splitIntoSections,
  }) async {
    final project = projectById(projectId);
    if (project == null) return <BookSection>[];

    final imported = await _prepareImportedSections(
      projectId: projectId,
      document: document,
      splitIntoSections: splitIntoSections,
    );

    final hasOnlyEmptyPlaceholder = project.sections.length == 1 &&
        project.sections.first.content.trim().isEmpty &&
        project.sections.first.images.isEmpty &&
        project.sections.first.title.trim().toLowerCase() == '1. bölüm';
    final existing = hasOnlyEmptyPlaceholder
        ? <BookSection>[]
        : List<BookSection>.from(project.sections);
    final appended = List<BookSection>.generate(
      imported.length,
      (index) => imported[index].copyWith(
        order: existing.length + index,
        modifiedAt: DateTime.now(),
      ),
    );
    await updateProject(
      project.copyWith(sections: <BookSection>[...existing, ...appended]),
    );
    return appended;
  }

  Future<List<BookSection>> _prepareImportedSections({
    required String projectId,
    required ImportedDocument document,
    required bool splitIntoSections,
  }) async {
    final rawSections = splitIntoSections
        ? ChapterParser.parse(document.text)
        : <BookSection>[
            BookSection(
              id: _id('section'),
              title: _titleFromFileName(document.fileName),
              content: document.text.trim(),
              kind: SectionKind.chapter,
              order: 0,
              createdAt: DateTime.now(),
              modifiedAt: DateTime.now(),
            ),
          ];

    final imageByToken = <String, ImportedImage>{
      for (final image in document.images) image.token: image,
    };
    final consumedTokens = <String>{};
    final prepared = <BookSection>[];

    for (var index = 0; index < rawSections.length; index++) {
      final raw = rawSections[index];
      final parsed = _stripImageMarkers(raw.content);
      final sectionImages = <SectionImage>[];

      for (final placement in parsed.placements) {
        final importedImage = imageByToken[placement.token];
        if (importedImage == null) continue;
        consumedTokens.add(placement.token);
        sectionImages.add(
          await _persistImportedImage(
            projectId: projectId,
            imported: importedImage,
            afterParagraph: placement.afterParagraph,
          ),
        );
      }

      prepared.add(
        raw.copyWith(
          content: parsed.content,
          images: sectionImages,
          order: index,
          modifiedAt: DateTime.now(),
        ),
      );
    }

    final orphanImages = document.images
        .where((image) => !consumedTokens.contains(image.token))
        .toList();
    if (orphanImages.isNotEmpty) {
      if (prepared.isEmpty) {
        prepared.add(
          BookSection(
            id: _id('section'),
            title: _titleFromFileName(document.fileName),
            content: '',
            kind: SectionKind.chapter,
            order: 0,
            createdAt: DateTime.now(),
            modifiedAt: DateTime.now(),
          ),
        );
      }
      final last = prepared.last;
      final images = List<SectionImage>.from(last.images);
      final afterParagraph = _paragraphCount(last.content);
      for (final importedImage in orphanImages) {
        images.add(
          await _persistImportedImage(
            projectId: projectId,
            imported: importedImage,
            afterParagraph: afterParagraph,
          ),
        );
      }
      prepared[prepared.length - 1] = last.copyWith(images: images);
    }

    return prepared;
  }

  Future<SectionImage> _persistImportedImage({
    required String projectId,
    required ImportedImage imported,
    required int afterParagraph,
  }) async {
    final imageId = _id('image');
    final extension = _extensionForImage(imported.name, imported.mimeType);
    final path = await _storage.saveImageAsset(
      projectId: projectId,
      imageId: imageId,
      extension: extension,
      bytes: imported.bytes,
    );
    return SectionImage(
      id: imageId,
      filePath: path,
      originalName: imported.name,
      mimeType: imported.mimeType,
      afterParagraph: afterParagraph,
      sourcePage: imported.sourcePage,
    );
  }

  Future<void> updateSection(String projectId, BookSection updatedSection) async {
    final project = projectById(projectId);
    if (project == null) return;
    final sections = project.sections
        .map((section) => section.id == updatedSection.id
            ? updatedSection.copyWith(modifiedAt: DateTime.now())
            : section)
        .toList();
    await updateProject(project.copyWith(sections: sections));
  }

  Future<void> deleteSection(String projectId, String sectionId) async {
    final project = projectById(projectId);
    if (project == null || project.sections.length <= 1) return;
    final remaining =
        project.sections.where((section) => section.id != sectionId).toList();
    final reordered = List<BookSection>.generate(
      remaining.length,
      (index) => remaining[index].copyWith(order: index),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<void> mergeWithPrevious(String projectId, String sectionId) async {
    final project = projectById(projectId);
    if (project == null) return;
    final index =
        project.sections.indexWhere((section) => section.id == sectionId);
    if (index <= 0) return;
    final sections = List<BookSection>.from(project.sections);
    final previous = sections[index - 1];
    final current = sections[index];
    final paragraphOffset = _paragraphCount(previous.content);
    final mergedImages = <SectionImage>[
      ...previous.images,
      ...current.images.map(
        (image) => image.copyWith(
          afterParagraph: image.afterParagraph + paragraphOffset,
        ),
      ),
    ]..sort((a, b) => a.afterParagraph.compareTo(b.afterParagraph));

    sections[index - 1] = previous.copyWith(
      content: '${previous.content.trim()}\n\n${current.content.trim()}'.trim(),
      images: mergedImages,
      modifiedAt: DateTime.now(),
    );
    sections.removeAt(index);
    final reordered = List<BookSection>.generate(
      sections.length,
      (position) => sections[position].copyWith(order: position),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<void> _persistAndNotify() async {
    try {
      _errorMessage = null;
      await _storage.saveProjects(_projects);
    } catch (error) {
      _errorMessage = 'Kayıt sırasında hata oluştu: $error';
    }
    notifyListeners();
  }

  static _MarkerParseResult _stripImageMarkers(String content) {
    final lines = content.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n');
    final cleaned = <String>[];
    final placements = <_ImagePlacement>[];
    var paragraphCount = 0;
    var paragraphOpen = false;

    void closeParagraph() {
      if (paragraphOpen) {
        paragraphCount++;
        paragraphOpen = false;
      }
    }

    for (final sourceLine in lines) {
      final line = sourceLine.trimRight();
      final marker = ImportService.imageMarkerPattern.firstMatch(line.trim());
      if (marker != null) {
        closeParagraph();
        placements.add(
          _ImagePlacement(
            token: marker.group(1)!,
            afterParagraph: paragraphCount,
          ),
        );
        continue;
      }

      if (line.trim().isEmpty) {
        closeParagraph();
        if (cleaned.isNotEmpty && cleaned.last.isNotEmpty) cleaned.add('');
      } else {
        paragraphOpen = true;
        cleaned.add(line);
      }
    }
    closeParagraph();

    while (cleaned.isNotEmpty && cleaned.last.isEmpty) {
      cleaned.removeLast();
    }

    return _MarkerParseResult(
      content: cleaned.join('\n').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim(),
      placements: placements,
    );
  }

  static int _paragraphCount(String content) {
    final trimmed = content.trim();
    if (trimmed.isEmpty) return 0;
    return trimmed
        .split(RegExp(r'\n\s*\n'))
        .where((paragraph) => paragraph.trim().isNotEmpty)
        .length;
  }

  static String _extensionForImage(String fileName, String mimeType) {
    final dot = fileName.lastIndexOf('.');
    if (dot >= 0 && dot < fileName.length - 1) {
      final extension = fileName.substring(dot + 1).toLowerCase();
      if (RegExp(r'^[a-z0-9]{2,5}$').hasMatch(extension)) return extension;
    }
    return switch (mimeType.toLowerCase()) {
      'image/png' => 'png',
      'image/gif' => 'gif',
      'image/webp' => 'webp',
      'image/bmp' => 'bmp',
      'image/tiff' => 'tiff',
      _ => 'jpg',
    };
  }

  static String _titleFromFileName(String fileName) {
    final title = fileName.replaceFirst(RegExp(r'\.[^.]+$'), '').trim();
    return title.isEmpty ? 'İçe Aktarılan Bölüm' : title;
  }

  static String _id(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}';
}

class _MarkerParseResult {
  const _MarkerParseResult({required this.content, required this.placements});

  final String content;
  final List<_ImagePlacement> placements;
}

class _ImagePlacement {
  const _ImagePlacement({required this.token, required this.afterParagraph});

  final String token;
  final int afterParagraph;
}
