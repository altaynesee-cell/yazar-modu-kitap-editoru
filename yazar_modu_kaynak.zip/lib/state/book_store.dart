import 'package:flutter/foundation.dart';

import '../models/book_project.dart';
import '../models/book_section.dart';
import '../services/chapter_parser.dart';
import '../services/project_storage.dart';

class BookStore extends ChangeNotifier {
  BookStore({ProjectStorage? storage}) : _storage = storage ?? ProjectStorage();

  final ProjectStorage _storage;
  final List<BookProject> _projects = <BookProject>[];
  bool _initialized = false;
  String? _errorMessage;

  List<BookProject> get projects => List<BookProject>.unmodifiable(_projects);
  bool get initialized => _initialized;
  String? get errorMessage => _errorMessage;

  Future<void> initialize() async {
    try {
      _projects
        ..clear()
        ..addAll(await _storage.loadProjects());
    } catch (error) {
      _errorMessage = 'Projeler yüklenemedi: $error';
    } finally {
      _initialized = true;
      notifyListeners();
    }
  }

  BookProject? projectById(String id) {
    for (final project in _projects) {
      if (project.id == id) return project;
    }
    return null;
  }

  Future<BookProject> createProject({
    required String title,
    required String author,
    String initialText = '',
  }) async {
    final now = DateTime.now();
    final project = BookProject(
      id: _id('project'),
      title: title.trim().isEmpty ? 'İsimsiz Kitap' : title.trim(),
      author: author.trim(),
      sections: ChapterParser.parse(initialText),
      createdAt: now,
      modifiedAt: now,
    );
    _projects.insert(0, project);
    await _persistAndNotify();
    return project;
  }

  Future<void> updateProject(BookProject updated) async {
    final index = _projects.indexWhere((project) => project.id == updated.id);
    if (index == -1) return;
    _projects[index] = updated.copyWith(modifiedAt: DateTime.now());
    _projects.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    await _persistAndNotify();
  }

  Future<void> deleteProject(String id) async {
    _projects.removeWhere((project) => project.id == id);
    await _persistAndNotify();
  }

  Future<void> reorderSections(String projectId, int oldIndex, int newIndex) async {
    final project = projectById(projectId);
    if (project == null) return;
    final sections = List<BookSection>.from(project.sections);
    if (newIndex > oldIndex) newIndex--;
    final moved = sections.removeAt(oldIndex);
    sections.insert(newIndex, moved);
    final reordered = List<BookSection>.generate(
      sections.length,
      (index) => sections[index].copyWith(order: index, modifiedAt: DateTime.now()),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<BookSection?> addSection(String projectId, {String? title}) async {
    final project = projectById(projectId);
    if (project == null) return null;
    final now = DateTime.now();
    final section = BookSection(
      id: _id('section'),
      title: title?.trim().isNotEmpty == true ? title!.trim() : '${project.sections.length + 1}. Bölüm',
      content: '',
      kind: SectionKind.chapter,
      order: project.sections.length,
      createdAt: now,
      modifiedAt: now,
    );
    await updateProject(project.copyWith(sections: <BookSection>[...project.sections, section]));
    return section;
  }

  Future<void> updateSection(String projectId, BookSection updatedSection) async {
    final project = projectById(projectId);
    if (project == null) return;
    final sections = project.sections
        .map((section) => section.id == updatedSection.id
            ? updatedSection.copyWith(modifiedAt: DateTime.now())
            : section)
        .toList();
    await updateProject(project.copyWith(sections: sections));
  }

  Future<void> deleteSection(String projectId, String sectionId) async {
    final project = projectById(projectId);
    if (project == null || project.sections.length <= 1) return;
    final remaining = project.sections.where((section) => section.id != sectionId).toList();
    final reordered = List<BookSection>.generate(
      remaining.length,
      (index) => remaining[index].copyWith(order: index),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<void> mergeWithPrevious(String projectId, String sectionId) async {
    final project = projectById(projectId);
    if (project == null) return;
    final index = project.sections.indexWhere((section) => section.id == sectionId);
    if (index <= 0) return;
    final sections = List<BookSection>.from(project.sections);
    final previous = sections[index - 1];
    final current = sections[index];
    sections[index - 1] = previous.copyWith(
      content: '${previous.content.trim()}\n\n${current.content.trim()}'.trim(),
      modifiedAt: DateTime.now(),
    );
    sections.removeAt(index);
    final reordered = List<BookSection>.generate(
      sections.length,
      (position) => sections[position].copyWith(order: position),
    );
    await updateProject(project.copyWith(sections: reordered));
  }

  Future<void> _persistAndNotify() async {
    try {
      _errorMessage = null;
      await _storage.saveProjects(_projects);
    } catch (error) {
      _errorMessage = 'Kayıt sırasında hata oluştu: $error';
    }
    notifyListeners();
  }

  static String _id(String prefix) => '$prefix-${DateTime.now().microsecondsSinceEpoch}';
}
