import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/section_image.dart';
import '../services/preview_text_parser.dart';

enum BookPreviewLayout { pageByPage, vertical }

class BookPagePreviewScreen extends StatelessWidget {
  const BookPagePreviewScreen({
    required this.title,
    required this.content,
    required this.images,
    super.key,
  });

  final String title;
  final String content;
  final List<SectionImage> images;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gerçek Sayfa Ön İzleme'),
      ),
      body: BookPagePreview(
        title: title,
        content: content,
        images: images,
        initialLayout: BookPreviewLayout.pageByPage,
      ),
    );
  }
}

/// Metni ve görselleri 13,5 × 21 cm oranındaki gerçek kitap sayfalarına
/// yaklaştırarak gösteren baskı ön izleme bileşeni.
class BookPagePreview extends StatefulWidget {
  const BookPagePreview({
    required this.title,
    required this.content,
    required this.images,
    this.initialLayout = BookPreviewLayout.pageByPage,
    super.key,
  });

  final String title;
  final String content;
  final List<SectionImage> images;
  final BookPreviewLayout initialLayout;

  @override
  State<BookPagePreview> createState() => _BookPagePreviewState();
}

class _BookPagePreviewState extends State<BookPagePreview> {
  late BookPreviewLayout _layout;
  final PageController _pageController = PageController();
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _layout = widget.initialLayout;
  }

  @override
  void didUpdateWidget(covariant BookPagePreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.title != widget.title ||
        oldWidget.content != widget.content ||
        oldWidget.images != widget.images) {
      _currentPage = 0;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) _pageController.jumpToPage(0);
      });
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        const ratio = 21 / 13.5;
        final availableWidth =
            math.max(260.0, constraints.maxWidth - 28).toDouble();
        final verticalPageWidth = math.min(520.0, availableWidth).toDouble();
        final maxWidthFromHeight =
            math.max(220.0, (constraints.maxHeight - 116) / ratio).toDouble();
        final pagedPageWidth = math
            .min(verticalPageWidth, maxWidthFromHeight)
            .clamp(220.0, 520.0)
            .toDouble();
        final pageWidth = _layout == BookPreviewLayout.pageByPage
            ? pagedPageWidth
            : verticalPageWidth;
        final pageHeight = pageWidth * ratio;
        final contentWidth = pageWidth - 68;
        final contentHeight = pageHeight - 92;
        final pages = _BookPaginator(
          context: context,
          title: widget.title,
          content: widget.content,
          images: widget.images,
          contentWidth: contentWidth,
          contentHeight: contentHeight,
        ).paginate();

        if (_currentPage >= pages.length && pages.isNotEmpty) {
          _currentPage = pages.length - 1;
        }

        return ColoredBox(
          color: const Color(0xFFE1D6C8),
          child: Column(
            children: <Widget>[
              Material(
                color: const Color(0xFFF4EBDD),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 7, 8, 7),
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.menu_book_outlined, size: 19),
                      const SizedBox(width: 8),
                      const Expanded(
                        child: Text(
                          'Gerçek kitap sayfası · 13,5 × 21 cm',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        tooltip: 'Sayfa sayfa',
                        onPressed: () => setState(
                          () => _layout = BookPreviewLayout.pageByPage,
                        ),
                        icon: Icon(
                          Icons.view_carousel_outlined,
                          color: _layout == BookPreviewLayout.pageByPage
                              ? Theme.of(context).colorScheme.primary
                              : null,
                        ),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        tooltip: 'Dikey sayfalar',
                        onPressed: () => setState(
                          () => _layout = BookPreviewLayout.vertical,
                        ),
                        icon: Icon(
                          Icons.view_agenda_outlined,
                          color: _layout == BookPreviewLayout.vertical
                              ? Theme.of(context).colorScheme.primary
                              : null,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: pages.isEmpty
                    ? const Center(child: Text('Ön izlenecek içerik yok.'))
                    : _layout == BookPreviewLayout.pageByPage
                        ? PageView.builder(
                            controller: _pageController,
                            itemCount: pages.length,
                            onPageChanged: (index) =>
                                setState(() => _currentPage = index),
                            itemBuilder: (context, index) => Center(
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: _BookPage(
                                  width: pageWidth,
                                  height: pageHeight,
                                  pageNumber: index + 1,
                                  blocks: pages[index],
                                ),
                              ),
                            ),
                          )
                        : ListView.separated(
                            padding:
                                const EdgeInsets.fromLTRB(14, 14, 14, 28),
                            itemCount: pages.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 18),
                            itemBuilder: (context, index) => Center(
                              child: _BookPage(
                                width: pageWidth,
                                height: pageHeight,
                                pageNumber: index + 1,
                                blocks: pages[index],
                              ),
                            ),
                          ),
              ),
              if (_layout == BookPreviewLayout.pageByPage && pages.isNotEmpty)
                Material(
                  color: const Color(0xFFF4EBDD),
                  child: SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      child: Row(
                        children: <Widget>[
                          IconButton(
                            tooltip: 'Önceki sayfa',
                            onPressed: _currentPage <= 0
                                ? null
                                : () => _pageController.previousPage(
                                      duration:
                                          const Duration(milliseconds: 240),
                                      curve: Curves.easeOut,
                                    ),
                            icon: const Icon(Icons.chevron_left),
                          ),
                          Expanded(
                            child: Text(
                              '${_currentPage + 1} / ${pages.length} sayfa',
                              textAlign: TextAlign.center,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Sonraki sayfa',
                            onPressed: _currentPage >= pages.length - 1
                                ? null
                                : () => _pageController.nextPage(
                                      duration:
                                          const Duration(milliseconds: 240),
                                      curve: Curves.easeOut,
                                    ),
                            icon: const Icon(Icons.chevron_right),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _BookPage extends StatelessWidget {
  const _BookPage({
    required this.width,
    required this.height,
    required this.pageNumber,
    required this.blocks,
  });

  final double width;
  final double height;
  final int pageNumber;
  final List<_PageBlock> blocks;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          color: Color(0xFFFFFCF5),
          boxShadow: <BoxShadow>[
            BoxShadow(
              blurRadius: 13,
              offset: Offset(0, 5),
              color: Color(0x44000000),
            ),
          ],
        ),
        child: Stack(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(34, 34, 34, 48),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: blocks
                    .map((block) => _PageBlockView(block: block))
                    .toList(),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 16,
              child: Text(
                '$pageNumber',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'serif',
                  fontSize: 12,
                  color: Color(0xFF675B50),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PageBlockView extends StatelessWidget {
  const _PageBlockView({required this.block});

  final _PageBlock block;

  @override
  Widget build(BuildContext context) {
    if (block.image != null) {
      final image = block.image!;
      final file = File(image.filePath);
      final caption = image.caption.trim().isNotEmpty
          ? image.caption.trim()
          : image.sourcePage == null
              ? ''
              : 'PDF sayfa ${image.sourcePage}';
      return Padding(
        padding: EdgeInsets.only(bottom: block.gap),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              height: block.contentHeight,
              child: ClipRect(
                child: file.existsSync()
                    ? Image.file(
                        file,
                        width: double.infinity,
                        fit: BoxFit.contain,
                        filterQuality: FilterQuality.medium,
                        errorBuilder: (_, __, ___) => const Center(
                          child: Icon(Icons.broken_image_outlined, size: 38),
                        ),
                      )
                    : const Center(
                        child: Icon(Icons.broken_image_outlined, size: 38),
                      ),
              ),
            ),
            if (caption.isNotEmpty) ...<Widget>[
              const SizedBox(height: 5),
              Text(
                caption,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: 'serif',
                  fontSize: 10.5,
                  height: 1.2,
                  fontStyle: FontStyle.italic,
                  color: Color(0xFF5F554C),
                ),
              ),
            ],
          ],
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(bottom: block.gap),
      child: Text(
        block.text,
        textAlign: block.kind == _BlockKind.paragraph
            ? TextAlign.justify
            : TextAlign.center,
        style: block.style,
      ),
    );
  }
}

class _BookPaginator {
  _BookPaginator({
    required this.context,
    required this.title,
    required this.content,
    required this.images,
    required this.contentWidth,
    required this.contentHeight,
  });

  final BuildContext context;
  final String title;
  final String content;
  final List<SectionImage> images;
  final double contentWidth;
  final double contentHeight;

  List<List<_PageBlock>> paginate() {
    final sourceBlocks = _sourceBlocks();
    final pages = <List<_PageBlock>>[<_PageBlock>[]];
    var remaining = contentHeight;

    void startPage() {
      pages.add(<_PageBlock>[]);
      remaining = contentHeight;
    }

    void addBlock(_PageBlock block) {
      pages.last.add(block);
      remaining -= block.totalHeight;
    }

    for (final source in sourceBlocks) {
      if (source.image != null) {
        if (source.totalHeight > remaining && pages.last.isNotEmpty) {
          startPage();
        }
        addBlock(source.copyWith(
          contentHeight: math.min(source.contentHeight, remaining - source.gap).toDouble(),
        ));
        continue;
      }

      if (source.kind != _BlockKind.paragraph) {
        final reserveForFollowingText = source.kind == _BlockKind.title ? 24.0 : 46.0;
        if (source.totalHeight + reserveForFollowingText > remaining &&
            pages.last.isNotEmpty) {
          startPage();
        }
        addBlock(source);
        continue;
      }

      var pendingText = source.text.trim();
      while (pendingText.isNotEmpty) {
        if (remaining < 42 && pages.last.isNotEmpty) startPage();
        final fitted = _fitText(
          pendingText,
          source.style,
          math.max(24.0, remaining - source.gap).toDouble(),
        );
        if (fitted.visible.isEmpty) {
          startPage();
          continue;
        }
        final block = source.copyWith(
          text: fitted.visible,
          contentHeight: _measureText(fitted.visible, source.style),
        );
        addBlock(block);
        pendingText = fitted.remaining.trim();
        if (pendingText.isNotEmpty) startPage();
      }
    }

    if (pages.length > 1 && pages.last.isEmpty) pages.removeLast();
    return pages;
  }

  List<_PageBlock> _sourceBlocks() {
    final rawParagraphs = content.trim().isEmpty
        ? <String>[]
        : content
            .trim()
            .split(RegExp(r'\n\s*\n'))
            .map((value) => value.trim())
            .where((value) => value.isNotEmpty)
            .toList();
    final imagesByPosition = <int, List<SectionImage>>{};
    for (final image in images) {
      final position = image.afterParagraph.clamp(0, rawParagraphs.length).toInt();
      imagesByPosition.putIfAbsent(position, () => <SectionImage>[]).add(image);
    }

    final blocks = <_PageBlock>[];
    final normalizedTitle = _normalizeSectionTitle(title);
    if (normalizedTitle.isNotEmpty) {
      const style = TextStyle(
        fontFamily: 'serif',
        fontSize: 22,
        height: 1.2,
        fontWeight: FontWeight.w700,
        color: Color(0xFF2D2118),
      );
      blocks.add(
        _PageBlock.text(
          kind: _BlockKind.title,
          text: normalizedTitle,
          style: style,
          contentHeight: _measureText(normalizedTitle, style),
          gap: 18,
        ),
      );
    }

    for (var position = 0; position <= rawParagraphs.length; position++) {
      for (final image in imagesByPosition[position] ?? const <SectionImage>[]) {
        final captionHeight = image.caption.trim().isNotEmpty || image.sourcePage != null
            ? 28.0
            : 0.0;
        blocks.add(
          _PageBlock.image(
            image: image,
            contentHeight: math.min(contentWidth * 0.62, contentHeight * 0.43).toDouble(),
            captionHeight: captionHeight,
            gap: 15,
          ),
        );
      }
      if (position >= rawParagraphs.length) continue;

      final parsed = PreviewTextParser.parseParagraph(
        rawParagraphs[position],
        allowMergedLeadingHeading: position == 0,
      );
      for (final parsedBlock in parsed) {
        final kind = switch (parsedBlock.kind) {
          PreviewTextKind.heading1 => _BlockKind.heading1,
          PreviewTextKind.heading2 => _BlockKind.heading2,
          PreviewTextKind.paragraph => _BlockKind.paragraph,
        };
        final style = switch (parsedBlock.kind) {
          PreviewTextKind.heading1 => const TextStyle(
              fontFamily: 'serif',
              fontSize: 18.5,
              height: 1.28,
              fontWeight: FontWeight.w700,
              color: Color(0xFF2D2118),
            ),
          PreviewTextKind.heading2 => const TextStyle(
              fontFamily: 'serif',
              fontSize: 17,
              height: 1.3,
              fontWeight: FontWeight.w700,
              color: Color(0xFF2D2118),
            ),
          PreviewTextKind.paragraph => const TextStyle(
              fontFamily: 'serif',
              fontSize: 15.5,
              height: 1.48,
              color: Color(0xFF2D2118),
            ),
        };
        blocks.add(
          _PageBlock.text(
            kind: kind,
            text: parsedBlock.text,
            style: style,
            contentHeight: _measureText(parsedBlock.text, style),
            gap: parsedBlock.kind == PreviewTextKind.paragraph ? 11 : 16,
          ),
        );
      }
    }
    return blocks;
  }

  String _normalizeSectionTitle(String value) {
    return value
        .trim()
        .replaceAllMapped(
          RegExp(r'^(\d+)\.\s*Bölüm$', caseSensitive: false),
          (match) => '${match.group(1)}. Bölüm',
        );
  }

  double _measureText(String text, TextStyle style) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: Directionality.of(context),
      textAlign: TextAlign.justify,
    )..layout(maxWidth: contentWidth);
    return painter.height;
  }

  _TextFit _fitText(String text, TextStyle style, double maxHeight) {
    final words = text.split(RegExp(r'\s+'));
    if (words.isEmpty) return const _TextFit('', '');
    if (_measureText(text, style) <= maxHeight) return _TextFit(text, '');

    var low = 1;
    var high = words.length;
    var best = 0;
    while (low <= high) {
      final middle = (low + high) ~/ 2;
      final candidate = words.take(middle).join(' ');
      if (_measureText(candidate, style) <= maxHeight) {
        best = middle;
        low = middle + 1;
      } else {
        high = middle - 1;
      }
    }

    if (best == 0) return const _TextFit('', '');
    if (best < words.length && best < 7) return const _TextFit('', '');
    return _TextFit(
      words.take(best).join(' '),
      words.skip(best).join(' '),
    );
  }
}

enum _BlockKind { title, heading1, heading2, paragraph, image }

class _PageBlock {
  const _PageBlock._({
    required this.kind,
    required this.text,
    required this.style,
    required this.contentHeight,
    required this.captionHeight,
    required this.gap,
    this.image,
  });

  factory _PageBlock.text({
    required _BlockKind kind,
    required String text,
    required TextStyle style,
    required double contentHeight,
    required double gap,
  }) =>
      _PageBlock._(
        kind: kind,
        text: text,
        style: style,
        contentHeight: contentHeight,
        captionHeight: 0,
        gap: gap,
      );

  factory _PageBlock.image({
    required SectionImage image,
    required double contentHeight,
    required double captionHeight,
    required double gap,
  }) =>
      _PageBlock._(
        kind: _BlockKind.image,
        text: '',
        style: const TextStyle(),
        contentHeight: contentHeight,
        captionHeight: captionHeight,
        gap: gap,
        image: image,
      );

  final _BlockKind kind;
  final String text;
  final TextStyle style;
  final double contentHeight;
  final double captionHeight;
  final double gap;
  final SectionImage? image;

  double get totalHeight => contentHeight + captionHeight + gap;

  _PageBlock copyWith({
    String? text,
    double? contentHeight,
  }) =>
      _PageBlock._(
        kind: kind,
        text: text ?? this.text,
        style: style,
        contentHeight: contentHeight ?? this.contentHeight,
        captionHeight: captionHeight,
        gap: gap,
        image: image,
      );
}

class _TextFit {
  const _TextFit(this.visible, this.remaining);

  final String visible;
  final String remaining;
}
