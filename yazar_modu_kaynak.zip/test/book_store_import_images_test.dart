import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/models/book_project.dart';
import 'package:yazar_modu_kitap_editoru/services/import_service.dart';
import 'package:yazar_modu_kitap_editoru/services/project_storage.dart';
import 'package:yazar_modu_kitap_editoru/state/book_store.dart';

void main() {
  test('DOCX ve PDF görsel işaretleri bölümlere bağlanır', () async {
    final storage = _MemoryStorage();
    final store = BookStore(storage: storage);
    await store.initialize();

    final document = ImportedDocument(
      fileName: 'ornek.docx',
      text: '''
1. Bölüm

İlk paragraf.

[[YM_IMAGE:resim-1]]

İkinci paragraf.
''',
      images: <ImportedImage>[
        ImportedImage(
          token: 'resim-1',
          name: 'image1.png',
          mimeType: 'image/png',
          bytes: Uint8List.fromList(<int>[1, 2, 3]),
        ),
      ],
    );

    final project = await store.createProjectFromImportedDocument(
      title: 'Test',
      author: 'Yazar',
      document: document,
    );

    expect(project.sections, hasLength(1));
    expect(project.sections.first.images, hasLength(1));
    expect(project.sections.first.images.first.afterParagraph, 1);
    expect(project.sections.first.content, isNot(contains('YM_IMAGE')));
    expect(storage.savedImageCount, 1);
  });
}

class _MemoryStorage extends ProjectStorage {
  int savedImageCount = 0;
  List<BookProject> projects = <BookProject>[];

  @override
  Future<List<BookProject>> loadProjects() async => projects;

  @override
  Future<void> saveProjects(List<BookProject> projects) async {
    this.projects = List<BookProject>.from(projects);
  }

  @override
  Future<String> saveImageAsset({
    required String projectId,
    required String imageId,
    required String extension,
    required Uint8List bytes,
  }) async {
    savedImageCount++;
    return '/test/$projectId/$imageId.$extension';
  }
}
