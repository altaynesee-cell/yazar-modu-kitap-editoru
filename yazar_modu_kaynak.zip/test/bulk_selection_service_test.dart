import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/services/bulk_selection_service.dart';

void main() {
  test('Tümünü reddet bütün değişiklikleri reddeder', () {
    final result = BulkSelectionService.selectAll(
      accept: false,
      items: const <BulkSelectionItem>[
        BulkSelectionItem(
          unchanged: false,
          protectedFromShortening: false,
          accepted: true,
        ),
        BulkSelectionItem(
          unchanged: false,
          protectedFromShortening: true,
          accepted: true,
        ),
      ],
    );

    expect(result.acceptedValues, <bool>[false, false]);
    expect(result.acceptedCount, 0);
    expect(result.rejectedCount, 2);
  });

  test('Tümünü kabul kısaltıcı öneri hariç bütün değişiklikleri kabul eder', () {
    final result = BulkSelectionService.selectAll(
      accept: true,
      items: const <BulkSelectionItem>[
        BulkSelectionItem(
          unchanged: false,
          protectedFromShortening: false,
          accepted: false,
        ),
        BulkSelectionItem(
          unchanged: false,
          protectedFromShortening: true,
          accepted: false,
        ),
        BulkSelectionItem(
          unchanged: true,
          protectedFromShortening: false,
          accepted: true,
        ),
      ],
    );

    expect(result.acceptedValues, <bool>[true, false, true]);
    expect(result.acceptedCount, 1);
    expect(result.rejectedCount, 1);
    expect(result.protectedCount, 1);
  });
}
