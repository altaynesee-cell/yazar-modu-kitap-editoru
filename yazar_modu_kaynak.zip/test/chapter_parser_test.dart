import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/models/book_section.dart';
import 'package:yazar_modu_kitap_editoru/services/chapter_parser.dart';

void main() {
  test('Ön Söz ve Giriş numarasız türlerde algılanır', () {
    const text = 'ÖN SÖZ\nBu bir ön söz metnidir.\n\nGİRİŞ\nBu bir giriş metnidir.\n\n1. BÖLÜM\nİLK İZLER\nBirinci bölüm metni.';

    final sections = ChapterParser.parse(text);

    expect(sections.length, 3);
    expect(sections[0].title, 'Ön Söz');
    expect(sections[0].kind, SectionKind.frontMatter);
    expect(sections[1].title, 'Giriş');
    expect(sections[2].title, '1. Bölüm — İLK İZLER');
  });

  test('Başlık bulunmayan metin tek bölüm olur', () {
    final sections = ChapterParser.parse('Tek parça ham kitap metni.');
    expect(sections.length, 1);
    expect(sections.single.title, '1. Bölüm');
  });

  test('BÖLÜM 2 biçimi algılanır', () {
    final sections = ChapterParser.parse('BÖLÜM 2 — DENEME\nMetin');
    expect(sections.single.title, '2. Bölüm — DENEME');
  });


  test('bölüm, ana başlık ve alt başlığı ayrı alanlara ayırır', () {
    const text = '''13. BÖLÜM
DİDİM APOLLON TAPINAĞI
KEHANETLER, YERALTI GEÇİTLERİ VE TANRI’NIN SESİ

Anadolu’nun batı kıyılarında yükselen tapınak.''';

    final section = ChapterParser.parse(text).single;

    expect(section.chapterNumber, 13);
    expect(section.mainTitle, 'DİDİM APOLLON TAPINAĞI');
    expect(
      section.subtitle,
      'KEHANETLER, YERALTI GEÇİTLERİ VE TANRI’NIN SESİ',
    );
    expect(section.content.startsWith('Anadolu’nun'), isTrue);
  });
}
