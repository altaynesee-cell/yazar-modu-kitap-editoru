import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/services/local_editor_service.dart';

void main() {
  test('Yerel düzenleyici tekrarları düzeltir ve paragrafları korur', () {
    const input = 'Bu bu bir denemedir.\n\nAynı paragraf.\n\nAynı paragraf.';
    final output =
        LocalEditorService.createSuggestion(input, LocalEditMode.full);

    expect(output.toLowerCase(), contains('bu bir denemedir'));
    expect(RegExp('Aynı paragraf').allMatches(output).length, 2);
    expect(
      LocalEditorService.paragraphCount(output),
      LocalEditorService.paragraphCount(input),
    );
  });
}
