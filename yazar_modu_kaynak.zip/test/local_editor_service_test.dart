import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/services/local_editor_service.dart';

void main() {
  test('Tekrarlanan kelimeleri ve paragrafları azaltır', () {
    const input = 'Bu bu bir denemedir.\n\nAynı paragraf.\n\nAynı paragraf.';
    final output = LocalEditorService.createSuggestion(input, LocalEditMode.full);

    expect(output.toLowerCase(), contains('bu bir denemedir'));
    expect(RegExp('Aynı paragraf').allMatches(output).length, 1);
  });

  test('Noktalama çevresindeki boşlukları düzeltir', () {
    const input = 'Bir cümle ,devam ediyor.';
    final output = LocalEditorService.createSuggestion(input, LocalEditMode.spelling);
    expect(output, 'Bir cümle, devam ediyor.');
  });
}
