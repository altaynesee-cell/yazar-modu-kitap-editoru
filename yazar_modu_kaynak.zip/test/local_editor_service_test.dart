import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Yazar Modu test altyapısı çalışır', () {
    expect(true, isTrue);
  });
}
