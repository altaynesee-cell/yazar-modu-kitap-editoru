import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/services/preview_text_parser.dart';

void main() {
  test('birleşmiş ana başlık ile ilk paragrafı ayırır', () {
    final blocks = PreviewTextParser.parse(
      'ANUNNAKİLER: GÖKTEN İNENLER VE İLK TEMAS TEORİSİnsanlık tarihinin en gizemli anlatılarından biridir.',
    );

    expect(blocks.length, 2);
    expect(blocks.first.kind, PreviewTextKind.heading1);
    expect(
      blocks.first.text,
      'ANUNNAKİLER: GÖKTEN İNENLER VE İLK TEMAS TEORİSİ',
    );
    expect(blocks.last.kind, PreviewTextKind.paragraph);
    expect(blocks.last.text.startsWith('İnsanlık'), isTrue);
  });

  test('başlık ile gövde arasında boşluk varsa ilk harfi başlığa katmaz', () {
    final blocks = PreviewTextParser.parse(
      'ANUNNAKİLER: GÖKTEN İNENLER VE İLK TEMAS TEORİSİ İnsanlık tarihinin en gizemli anlatılarından biridir.',
    );

    expect(blocks.length, 2);
    expect(
      blocks.first.text,
      'ANUNNAKİLER: GÖKTEN İNENLER VE İLK TEMAS TEORİSİ',
    );
    expect(blocks.last.text.startsWith('İnsanlık'), isTrue);
  });

  test('normal paragrafı başlık saymaz', () {
    final blocks = PreviewTextParser.parse(
      'İnsanlık tarihinin en gizemli anlatılarından biri bu konuyla ilgilidir.',
    );

    expect(blocks.single.kind, PreviewTextKind.paragraph);
  });
}
