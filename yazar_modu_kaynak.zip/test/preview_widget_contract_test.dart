import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/widgets/book_page_preview.dart';

void main() {
  test('Gerçek sayfa ön izleme bileşeni projede bulunur', () {
    expect(BookPagePreview, isNotNull);
  });
}
