import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/models/book_section.dart';
import 'package:yazar_modu_kitap_editoru/services/section_title_parser.dart';

void main() {
  test('eski Didim bölümünü üç ayrı başlık alanına ayırır', () {
    final now = DateTime(2026, 7, 23);
    final section = BookSection(
      id: 'didim',
      title: '13. Bölüm — DİDİM APOLLON TAPINAĞI',
      content:
          'KEHANETLER, YERALTI GEÇİTLERİ\n\nVE TANRI’NIN SESİ Anadolu’nun batı kıyılarında yükselen Didim Apollon Tapınağı, antik dünyanın önemli merkezlerinden biridir.',
      kind: SectionKind.chapter,
      order: 12,
      createdAt: now,
      modifiedAt: now,
    );

    final result = SectionTitleParser.resolve(section: section);

    expect(result.chapterNumber, 13);
    expect(result.mainTitle, 'DİDİM APOLLON TAPINAĞI');
    expect(
      result.subtitle,
      'KEHANETLER, YERALTI GEÇİTLERİ VE TANRI’NIN SESİ',
    );
    expect(result.body.startsWith('Anadolu’nun'), isTrue);
    expect(result.removedLeadingParagraphs, 1);
  });
}
