import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/screens/ai_comparison_screen.dart';
import 'package:yazar_modu_kitap_editoru/widgets/book_page_preview.dart';

void main() {
  testWidgets('Tümünü kabul ve reddet seçimleri bütün grupları günceller',
      (tester) async {
    // Karşılaştırma ekranı telefonda dikey kullanıldığı için test yüzeyini de
    // gerçek bir telefon yüksekliğine yaklaştırıyoruz. Böylece alt işlem
    // düğmeleri görünür ve gerçekten dokunulabilir durumda sınanır.
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(
      const MaterialApp(
        home: AiComparisonScreen(
          originalText: 'Bu bu bir denemedir. Metin korunacaktır.',
        ),
      ),
    );
    await tester.pumpAndSettle();

    final rejectAll = find.widgetWithText(FilledButton, 'Tümünü reddet');
    expect(rejectAll, findsOneWidget);
    await tester.ensureVisible(rejectAll);
    await tester.tap(rejectAll);
    await tester.pumpAndSettle();
    expect(find.textContaining('Kabul: 0'), findsOneWidget);

    final acceptAll = find.widgetWithText(FilledButton, 'Tümünü kabul et');
    expect(acceptAll, findsOneWidget);
    await tester.ensureVisible(acceptAll);
    await tester.tap(acceptAll);
    await tester.pumpAndSettle();
    expect(find.textContaining('Ret: 0'), findsOneWidget);
  });

  testWidgets('Gerçek sayfa ön izlemesi sayfa sayfa açılır', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 420,
            height: 760,
            child: BookPagePreview(
              title: '1. Bölüm',
              content:
                  'ANA BAŞLIK\n\nBu metin gerçek kitap sayfasında gösterilir.',
              images: [],
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('Gerçek kitap sayfası'), findsOneWidget);
    expect(find.textContaining('/ 1 sayfa'), findsOneWidget);
  });
}
