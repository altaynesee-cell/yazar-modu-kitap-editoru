import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/screens/ai_comparison_screen.dart';
import 'package:yazar_modu_kitap_editoru/widgets/book_page_preview.dart';

void main() {
  testWidgets('Tümünü kabul ve reddet seçimleri bütün grupları günceller',
      (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: AiComparisonScreen(
          originalText: 'Bu bu bir denemedir. Metin korunacaktır.',
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('Tümünü reddet'));
    await tester.pump();
    expect(find.textContaining('Kabul: 0'), findsOneWidget);

    await tester.tap(find.text('Tümünü kabul et'));
    await tester.pump();
    expect(find.textContaining('Ret: 0'), findsOneWidget);
  });

  testWidgets('Gerçek sayfa ön izlemesi sayfa sayfa açılır', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(
            width: 420,
            height: 760,
            child: BookPagePreview(
              title: '1. Bölüm',
              content:
                  'ANA BAŞLIK\n\nBu metin gerçek kitap sayfasında gösterilir.',
              images: [],
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('Gerçek kitap sayfası'), findsOneWidget);
    expect(find.textContaining('/ 1 sayfa'), findsOneWidget);
  });
}
