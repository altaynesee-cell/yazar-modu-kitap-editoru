import 'package:flutter_test/flutter_test.dart';
import 'package:yazar_modu_kitap_editoru/main.dart';

void main() {
  test('Yazar Modu uygulama sınıfı erişilebilir', () {
    expect(YazarModuApp, isNotNull);
  });
}
