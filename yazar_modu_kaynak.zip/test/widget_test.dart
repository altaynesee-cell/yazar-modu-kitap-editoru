import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Temel test ortamı çalışır', () {
    expect(true, isTrue);
  });
}
